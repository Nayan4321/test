<?php
// Creates connect-config.php (next to config.php) with a random state_key, once. Fill in the two Google values after.
$f = dirname(__DIR__) . '/connect-config.php';
if (is_file($f)) {
	echo "exists\n";
	exit;
}
$key = bin2hex(random_bytes(32));
file_put_contents($f, "<?php\n// Google Cloud → Credentials → OAuth client (Web application). Redirect URIs:\n//   https://sh.laghavi.site/connect/callback.php   (WordPress plugin)\n//   https://sh.laghavi.site/google/callback        (Shopify app)\nreturn array(\n\t'google_client_id'     => '',\n\t'google_client_secret' => '',\n\t'state_key'            => '" . $key . "',\n);\n");
chmod($f, 0600);
echo "created\n";

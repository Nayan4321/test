<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Config;
use App\Crypto;
use App\Insights;
use App\Log;
use App\Platform\BigCommerce;
use App\Platform\Platform;
use App\Plan;
use App\Platform\Shopify;
use App\Reports;
use App\Search;
use App\Shops;
use App\Tracker;

/**
 * All requests. Every data request must prove which shop it is for with a token signed by
 * Shopify / BigCommerce (or by this app for BigCommerce's iframe) — the shop is never taken from the URL.
 */
final class App
{
    /** Bump when the pixel / storefront script changes, so every shop gets the new one on its next visit to the app. */
    public const SETUP = 2;

    private static function needsSetup(array $row): bool
    {
        if (! $row['pixel'] || ! $row['timezone']) {
            return true;
        }
        $r = \App\Db::one('SELECT v FROM cache WHERE shop_id = ? AND k = ?', [$row['id'], 'setup']);

        return (int) json_decode((string) ($r['v'] ?? '0')) < self::SETUP;
    }

    public static function handle(string $method, string $path): void
    {
        $sh = Config::shopify();
        match (true) {
            $path === '/hit' => self::hit(),
            $path === '/google/start' => self::googleStart(),
            $path === '/google/callback' => self::googleCallback(),
            $path === '/t.js' && ! $sh => self::script(),
            str_starts_with($path, '/api/') => self::api(substr($path, 5)),
            $sh && $path === '/' => self::shopifyApp(),
            $sh && $path === '/shopify/webhooks' && $method === 'POST' => self::shopifyWebhook(),
            ! $sh && $path === '/bc/auth' => self::bcAuth(),
            ! $sh && $path === '/bc/load' => self::bcLoad(),
            ! $sh && $path === '/bc/uninstall' => self::bcUninstall(),
            ! $sh && $path === '/bc/remove_user' => self::ok(),
            $path === '/' => self::page('home'),
            $path === '/health' => self::ok(),
            $path === '/feedback' && $method === 'POST' => self::feedback(),
            default => self::notFound(),
        };
    }

    // ---------------------------------------------------------------- shared

    private static function ok(): void
    {
        header('Content-Type: text/plain');
        echo 'ok';
    }

    /**
     * Deactivation feedback from the free WordPress plugin. Only what the person chose to send:
     * reason, their words, an email if they typed one, versions and the site address.
     * Kept in storage/feedback.log and mailed to the support address. At most 5 a day per sender.
     */
    private static function feedback(): void
    {
        $raw = (string) file_get_contents('php://input', false, null, 0, 8192);
        $d = json_decode($raw, true);
        if (! is_array($d) || ($d['p'] ?? '') !== 'lgpi-wp') {
            self::json(['ok' => false], 400);

            return;
        }
        $clean = static fn ($v, int $n) => mb_substr(trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', (string) $v) ?? ''), 0, $n);
        $email = $clean($d['email'] ?? '', 190);
        $row = [
            'at' => gmdate('c'),
            'reason' => $clean($d['reason'] ?? '', 40),
            'details' => $clean($d['details'] ?? '', 1000),
            'email' => filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : '',
            'site' => $clean($d['site'] ?? '', 190),
            'plugin' => $clean($d['v'] ?? '', 20),
            'wp' => $clean($d['wp'] ?? '', 20),
            'wc' => $clean($d['wc'] ?? '', 20),
            'php' => $clean($d['php'] ?? '', 20),
        ];
        if ($row['reason'] === '') {
            self::json(['ok' => false], 400);

            return;
        }
        $dir = dirname(__DIR__, 2).'/storage';
        $rate = $dir.'/feedback-rate.json';
        $key = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '').gmdate('Y-m-d'));
        $counts = json_decode((string) @file_get_contents($rate), true);
        $counts = is_array($counts) && ($counts['_day'] ?? '') === gmdate('Y-m-d') ? $counts : ['_day' => gmdate('Y-m-d')];
        if (($counts[$key] ?? 0) >= 5) {
            self::json(['ok' => true]);

            return;
        }
        $counts[$key] = ($counts[$key] ?? 0) + 1;
        @file_put_contents($rate, json_encode($counts), LOCK_EX);
        $log = $dir.'/feedback.log';
        if (! is_file($log) || filesize($log) < 5_000_000) {
            @file_put_contents($log, json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)."\n", FILE_APPEND | LOCK_EX);
        }
        $to = (string) Config::get('support_email');
        if ($to !== '' && function_exists('mail')) {
            $body = '';
            foreach ($row as $k => $v) {
                $body .= str_pad($k.':', 9).$v."\n";
            }
            $head = 'From: Performance Insight <'.$to.'>'."\r\n".'Content-Type: text/plain; charset=UTF-8';
            if ($row['email'] !== '') {
                $head .= "\r\nReply-To: ".$row['email'];
            }
            @mail($to, 'WordPress plugin deactivated: '.$row['reason'], $body, $head);
        }
        self::json(['ok' => true]);
    }

    private static function notFound(): void
    {
        http_response_code(404);
        header('Content-Type: text/plain');
        echo 'Not found';
    }

    private static function json(mixed $data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json');
        header('Cache-Control: no-store');
        echo json_encode($data);
    }

    private static function frameHeaders(?string $shop): void
    {
        $anc = Config::shopify()
            ? ($shop ? "https://$shop https://admin.shopify.com" : 'https://admin.shopify.com')
            : 'https://*.bigcommerce.com https://*.mybigcommerce.com';
        header("Content-Security-Policy: frame-ancestors $anc;");
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');
    }

    private static function page(string $view, array $vars = []): void
    {
        self::frameHeaders($vars['shop']['shop'] ?? null);
        header('Content-Type: text/html; charset=utf-8');
        extract($vars);
        require dirname(__DIR__, 2).'/views/'.$view.'.php';
    }

    private static function api(string $what): void
    {
        $shop = self::authShop();
        if (! $shop) {
            self::json(['error' => 'Please reload the app.'], 401);

            return;
        }
        try {
            if ($what === 'plan' || $what === 'prefs' || $what === 'report-test') {
                self::planApi($shop, $what);

                return;
            }
            if (in_array($what, ['search-connect', 'search-save', 'search-disconnect', 'search-sites'], true)) {
                self::searchApi($shop, $what);

                return;
            }
            $plan = Plan::of($shop);
            $range = Insights::parseRange($_GET, (string) ($shop['timezone'] ?? 'UTC'), Plan::days($plan));
            $ins = new Insights($shop, self::platform($shop), $range);
            $data = match ($what) {
                'summary' => $ins->summary(),
                'realtime' => $ins->realtime(),
                'sources' => $ins->sources(),
                'visitors' => $ins->visitors(),
                'pages' => $ins->pages(),
                'products' => $ins->products(),
                'journeys' => $ins->journeys(in_array($_GET['only'] ?? '', ['order', 'cart'], true) ? (string) $_GET['only'] : ''),
                'stock' => $ins->stock(),
                'coupons' => $ins->coupons(),
                'seo' => $ins->seo(),
                'search' => Search::report($shop, $ins),
                'profit' => Plan::paid($plan) ? $ins->profit() : ['locked' => true],
                'customers' => Plan::paid($plan) ? $ins->customers() : ['locked' => true],
                'item' => is_string($_GET['path'] ?? null) && str_starts_with($_GET['path'], '/') && strlen($_GET['path']) <= 300 ? ($ins->item($_GET['path']) ?? []) : null,
                default => null,
            };
            $data === null ? self::json(['error' => 'Unknown'], 404) : self::json(['data' => $data, 'currency' => $shop['currency'], 'range' => $ins->range(), 'preset' => $range[2], 'prev' => $ins->prevRange(), 'warnings' => $ins->warnings(), 'since' => $ins->countingSince(), 'history' => $ins->historyRange(),
                'plan' => $plan, 'cut' => ! empty($range[3]) ? Plan::days($plan) : null]);
        } catch (\Throwable $e) {
            Log::error($e, ['shop' => $shop['shop']]);
            self::json(['error' => 'Could not load your store data right now. Please try again in a minute.'], 502);
        }
    }

    /** Plan tab: the plan, the report settings, saving them, and a test report. */
    private static function planApi(array $shop, string $what): void
    {
        $id = (int) $shop['id'];
        $plan = Plan::of($shop, $what === 'plan');
        if ($what === 'prefs' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            $in = json_decode((string) file_get_contents('php://input', false, null, 0, 4096), true);
            $in = is_array($in) ? $in : [];
            $email = trim((string) ($in['email'] ?? ''));
            if ($email !== '' && ! filter_var($email, FILTER_VALIDATE_EMAIL)) {
                self::json(['error' => 'Please enter a valid email address.'], 422);

                return;
            }
            Shops::setPref($id, 'email', $email === '' ? '' : Crypto::seal(mb_substr($email, 0, 190)));
            Shops::setPref($id, 'weekly', empty($in['weekly']) ? '0' : '1');
            Shops::setPref($id, 'alerts', empty($in['alerts']) ? '0' : '1');
        }
        if ($what === 'report-test') {
            if (! Plan::paid($plan)) {
                self::json(['error' => 'Email reports are part of the Plus plan.'], 403);

                return;
            }
            $sent = Reports::weekly($shop, true);
            self::json($sent === true ? ['ok' => true] : ['error' => $sent], $sent === true ? 200 : 422);

            return;
        }
        $p = Shops::prefs($id);
        $email = ($p['email'] ?? '') !== '' ? (string) Crypto::unseal((string) $p['email']) : '';
        if ($email === '' && ! isset($p['email'])) {
            $email = Reports::shopEmail($shop);
        }
        self::json(['data' => [
            'plan' => $plan, 'name' => Plan::NAMES[$plan], 'pricing' => Plan::pricingUrl($shop), 'free_days' => Plan::FREE_DAYS,
            'hub' => $plan === 'pro' && Config::get('hub_url') ? (string) Config::get('hub_url') : null,
            'email' => $email, 'weekly' => ($p['weekly'] ?? '1') === '1', 'alerts' => ($p['alerts'] ?? '1') === '1',
            'last_weekly' => $p['last_weekly'] ?? null, 'last_alert' => $p['last_alert'] ?? null,
        ]]);
    }

    /** Search tab settings: start Google sign-in, list properties, save the property / Bing key, disconnect. */
    private static function searchApi(array $shop, string $what): void
    {
        $post = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
        $in = $post ? json_decode((string) file_get_contents('php://input', false, null, 0, 4096), true) : [];
        $in = is_array($in) ? $in : [];
        if ($what === 'search-connect') {
            Search::googleReady() ? self::json(['url' => Search::startUrl($shop)]) : self::json(['error' => 'Google sign-in is not switched on yet.'], 503);

            return;
        }
        if ($what === 'search-sites') {
            self::json(['sites' => Search::sites($shop), 'status' => Search::status($shop)]);

            return;
        }
        if (! $post) {
            self::json(['error' => 'POST only'], 405);

            return;
        }
        if ($what === 'search-disconnect') {
            Search::disconnect($shop, (string) ($in['which'] ?? ''));
            self::json(['ok' => true]);

            return;
        }
        $err = Search::save($shop, array_intersect_key($in, ['g_site' => 1, 'b_key' => 1]));
        $err === null ? self::json(['ok' => true, 'status' => Search::status($shop)]) : self::json(['error' => $err], 422);
    }

    /** Opened in a new tab from the app (Google sign-in can't run inside the Shopify admin frame). */
    private static function googleStart(): void
    {
        $url = Search::start((string) ($_GET['t'] ?? ''));
        if ($url === null) {
            self::message('This link has expired. Go back to the app and click "Sign in with Google" again.');

            return;
        }
        header('Cache-Control: no-store');
        header('Location: '.$url, true, 302);
    }

    private static function googleCallback(): void
    {
        self::message(Search::callback($_GET));
    }

    private static function message(string $text): void
    {
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');
        echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Performance Insight</title>'
            .'<body style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:520px;margin:12vh auto;padding:0 20px;color:#1d2327">'
            .'<h1 style="font-size:20px">Performance Insight</h1><p>'.htmlspecialchars($text, ENT_QUOTES, 'UTF-8').'</p>'
            .'<script>try{window.opener&&window.opener.postMessage("pi-search-connected","*")}catch(e){}</script></body>';
    }

    /** Which shop is asking: Shopify session token, or this app's token for BigCommerce. */
    private static function authShop(): ?array
    {
        $h = (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        if (! preg_match('/^Bearer\s+(\S+)$/', $h, $m)) {
            return null;
        }
        if (Config::shopify()) {
            $shop = self::sessionShop($m[1]);
            $row = $shop ? Shops::byShop($shop) : null;

            return $row && ! $row['uninstalled_at'] ? $row : null;
        }
        $id = Crypto::checkAppToken($m[1]);

        return $id ? Shops::find($id) : null;
    }

    public static function platform(array $shop): Platform
    {
        return Config::shopify() ? new Shopify($shop) : new BigCommerce($shop);
    }

    private static function hit(): void
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            http_response_code(204);

            return;
        }
        $raw = (string) file_get_contents('php://input', false, null, 0, 4096);
        $in = json_decode($raw, true);
        if (is_array($in)) {
            try {
                Tracker::hit($in, (string) ($_SERVER['REMOTE_ADDR'] ?? ''), (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
            } catch (\Throwable $e) {
                Log::error($e);
            }
        }
        http_response_code(204);
    }

    /** First load after install: store name, currency, time zone, domain; switch on visit counting. */
    private static function setup(array $shop): array
    {
        try {
            $api = self::platform($shop);
            $info = $api->info();
            Shops::update((int) $shop['id'], ['name' => mb_substr($info['name'], 0, 190), 'currency' => mb_substr($info['currency'], 0, 8),
                'timezone' => mb_substr($info['timezone'], 0, 60), 'domain' => mb_substr($info['domain'], 0, 255)]);
            $shop = Shops::find((int) $shop['id']) ?? $shop;
            $id = $api instanceof Shopify ? $api->enablePixel() : ($api instanceof BigCommerce ? $api->enableScript() : null);
            if ($id) {
                Shops::update((int) $shop['id'], ['pixel' => mb_substr($id, 0, 190)]);
                \App\Db::run('DELETE FROM cache WHERE shop_id = ? AND k = ?', [$shop['id'], 'setup']);
                \App\Db::run('INSERT INTO cache (shop_id, k, v, at) VALUES (?, ?, ?, ?)', [$shop['id'], 'setup', json_encode(self::SETUP), time()]);
            }
        } catch (\Throwable $e) {
            Log::error($e, ['setup' => $shop['shop']]);
        }

        return Shops::find((int) $shop['id']) ?? $shop;
    }

    // ---------------------------------------------------------------- Shopify

    /** Shop domain from a valid Shopify session token (id_token), else null. */
    public static function sessionShop(string $jwt): ?string
    {
        $c = \App\Crypto::jwt($jwt, (string) Config::get('client_secret'));
        if (! $c || ($c['aud'] ?? '') !== Config::get('client_id')) {
            return null;
        }
        $dest = (string) parse_url((string) ($c['dest'] ?? ''), PHP_URL_HOST);
        $iss = (string) parse_url((string) ($c['iss'] ?? ''), PHP_URL_HOST);

        return Shopify::validShop($dest) && $iss === $dest ? $dest : null;
    }

    private static function shopifyApp(): void
    {
        $idToken = (string) ($_GET['id_token'] ?? '');
        $shopParam = strtolower((string) ($_GET['shop'] ?? ''));
        $shop = $idToken !== '' ? self::sessionShop($idToken) : null;
        if (! $shop) {
            if (Shopify::validShop($shopParam)) {
                // Opened outside the Shopify admin: send them into the admin, where Shopify signs the request.
                header('Location: https://'.$shopParam.'/admin/apps/'.rawurlencode((string) Config::get('client_id')), true, 302);

                return;
            }
            self::page('home');

            return;
        }
        $row = Shops::byShop($shop);
        if (! $row || $row['uninstalled_at'] || ! Shopify::freshToken($row)) {
            $t = Shopify::exchange($shop, $idToken);
            $row = Shops::install($shop, $t['access_token'], (string) ($t['scope'] ?? ''), $t['refresh_token'] ?? null, isset($t['expires_in']) ? time() + (int) $t['expires_in'] : null);
            $row = self::setup($row);
        } elseif (self::needsSetup($row)) {
            $row = self::setup($row);
        }
        self::page('app', ['shop' => $row, 'appToken' => null, 'plan' => Plan::of($row, true)]);   // fresh: the merchant may have just changed plan
    }

    private static function shopifyWebhook(): void
    {
        $raw = (string) file_get_contents('php://input');
        $sig = (string) ($_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'] ?? '');
        if (! hash_equals(base64_encode(hash_hmac('sha256', $raw, (string) Config::get('client_secret'), true)), $sig)) {
            http_response_code(401);

            return;
        }
        $topic = (string) ($_SERVER['HTTP_X_SHOPIFY_TOPIC'] ?? '');
        $shop = strtolower((string) ($_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'] ?? ''));
        $row = Shopify::validShop($shop) ? Shops::byShop($shop) : null;
        if ($row && in_array($topic, ['app/uninstalled', 'shop/redact'], true)) {
            Shops::forget((int) $row['id']);
            if ($topic === 'shop/redact') {
                \App\Db::run('DELETE FROM shops WHERE id = ?', [$row['id']]);
            }
        }
        if ($row && $topic === 'customers/redact') {
            // No names, emails or addresses are stored. Journeys are linked to an order only by its number: delete those of this customer's orders.
            $in = json_decode($raw, true);
            $ids = array_values(array_filter(array_map(fn ($x) => \App\Crypto::order((int) $row['id'], (string) $x), (array) ($in['orders_to_redact'] ?? []))));
            foreach (array_chunk($ids, 200) as $chunk) {
                $ph = implode(',', array_fill(0, count($chunk), '?'));
                \App\Db::run("DELETE FROM journeys WHERE shop_id = ? AND oid IN ($ph)", [$row['id'], ...$chunk]);
                \App\Db::run("DELETE FROM events WHERE shop_id = ? AND oid IN ($ph)", [$row['id'], ...$chunk]);
            }
            \App\Db::run("DELETE FROM cache WHERE shop_id = ? AND k LIKE 'ord:%'", [$row['id']]);
        }
        // customers/data_request: the app holds no personal data about the customer (only anonymous counts), so there is nothing to send.
        http_response_code(200);
    }

    // ---------------------------------------------------------------- BigCommerce

    private static function bcClaims(): ?array
    {
        $c = Crypto::jwt((string) ($_GET['signed_payload_jwt'] ?? ''), (string) Config::get('client_secret'));
        if (! $c || ($c['aud'] ?? '') !== Config::get('client_id') || ! preg_match('#^stores/([a-z0-9]+)$#', (string) ($c['sub'] ?? ''), $m)) {
            return null;
        }

        return $c + ['store_hash' => $m[1]];
    }

    private static function bcAuth(): void
    {
        $code = (string) ($_GET['code'] ?? '');
        $context = (string) ($_GET['context'] ?? '');
        if ($code === '' || ! preg_match('#^stores/([a-z0-9]+)$#', $context, $m)) {
            http_response_code(400);
            echo 'Missing install details. Please install the app again from your BigCommerce control panel.';

            return;
        }
        $r = \App\Http::json('POST', 'https://login.bigcommerce.com/oauth2/token', [], [
            'client_id' => Config::get('client_id'), 'client_secret' => Config::get('client_secret'), 'code' => $code, 'context' => $context,
            'scope' => (string) ($_GET['scope'] ?? ''), 'grant_type' => 'authorization_code', 'redirect_uri' => Config::get('app_url').'/bc/auth',
        ]);
        $j = $r['json'];
        if ($r['status'] !== 200 || empty($j['access_token']) || ($j['context'] ?? '') !== $context) {
            Log::error('bc auth failed', ['status' => $r['status']]);
            http_response_code(400);
            echo 'BigCommerce did not confirm the install. Please try again.';

            return;
        }
        $row = self::setup(Shops::install($m[1], $j['access_token'], (string) ($j['scope'] ?? '')));
        self::page('app', ['shop' => $row, 'appToken' => Crypto::appToken((int) $row['id'])]);
    }

    private static function bcLoad(): void
    {
        $c = self::bcClaims();
        $row = $c ? Shops::byShop($c['store_hash']) : null;
        if (! $row || $row['uninstalled_at']) {
            http_response_code(401);
            echo 'Please install the app again from your BigCommerce control panel.';

            return;
        }
        if (self::needsSetup($row)) {
            $row = self::setup($row);
        }
        self::page('app', ['shop' => $row, 'appToken' => Crypto::appToken((int) $row['id'])]);
    }

    private static function bcUninstall(): void
    {
        $c = self::bcClaims();
        $row = $c ? Shops::byShop($c['store_hash']) : null;
        if ($row) {
            Shops::forget((int) $row['id']);
        }
        self::ok();
    }

    /** Storefront script (added through BigCommerce Script Manager, "analytics" consent category). No cookies, nothing stored on the device. */
    private static function script(): void
    {
        header('Content-Type: application/javascript; charset=utf-8');
        header('Cache-Control: public, max-age=3600');
        $k = json_encode(preg_replace('/[^a-f0-9]/', '', (string) ($_GET['k'] ?? '')));
        $url = json_encode(Config::get('app_url').'/hit', JSON_UNESCAPED_SLASHES);
        echo <<<JS
(function(){try{if(navigator.doNotTrack==='1'||navigator.webdriver)return;var U={$url},K={$k};
function send(d){d=JSON.stringify(d);try{if(navigator.sendBeacon&&navigator.sendBeacon(U,new Blob([d],{type:'text/plain'})))return;}catch(e){}try{fetch(U,{method:'POST',body:d,keepalive:true,credentials:'omit'});}catch(e){}}
var tz='';try{tz=Intl.DateTimeFormat().resolvedOptions().timeZone||'';}catch(e){}
var pv=Math.random().toString(36).slice(2,12);
function pid(){var i=document.querySelector('form[data-cart-item-add] [name="product_id"]');return i?i.value:'';}
function go(){send({k:K,e:'page',u:location.href,r:document.referrer||'',t:(document.title||'').slice(0,120),w:window.screen?screen.width:0,l:navigator.language||'',z:tz,pv:pv,p:pid(),o:window.PI_ORDER||''});}
if(document.readyState==='complete'){go();}else{window.addEventListener('load',go);}
document.addEventListener('submit',function(e){var f=e.target;if(f&&f.matches&&f.matches('form[data-cart-item-add]')){var i=f.querySelector('[name="product_id"]'),q=f.querySelector('[name="qty[]"]');send({k:K,e:'cart',u:location.href,z:tz,p:i?i.value:'',q:q?parseInt(q.value,10)||1:1});}},true);
var shown=document.visibilityState==='visible'?Date.now():0,total=0;
function leave(){if(shown){total+=Date.now()-shown;shown=0;}var s=Math.round(total/1000);if(s>0){send({k:K,pv:pv,d:s});}}
document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden'){leave();}else if(!shown){shown=Date.now();}});
window.addEventListener('pagehide',leave);}catch(e){}})();
JS;
    }
}

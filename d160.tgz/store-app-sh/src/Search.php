<?php

declare(strict_types=1);

namespace App;

/**
 * Google Search Console (sign in with Google) and Bing Webmaster Tools (API key) for a store. Optional, read-only.
 * Google's app keys live in connect-config.php next to config.php (shared with the WordPress plugin's sign-in relay).
 * Tokens are kept encrypted in prefs; search data is cached for 6 hours and never leaves this server.
 */
final class Search
{
    private const GSC = 'https://www.googleapis.com/webmasters/v3/';
    private const BING = 'https://ssl.bing.com/webmaster/api.svc/json/';
    private const TOKEN = 'https://oauth2.googleapis.com/token';
    private const TTL = 21600;

    public static function conf(): array
    {
        static $c = null;
        if ($c === null) {
            $f = dirname(__DIR__).'/connect-config.php';
            $c = is_file($f) ? (array) require $f : [];
        }

        return $c;
    }

    /** API addresses (connect-config.php can point them elsewhere for testing). */
    private static function url(string $k, string $default): string
    {
        return (string) (self::conf()[$k] ?? $default);
    }

    public static function googleReady(): bool
    {
        return ! empty(self::conf()['google_client_id']) && ! empty(self::conf()['google_client_secret']);
    }

    private static function redirectUri(): string
    {
        return rtrim((string) Config::get('app_url'), '/').'/google/callback';
    }

    private static function pref(array $shop, string $k): string
    {
        return (string) (Shops::prefs((int) $shop['id'])[$k] ?? '');
    }

    public static function status(array $shop): array
    {
        $p = Shops::prefs((int) $shop['id']);

        return [
            'google_ready' => self::googleReady(),
            'google' => ($p['g_refresh'] ?? '') !== '',
            'google_email' => ($p['g_email'] ?? '') !== '' ? (string) Crypto::unseal((string) $p['g_email']) : '',
            'google_site' => (string) ($p['g_site'] ?? ''),
            'google_error' => (string) ($p['g_error'] ?? ''),
            'bing' => ($p['b_key'] ?? '') !== '',
            'bing_site' => (string) ($p['b_site'] ?? ''),
        ];
    }

    /** The store's addresses: primary domain and the myshopify one. */
    private static function hosts(array $shop): array
    {
        $h = [strtolower((string) $shop['shop'])];
        $d = (string) parse_url((string) ($shop['domain'] ?? ''), PHP_URL_HOST);
        if ($d !== '') {
            $h[] = strtolower($d);
        }

        return array_values(array_unique(array_map(fn ($x) => (string) preg_replace('/^www\./', '', $x), $h)));
    }

    // ---------------------------------------------------------------- Google sign-in (top-level window)

    /** Address the app opens in a new tab to start Google sign-in (signed, valid 15 minutes). */
    public static function startUrl(array $shop): string
    {
        return rtrim((string) Config::get('app_url'), '/').'/google/start?t='.rawurlencode(Crypto::appToken((int) $shop['id'], 900));
    }

    public static function start(string $t): ?string
    {
        $id = Crypto::checkAppToken($t);
        if (! $id || ! self::googleReady()) {
            return null;
        }

        return 'https://accounts.google.com/o/oauth2/v2/auth?'.http_build_query([
            'client_id' => self::conf()['google_client_id'],
            'redirect_uri' => self::redirectUri(),
            'response_type' => 'code',
            'scope' => 'openid email https://www.googleapis.com/auth/webmasters.readonly',
            'access_type' => 'offline',
            'prompt' => 'consent',
            'include_granted_scopes' => 'true',
            'state' => Crypto::appToken($id, 1800),
        ]);
    }

    /** Back from Google: store the refresh token for the shop in the signed state, pick the matching property. */
    public static function callback(array $q): string
    {
        $id = Crypto::checkAppToken((string) ($q['state'] ?? ''));
        $shop = $id ? Shops::find($id) : null;
        if (! $shop || ! empty($q['error']) || empty($q['code'])) {
            return 'Google sign-in was cancelled or has expired. Close this tab and try again from the app.';
        }
        $r = Http::request('POST', self::url('token_url', self::TOKEN), ['Content-Type' => 'application/x-www-form-urlencoded'], http_build_query([
            'code' => (string) $q['code'], 'client_id' => self::conf()['google_client_id'], 'client_secret' => self::conf()['google_client_secret'],
            'redirect_uri' => self::redirectUri(), 'grant_type' => 'authorization_code',
        ]), 20);
        $j = is_array($r['json']) ? $r['json'] : [];
        if ($r['status'] !== 200 || empty($j['refresh_token'])) {
            return 'Google did not finish the sign-in. Close this tab and try again from the app.';
        }
        $email = '';
        if (! empty($j['id_token'])) {
            $c = json_decode((string) Crypto::unb64(explode('.', (string) $j['id_token'])[1] ?? ''), true);
            $email = is_array($c) ? (string) ($c['email'] ?? '') : '';
        }
        $sid = (int) $shop['id'];
        Shops::setPref($sid, 'g_refresh', (string) Crypto::encrypt((string) $j['refresh_token']));
        Shops::setPref($sid, 'g_email', $email !== '' ? Crypto::seal($email) : '');
        Shops::setPref($sid, 'g_error', '');
        Shops::setPref($sid, 'g_site', '');
        Shops::put($sid, 'g_at', ['t' => (string) $j['access_token'], 'exp' => time() + (int) ($j['expires_in'] ?? 3600) - 120]);
        $sites = self::sites($shop);
        $pick = self::bestSite($shop, $sites);
        if ($pick !== '') {
            Shops::setPref($sid, 'g_site', $pick);

            return 'Google Search Console is connected ('.$pick.'). You can close this tab — the app updates by itself.';
        }

        return $sites ? 'Google is connected. Close this tab and choose your Search Console property in the app.'
            : 'Google is connected, but this Google account has no Search Console property for your store yet. Add and verify your store at search.google.com/search-console, then choose it in the app.';
    }

    private static function token(array $shop): string
    {
        $sid = (int) $shop['id'];
        $c = Shops::cachedValue($sid, 'g_at', 3600);
        if (is_array($c) && ($c['exp'] ?? 0) > time() && ! empty($c['t'])) {
            return (string) $c['t'];
        }
        $rt = (string) Crypto::decrypt(self::pref($shop, 'g_refresh'));
        if ($rt === '' || ! self::googleReady()) {
            return '';
        }
        $r = Http::request('POST', self::url('token_url', self::TOKEN), ['Content-Type' => 'application/x-www-form-urlencoded'], http_build_query([
            'refresh_token' => $rt, 'client_id' => self::conf()['google_client_id'], 'client_secret' => self::conf()['google_client_secret'], 'grant_type' => 'refresh_token',
        ]), 20);
        $j = is_array($r['json']) ? $r['json'] : [];
        if ($r['status'] !== 200 || empty($j['access_token'])) {
            if (($j['error'] ?? '') === 'invalid_grant') {
                Shops::setPref($sid, 'g_error', 'revoked');
            }

            return '';
        }
        Shops::put($sid, 'g_at', ['t' => (string) $j['access_token'], 'exp' => time() + (int) ($j['expires_in'] ?? 3600) - 120]);

        return (string) $j['access_token'];
    }

    private static function google(array $shop, string $url, ?array $body = null): ?array
    {
        $t = self::token($shop);
        if ($t === '') {
            return null;
        }
        $r = $body === null ? Http::request('GET', $url, ['Authorization' => 'Bearer '.$t], null, 20) : Http::json('POST', $url, ['Authorization' => 'Bearer '.$t], $body);
        if ($r['status'] === 403) {
            Shops::setPref((int) $shop['id'], 'g_error', 'no_access');
        }

        return $r['status'] === 200 && is_array($r['json']) ? $r['json'] : null;
    }

    public static function sites(array $shop): array
    {
        $out = [];
        foreach ((array) (self::google($shop, self::url('gsc_url', self::GSC).'sites')['siteEntry'] ?? []) as $s) {
            if (($s['permissionLevel'] ?? '') !== 'siteUnverifiedUser' && ! empty($s['siteUrl'])) {
                $out[] = (string) $s['siteUrl'];
            }
        }

        return $out;
    }

    public static function bestSite(array $shop, array $sites): string
    {
        foreach (self::hosts($shop) as $h) {
            foreach (['https://'.$h.'/', 'https://www.'.$h.'/', 'sc-domain:'.$h] as $want) {
                if (in_array($want, $sites, true)) {
                    return $want;
                }
            }
        }

        return '';
    }

    // ---------------------------------------------------------------- settings from the app

    /** Choose the Google property and / or save a Bing key. Returns an error text or null. */
    public static function save(array $shop, array $in): ?string
    {
        $sid = (int) $shop['id'];
        if (isset($in['g_site'])) {
            $want = (string) $in['g_site'];
            if (! in_array($want, self::sites($shop), true)) {
                return 'That Search Console property is not available for this Google account.';
            }
            Shops::setPref($sid, 'g_site', $want);
            Shops::setPref($sid, 'g_error', '');
        }
        $key = (string) preg_replace('/[^A-Za-z0-9]/', '', (string) ($in['b_key'] ?? ''));
        if ($key !== '') {
            $sites = self::bing('GetUserSites', [], $key);
            if ($sites === null) {
                return 'Bing did not accept that API key. Copy it again from Bing Webmaster Tools → Settings → API access.';
            }
            $pick = '';
            foreach ($sites as $s) {
                $h = (string) preg_replace('/^www\./', '', strtolower((string) parse_url((string) ($s['Url'] ?? ''), PHP_URL_HOST)));
                if (! empty($s['IsVerified']) && in_array($h, self::hosts($shop), true)) {
                    $pick = (string) $s['Url'];
                    break;
                }
            }
            if ($pick === '') {
                return 'The key works, but your store is not verified in that Bing Webmaster Tools account. Add it there (you can import it from Google Search Console), then save again.';
            }
            Shops::setPref($sid, 'b_key', (string) Crypto::encrypt($key));
            Shops::setPref($sid, 'b_site', $pick);
        }
        Shops::put($sid, 'search_gen', time());

        return null;
    }

    public static function disconnect(array $shop, string $which): void
    {
        $sid = (int) $shop['id'];
        if ($which === 'google') {
            $rt = (string) Crypto::decrypt(self::pref($shop, 'g_refresh'));
            if ($rt !== '') {
                Http::request('POST', 'https://oauth2.googleapis.com/revoke', ['Content-Type' => 'application/x-www-form-urlencoded'], http_build_query(['token' => $rt]), 10);
            }
            foreach (['g_refresh', 'g_email', 'g_site', 'g_error'] as $k) {
                Shops::setPref($sid, $k, '');
            }
            Shops::put($sid, 'g_at', []);
        } elseif ($which === 'bing') {
            Shops::setPref($sid, 'b_key', '');
            Shops::setPref($sid, 'b_site', '');
        }
        Shops::put($sid, 'search_gen', time());
    }

    // ---------------------------------------------------------------- data

    private static function gen(array $shop): string
    {
        return (string) (Shops::cachedValue((int) $shop['id'], 'search_gen', 86400 * 3650) ?? 0);
    }

    /** @return array<int, array{keys: array, clicks: int, impressions: int, ctr: float, position: float}>|null */
    public static function gsc(array $shop, string $since, string $until, array $dims, int $limit = 100, string $page = ''): ?array
    {
        $site = self::pref($shop, 'g_site');
        if ($site === '' || self::pref($shop, 'g_refresh') === '') {
            return null;
        }
        $key = 'gsc:'.substr(md5(self::gen($shop).'|'.$site.'|'.$since.'|'.$until.'|'.implode(',', $dims).'|'.$limit.'|'.$page), 0, 20);
        $hit = Shops::cachedValue((int) $shop['id'], $key, self::TTL);
        if (is_array($hit)) {
            return $hit;
        }
        $body = ['startDate' => $since, 'endDate' => $until, 'dimensions' => $dims, 'rowLimit' => $limit, 'dataState' => 'all'];
        if ($page !== '') {
            $body['dimensionFilterGroups'] = [['filters' => [['dimension' => 'page', 'operator' => 'equals', 'expression' => $page]]]];
        }
        $j = self::google($shop, self::url('gsc_url', self::GSC).'sites/'.rawurlencode($site).'/searchAnalytics/query', $body);
        if ($j === null) {
            return null;
        }
        $rows = array_map(fn ($r) => ['keys' => (array) ($r['keys'] ?? []), 'clicks' => (int) ($r['clicks'] ?? 0), 'impressions' => (int) ($r['impressions'] ?? 0),
            'ctr' => round((float) ($r['ctr'] ?? 0) * 100, 2), 'position' => round((float) ($r['position'] ?? 0), 1)], (array) ($j['rows'] ?? []));
        Shops::put((int) $shop['id'], $key, $rows);

        return $rows;
    }

    private static function bing(string $method, array $args = [], string $key = '', ?array $shop = null): ?array
    {
        $key = $key !== '' ? $key : ($shop ? (string) Crypto::decrypt(self::pref($shop, 'b_key')) : '');
        if ($key === '') {
            return null;
        }
        $r = Http::request('GET', self::url('bing_url', self::BING).$method.'?'.http_build_query($args + ['apikey' => $key]), [], null, 20);

        return $r['status'] === 200 && is_array($r['json']) && isset($r['json']['d']) ? (array) $r['json']['d'] : null;
    }

    private static function bingDay(string $d, string $tz): string
    {
        if (! preg_match('/Date\((-?\d+)/', $d, $m)) {
            return '';
        }

        return (new \DateTimeImmutable('@'.intdiv((int) $m[1], 1000)))->setTimezone(new \DateTimeZone($tz ?: 'UTC'))->format('Y-m-d');
    }

    public static function bingReport(array $shop, string $since, string $until): ?array
    {
        $site = self::pref($shop, 'b_site');
        if ($site === '' || self::pref($shop, 'b_key') === '') {
            return null;
        }
        $key = 'bing:'.substr(md5(self::gen($shop).'|'.$site.'|'.$since.'|'.$until), 0, 20);
        $hit = Shops::cachedValue((int) $shop['id'], $key, self::TTL);
        if (is_array($hit)) {
            return $hit;
        }
        $tz = (string) ($shop['timezone'] ?? 'UTC');
        $traffic = self::bing('GetRankAndTrafficStats', ['siteUrl' => $site], '', $shop);
        if ($traffic === null) {
            return null;
        }
        $days = [];
        foreach ($traffic as $r) {
            $d = self::bingDay((string) ($r['Date'] ?? ''), $tz);
            if ($d >= $since && $d <= $until) {
                $days[$d] = ['clicks' => (int) ($r['Clicks'] ?? 0), 'impressions' => (int) ($r['Impressions'] ?? 0)];
            }
        }
        ksort($days);
        $from = (new \DateTimeImmutable($since))->modify('-6 days')->format('Y-m-d');
        $group = function (?array $rows) use ($from, $until, $tz) {
            $agg = [];
            foreach ((array) $rows as $r) {
                $d = self::bingDay((string) ($r['Date'] ?? ''), $tz);
                $k = (string) ($r['Query'] ?? '');
                if ($k === '' || $d < $from || $d > $until) {
                    continue;
                }
                $agg[$k] ??= ['keys' => [$k], 'clicks' => 0, 'impressions' => 0, 'pos' => 0.0];
                $agg[$k]['clicks'] += (int) ($r['Clicks'] ?? 0);
                $agg[$k]['impressions'] += (int) ($r['Impressions'] ?? 0);
                $agg[$k]['pos'] += (float) ($r['AvgImpressionPosition'] ?? 0) * max(1, (int) ($r['Impressions'] ?? 0));
            }
            $out = [];
            foreach ($agg as $a) {
                $out[] = ['keys' => $a['keys'], 'clicks' => $a['clicks'], 'impressions' => $a['impressions'],
                    'ctr' => $a['impressions'] ? round($a['clicks'] / $a['impressions'] * 100, 2) : 0, 'position' => $a['impressions'] ? round($a['pos'] / $a['impressions'], 1) : 0];
            }
            usort($out, fn ($x, $y) => [$y['clicks'], $y['impressions']] <=> [$x['clicks'], $x['impressions']]);

            return array_slice($out, 0, 100);
        };
        $out = ['days' => $days, 'queries' => $group(self::bing('GetQueryStats', ['siteUrl' => $site], '', $shop)), 'pages' => $group(self::bing('GetPageStats', ['siteUrl' => $site], '', $shop))];
        Shops::put((int) $shop['id'], $key, $out);

        return $out;
    }

    public static function totals(array $rows): array
    {
        $c = $i = 0;
        $p = 0.0;
        foreach ($rows as $r) {
            $c += $r['clicks'];
            $i += $r['impressions'];
            $p += $r['position'] * $r['impressions'];
        }

        return ['clicks' => $c, 'impressions' => $i, 'ctr' => $i ? round($c / $i * 100, 2) : null, 'position' => $i ? round($p / $i, 1) : null];
    }

    /** Path of a search result address on this store ('' for other sites). */
    public static function pathOf(array $shop, string $url): string
    {
        $h = (string) preg_replace('/^www\./', '', strtolower((string) parse_url($url, PHP_URL_HOST)));
        if (! in_array($h, self::hosts($shop), true)) {
            return '';
        }

        return Tracker::path((string) (parse_url($url, PHP_URL_PATH) ?: '/'));
    }

    /** Everything the Search tab shows: Google and Bing next to this store's visitors, orders and sales per page. */
    public static function report(array $shop, Insights $ins): array
    {
        [$a, $b] = $ins->range();
        [$pa, $pb] = $ins->prevRange();
        $st = self::status($shop);
        $out = ['status' => $st, 'google' => null, 'bing' => null];
        if (! $st['google'] && ! $st['bing']) {
            return $out;
        }
        $pages = [];
        foreach (($ins->pages()['pages'] ?? []) as $p) {
            $pages[$p['path']] = $p;
        }
        $prods = [];
        foreach (($ins->products()['products'] ?? []) as $p) {
            $prods[$p['path']] = $p;
        }
        $join = function (array $rows) use ($shop, $pages, $prods) {
            $o = [];
            foreach (array_slice($rows, 0, 30) as $r) {
                $path = self::pathOf($shop, (string) $r['keys'][0]);
                $pg = $pages[$path] ?? null;
                $pr = $prods[$path] ?? null;
                $o[] = $r + ['url' => (string) $r['keys'][0], 'path' => $path, 'title' => $pg['title'] ?? $pr['title'] ?? ($path ?: $r['keys'][0]),
                    'visitors' => $pg['visitors'] ?? $pr['visitors'] ?? null, 'orders' => $pr['orders'] ?? null, 'sales' => $pr['sales'] ?? null];
            }

            return $o;
        };
        if ($st['google'] && $st['google_site'] !== '') {
            $days = self::gsc($shop, $a, $b, ['date'], 500);
            if ($days !== null) {
                $prev = self::gsc($shop, $pa, $pb, ['date'], 500) ?? [];
                $out['google'] = ['totals' => self::totals($days), 'prev' => self::totals($prev),
                    'daily' => array_map(fn ($r) => ['day' => $r['keys'][0], 'clicks' => $r['clicks']], $days),
                    'queries' => self::gsc($shop, $a, $b, ['query'], 250) ?? [], 'pages' => $join(self::gsc($shop, $a, $b, ['page'], 100) ?? [])];
            } else {
                $out['google'] = ['error' => true];
            }
        }
        if ($st['bing']) {
            $r = self::bingReport($shop, $a, $b);
            if ($r !== null) {
                $c = array_sum(array_column($r['days'], 'clicks'));
                $i = array_sum(array_column($r['days'], 'impressions'));
                $out['bing'] = ['totals' => ['clicks' => $c, 'impressions' => $i, 'ctr' => $i ? round($c / $i * 100, 2) : null],
                    'daily' => array_map(fn ($d, $v) => ['day' => $d, 'clicks' => $v['clicks']], array_keys($r['days']), $r['days']),
                    'queries' => $r['queries'], 'pages' => $join($r['pages'])];
            } else {
                $out['bing'] = ['error' => true];
            }
        }

        return $out;
    }
}

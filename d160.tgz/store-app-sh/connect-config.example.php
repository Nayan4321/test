<?php
/**
 * Copy to  ~/store-app-sh/connect-config.php  (next to config.php, NOT inside public/) and fill in.
 * Google Cloud → APIs & Services → Credentials → OAuth client ID (type: Web application)
 *   Authorised redirect URIs:  https://sh.laghavi.site/connect/callback.php  (WordPress plugin)
 *                              https://sh.laghavi.site/google/callback       (Shopify app)
 * state_key: any random 64 characters (e.g. run:  php -r "echo bin2hex(random_bytes(32));").
 */
return array(
	'google_client_id'     => '',
	'google_client_secret' => '',
	'state_key'            => '',
);

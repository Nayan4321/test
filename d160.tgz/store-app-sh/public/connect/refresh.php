<?php
/** A store swaps its refresh token for a new access token (Google needs the client secret for this). Nothing is kept. */
declare(strict_types=1);
require __DIR__ . '/lib.php';

if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
	lc_json( 405, array( 'error' => 'post_only' ) );
}
if ( ! lc_ready() ) {
	lc_json( 503, array( 'error' => 'not_ready' ) );
}
$in = json_decode( (string) file_get_contents( 'php://input' ), true );
$rt = is_array( $in ) ? (string) ( $in['refresh_token'] ?? '' ) : '';
if ( '' === $rt || strlen( $rt ) > 512 ) {
	lc_json( 400, array( 'error' => 'missing' ) );
}
list( $code, $tok ) = lc_post(
	(string) ( lc_conf()['token_url'] ?? LC_TOKEN ),
	array(
		'refresh_token' => $rt,
		'client_id'     => lc_conf()['google_client_id'],
		'client_secret' => lc_conf()['google_client_secret'],
		'grant_type'    => 'refresh_token',
	)
);
if ( 200 !== $code || empty( $tok['access_token'] ) ) {
	// invalid_grant = the owner removed access in their Google account: the store shows "reconnect".
	lc_json( 400 === $code ? 400 : 502, array( 'error' => (string) ( $tok['error'] ?? 'refresh_failed' ) ) );
}
lc_json(
	200,
	array(
		'access_token' => $tok['access_token'],
		'expires_in'   => (int) ( $tok['expires_in'] ?? 3600 ),
	)
);

<?php
/** Step 2: Google sends the owner back here with a one-time code. We swap it for tokens and return them sealed. */
declare(strict_types=1);
require __DIR__ . '/lib.php';

if ( ! lc_ready() ) {
	lc_page( 'Not available yet', 'Google sign-in is not switched on yet.' );
}
$st = lc_verify( (string) ( $_GET['state'] ?? '' ) );
if ( ! $st ) {
	lc_page( 'This link has expired', 'Please start again from your store\'s admin screen.' );
}
$back = (string) $st['b'];
$sep  = false === strpos( $back, '?' ) ? '?' : '&';
if ( ! empty( $_GET['error'] ) || empty( $_GET['code'] ) ) {
	header( 'Location: ' . $back . $sep . http_build_query( array( 'lgpi_gerr' => substr( preg_replace( '/[^a-z_]/', '', (string) ( $_GET['error'] ?? 'cancelled' ) ), 0, 40 ) ) ), true, 302 );
	exit;
}
list( $code, $tok ) = lc_post(
	(string) ( lc_conf()['token_url'] ?? LC_TOKEN ),
	array(
		'code'          => (string) $_GET['code'],
		'client_id'     => lc_conf()['google_client_id'],
		'client_secret' => lc_conf()['google_client_secret'],
		'redirect_uri'  => lc_redirect_uri(),
		'grant_type'    => 'authorization_code',
	)
);
if ( 200 !== $code || empty( $tok['access_token'] ) ) {
	header( 'Location: ' . $back . $sep . http_build_query( array( 'lgpi_gerr' => 'exchange_failed' ) ), true, 302 );
	exit;
}
$email = '';
if ( ! empty( $tok['id_token'] ) ) {
	$p     = explode( '.', (string) $tok['id_token'] );
	$claim = isset( $p[1] ) ? json_decode( lc_unb64u( $p[1] ), true ) : null;
	$email = is_array( $claim ) ? (string) ( $claim['email'] ?? '' ) : '';
}
$payload = json_encode(
	array(
		'n'             => $st['n'],
		'access_token'  => $tok['access_token'],
		'refresh_token' => $tok['refresh_token'] ?? '',
		'expires_in'    => (int) ( $tok['expires_in'] ?? 3600 ),
		'scope'         => (string) ( $tok['scope'] ?? '' ),
		'email'         => $email,
	)
);
// Sealed with the store's one-time public key: only the admin session that started this can open it.
$sealed = sodium_crypto_box_seal( (string) $payload, lc_unb64u( (string) $st['k'] ) );
header( 'Cache-Control: no-store' );
header( 'Location: ' . $back . $sep . http_build_query( array( 'lgpi_sealed' => lc_b64u( $sealed ) ) ), true, 302 );

<?php
/** Step 1: the store's admin screen sends the owner here; we send them on to Google's consent screen. */
declare(strict_types=1);
require __DIR__ . '/lib.php';

if ( ! lc_ready() ) {
	lc_page( 'Not available yet', 'Google sign-in is not switched on yet. Please try again later.' );
}
$site  = (string) ( $_GET['site'] ?? '' );
$back  = (string) ( $_GET['back'] ?? '' );
$pk    = lc_unb64u( (string) ( $_GET['pk'] ?? '' ) );
$nonce = preg_replace( '/[^A-Za-z0-9]/', '', (string) ( $_GET['n'] ?? '' ) );
$want  = array_values( array_intersect( array_keys( LC_SCOPES ), explode( ',', (string) ( $_GET['scopes'] ?? 'gsc' ) ) ) );
if ( ! lc_back_ok( $back, $site ) || 32 !== strlen( $pk ) || strlen( $nonce ) < 16 || ! $want ) {
	lc_page( 'Something is missing', 'Please start again from your store\'s admin screen.' );
}
$scopes = array( 'openid', 'email' );
foreach ( $want as $w ) {
	$scopes[] = LC_SCOPES[ $w ];
}
$state = lc_sign(
	array(
		'b' => $back,
		'k' => lc_b64u( $pk ),
		'n' => $nonce,
		't' => time(),
	)
);
header( 'Cache-Control: no-store' );
header(
	'Location: ' . LC_AUTH . '?' . http_build_query(
		array(
			'client_id'              => lc_conf()['google_client_id'],
			'redirect_uri'           => lc_redirect_uri(),
			'response_type'          => 'code',
			'scope'                  => implode( ' ', $scopes ),
			'access_type'            => 'offline',
			'prompt'                 => 'consent',
			'include_granted_scopes' => 'true',
			'state'                  => $state,
		)
	),
	true,
	302
);

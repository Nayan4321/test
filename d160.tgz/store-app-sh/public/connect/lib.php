<?php
/**
 * Laghavi Connect — sign-in relay for Performance Insight (WordPress plugin and store apps).
 *
 * Holds the Google OAuth client secret so that each store does not need its own Google Cloud project
 * (the same pattern Site Kit and MonsterInsights use). It only:
 *   start.php    → sends the store owner to Google's consent screen,
 *   callback.php → swaps Google's one-time code for tokens and hands them back to the store, sealed with
 *                  a one-time public key that only that store's admin session can open,
 *   refresh.php  → turns a refresh token into a short-lived access token (needs the client secret).
 * Nothing is stored here: no tokens, no report data. Reports are read by the store directly from Google.
 */
declare(strict_types=1);

const LC_AUTH   = 'https://accounts.google.com/o/oauth2/v2/auth';
const LC_TOKEN  = 'https://oauth2.googleapis.com/token';
const LC_SCOPES = array(
	'gsc' => 'https://www.googleapis.com/auth/webmasters.readonly',
	'ga'  => 'https://www.googleapis.com/auth/analytics.readonly',
);

function lc_conf(): array {
	static $c = null;
	if ( null === $c ) {
		// Kept outside the public folder; never in a zip. Keys: google_client_id, google_client_secret, state_key.
		$f = dirname( __DIR__, 2 ) . '/connect-config.php';
		$c = is_file( $f ) ? (array) require $f : array();
	}
	return $c;
}

function lc_ready(): bool {
	$c = lc_conf();
	return ! empty( $c['google_client_id'] ) && ! empty( $c['google_client_secret'] ) && strlen( (string) ( $c['state_key'] ?? '' ) ) >= 32;
}

function lc_b64u( string $s ): string {
	return rtrim( strtr( base64_encode( $s ), '+/', '-_' ), '=' );
}

function lc_unb64u( string $s ): string {
	return (string) base64_decode( strtr( $s, '-_', '+/' ) . str_repeat( '=', ( 4 - strlen( $s ) % 4 ) % 4 ), true );
}

function lc_redirect_uri(): string {
	$c = lc_conf();
	return (string) ( $c['redirect_uri'] ?? 'https://' . ( $_SERVER['HTTP_HOST'] ?? 'sh.laghavi.site' ) . '/connect/callback.php' );
}

function lc_sign( array $data ): string {
	$p = lc_b64u( (string) json_encode( $data ) );
	return $p . '.' . lc_b64u( hash_hmac( 'sha256', $p, (string) lc_conf()['state_key'], true ) );
}

function lc_verify( string $state ): ?array {
	$parts = explode( '.', $state );
	if ( 2 !== count( $parts ) ) {
		return null;
	}
	$want = lc_b64u( hash_hmac( 'sha256', $parts[0], (string) lc_conf()['state_key'], true ) );
	if ( ! hash_equals( $want, $parts[1] ) ) {
		return null;
	}
	$d = json_decode( lc_unb64u( $parts[0] ), true );
	return is_array( $d ) && ( $d['t'] ?? 0 ) > time() - 1800 ? $d : null;
}

/** A return address must be https (or http on localhost) and point at the site that asked. */
function lc_back_ok( string $back, string $site ): bool {
	$b = parse_url( $back );
	$s = parse_url( $site );
	if ( ! $b || ! $s || empty( $b['host'] ) || empty( $s['host'] ) ) {
		return false;
	}
	$local = in_array( $b['host'], array( 'localhost', '127.0.0.1' ), true ) || str_ends_with( $b['host'], '.local' ) || str_ends_with( $b['host'], '.test' );
	if ( 'https' !== ( $b['scheme'] ?? '' ) && ! ( $local && 'http' === ( $b['scheme'] ?? '' ) ) ) {
		return false;
	}
	$strip = fn( $h ) => preg_replace( '/^www\./', '', strtolower( (string) $h ) );
	return $strip( $b['host'] ) === $strip( $s['host'] );
}

function lc_post( string $url, array $fields ): array {
	$ch = curl_init( $url );
	curl_setopt_array(
		$ch,
		array(
			CURLOPT_POST           => true,
			CURLOPT_POSTFIELDS     => http_build_query( $fields ),
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_TIMEOUT        => 20,
			CURLOPT_HTTPHEADER     => array( 'Accept: application/json' ),
		)
	);
	$body = (string) curl_exec( $ch );
	$code = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
	curl_close( $ch );
	$j = json_decode( $body, true );
	return array( $code, is_array( $j ) ? $j : array() );
}

function lc_json( int $code, array $data ): void {
	http_response_code( $code );
	header( 'Content-Type: application/json' );
	header( 'Cache-Control: no-store' );
	echo json_encode( $data );
	exit;
}

function lc_page( string $title, string $text ): void {
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'Cache-Control: no-store' );
	echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . htmlspecialchars( $title ) . '</title>'
		. '<body style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:520px;margin:12vh auto;padding:0 20px;color:#1d2327">'
		. '<h1 style="font-size:22px">' . htmlspecialchars( $title ) . '</h1><p>' . htmlspecialchars( $text ) . '</p></body>';
	exit;
}

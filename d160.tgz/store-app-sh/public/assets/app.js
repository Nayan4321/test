/* Performance Insight — app screens. All data comes from /api/* with a signed token for this shop. */
(function () {
  'use strict';
  var PI = window.PI || {};
  var main = document.getElementById('main');
  var cache = {};
  var seq = 0;          // only the latest screen request may draw (a slow tab never overwrites the one you clicked)
  var current = 'overview';
  var timer = null;     // real-time refresh
  var range = { r: '7d', from: '', to: '' };
  var journeyFilter = '';
  var warnings = [];   // parts the store would not give us on the last request
  var SHOP = PI.platform === 'shopify';

  // ------------------------------------------------------------ helpers
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(n) { return Number(n || 0).toLocaleString(); }
  function money(n) {
    try { return Number(n || 0).toLocaleString(undefined, { style: 'currency', currency: PI.currency || 'USD', maximumFractionDigits: 2 }); }
    catch (e) { return num(n); }
  }
  function pct(n, d) { return n == null ? '–' : Number(n).toFixed(d == null ? 2 : d) + '%'; }
  function dur(s) {
    if (s == null) { return '–'; }
    s = Math.round(s);
    if (s < 60) { return s + 's'; }
    if (s < 3600) { return Math.floor(s / 60) + 'm ' + (s % 60 ? (s % 60) + 's' : ''); }
    return Math.floor(s / 3600) + 'h ' + Math.floor((s % 3600) / 60) + 'm';
  }
  function ago(s) { return s < 60 ? 'just now' : (s < 3600 ? Math.floor(s / 60) + ' min ago' : dur(s) + ' ago'); }
  function when(ts) {
    var d = new Date(ts * 1000);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
  }
  function score(s) { if (s == null) return '<span class="muted">–</span>'; var c = s >= 80 ? 'hi' : (s >= 55 ? 'mid' : 'lo'); return '<span class="score ' + c + '">' + s + '</span>'; }
  function flag(cc) { if (!/^[A-Z]{2}$/.test(cc || '')) return ''; return String.fromCodePoint(0x1F1E6 + cc.charCodeAt(0) - 65, 0x1F1E6 + cc.charCodeAt(1) - 65); }
  function country(cc) { if (!/^[A-Z]{2}$/.test(cc || '')) return 'Unknown'; try { return new Intl.DisplayNames(['en'], { type: 'region' }).of(cc); } catch (e) { return cc; } }
  function language(l) { if (!l || l === '??') return 'Unknown'; try { return new Intl.DisplayNames(['en'], { type: 'language' }).of(l); } catch (e) { return l; } }

  var TYPES = { product: 'Product', page: 'Page', post: 'Blog post', category: SHOP ? 'Collection' : 'Category', home: 'Home', search: 'Search', checkout: 'Cart / checkout', account: 'Account', other: 'Page' };
  var KINDS = { physical: 'Physical', digital: 'Digital', subscription: 'Subscription' };
  var SOURCES = { search: 'Search engines', social: 'Social media', ai: 'AI assistants', paid: 'Paid ads', direct: 'Direct', referral: 'Other websites', email: 'Email', checkout: 'Shopify checkout' };
  var DEVICES = { mobile: 'Mobile', tablet: 'Tablet', desktop: 'Desktop' };
  var WHY = {
    'SEO title is short': 'The title is the blue link in Google. A short one wastes the space that wins the click.',
    'SEO title is long': 'Google cuts titles after about 60 characters, so the end is hidden.',
    'No meta description': 'Google picks random text from the page for the search result.',
    'Meta description length': 'The text under the link works best at 70–160 characters.',
    'Very little text': 'Search engines and shoppers need words to understand what the page offers.',
    'Thin content': 'Pages that rank usually answer the shopper’s questions fully.',
    'Few product images': 'Shoppers want to see the product from several angles, in use and up close.',
    'Images without alt text': 'Alt text lets Google Images understand the photo and helps screen readers.',
    'No video': 'A short video of the product in use often lifts sales.',
    'No subheadings': 'Subheadings make long pages easy to scan.',
    'No images': 'Posts with images keep readers on the page longer.'
  };

  function token() {
    if (SHOP && window.shopify && shopify.idToken) { return shopify.idToken(); }
    return Promise.resolve(PI.appToken);
  }

  function qs() {
    var q = 'r=' + encodeURIComponent(range.r);
    if (range.r === 'custom') { q += '&from=' + encodeURIComponent(range.from) + '&to=' + encodeURIComponent(range.to); }
    return q;
  }

  function api(what, fresh) {
    var url = '/api/' + what + (what.indexOf('?') >= 0 ? '&' : '?') + qs();
    if (cache[url] && !fresh) { warnings = cache[url].cut ? ['__cut__' + cache[url].cut + '|' + cache[url].range[0]] : []; return Promise.resolve(cache[url]); }
    return token().then(function (t) {
      return fetch(url, { headers: { Authorization: 'Bearer ' + t } });
    }).then(function (r) {
      return r.json().then(function (j) {
        if (!r.ok) { throw new Error(j.error || 'Could not load.'); }
        warnings = j.warnings || [];
        if (j.cut) { warnings = warnings.concat(['__cut__' + j.cut + '|' + j.range[0]]); }
        if (!(j.warnings || []).length) { cache[url] = j; }
        return j;
      });
    });
  }

  function more(text) {
    if (!PI.upsell) { return ''; }
    return '<div class="more"><span>' + esc(text) + '</span><a href="' + esc(PI.upsell) + '" target="_blank" rel="noopener">Get Laghavi Ads Hub →</a></div>';
  }

  var PAID = PI.plan === 'plus' || PI.plan === 'pro';
  var PRICE = { plus: '$9.90', pro: '$85' };
  function upgradeBtn(label) {
    if (!PI.pricing) { return ''; }
    return '<a class="btn primary" href="' + esc(PI.pricing) + '" target="_top">' + esc(label || 'See plans') + '</a>';
  }
  /** The asked-for period went further back than the Free plan shows. */
  function cutPlanNote(j) {
    if (!j || !j.cut) { return ''; }
    return '<div class="note plan">The Free plan shows the last ' + j.cut + ' days, so this view starts on ' + esc(j.range[0]) + '. Plus shows 13 months, with profit per product, customers, a weekly email report and alerts, for ' + PRICE.plus + ' a month. ' + upgradeBtn('Upgrade to Plus') + '</div>';
  }

  function locked(title, what, plan) {
    return '<h2>' + esc(title) + ' <span class="pill">' + esc(plan === 'pro' ? 'Pro' : 'Plus') + '</span></h2><div class="card lockcard"><p>' + what + '</p><div class="tools left">' + upgradeBtn('Upgrade to ' + (plan === 'pro' ? 'Pro' : 'Plus') + ' — 7 days free') + '</div></div>';
  }
  /** Pro: the store's own Laghavi dashboard (ads next to sales). Shown in the app; billed by Shopify like every plan. */
  function proCard() {
    if (!SHOP || PI.plan === 'pro') { return ''; }
    return '<div class="card procard"><div><h3>Which ad made this money? <span class="pill">Pro</span></h3><p>See your Meta, Google and TikTok ad spend next to these sales: ROAS and profit per campaign and ad, which ads to scale or pause, plus CRM, automations and WhatsApp — in your own Laghavi dashboard.</p></div>' + upgradeBtn('See Pro') + '</div>';
  }

  var tableId = 0;
  /** Sortable table with a CSV download. */
  function table(head, rows, empty, name) {
    if (!rows.length) { return '<p class="empty">' + esc(empty) + '</p>'; }
    var id = 't' + (++tableId);
    return '<div class="tw"><table class="sort" id="' + id + '" data-name="' + esc(name || 'report') + '"><thead><tr>' + head.map(function (h) { return '<th' + (h[1] ? ' class="n"' : '') + '>' + esc(h[0]) + '</th>'; }).join('') +
      '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div><div class="tools"><button class="link csv" data-t="' + id + '">Download CSV</button></div>';
  }

  function itemLink(title, path, url) {
    var t = path ? '<a href="#" class="open" data-path="' + esc(path) + '">' + esc(title) + '</a>' : esc(title);
    return t + (url ? ' <a class="ext" href="' + esc(url) + '" target="_blank" rel="noopener" title="Open the live page">↗</a>' : '');
  }

  function bars(obj, labels, total) {
    var keys = Object.keys(obj).filter(function (k) { return obj[k] > 0; });
    var sum = total || keys.reduce(function (a, k) { return a + (obj[k] || 0); }, 0);
    if (!sum) { return '<p class="empty">No visits yet.</p>'; }
    return '<div class="bars">' + keys.sort(function (a, b) { return obj[b] - obj[a]; }).map(function (k) {
      var p = Math.round(obj[k] / sum * 100);
      var label = typeof labels === 'function' ? labels(k) : (labels[k] || k);
      return '<div class="br"><span title="' + esc(label) + '">' + esc(label) + '</span><span class="bt"><i style="width:' + p + '%"></i></span><span class="bv">' + num(obj[k]) + ' <em>' + p + '%</em></span></div>';
    }).join('') + '</div>';
  }

  /** Change vs the period before: ▲ 12% (green when it is good). */
  function delta(cur, prev, lowerIsBetter) {
    if (prev == null || cur == null) { return '<span class="dl muted">no earlier data</span>'; }
    if (!prev) { return cur ? '<span class="dl muted">new</span>' : '<span class="dl muted">no change</span>'; }
    var d = (cur - prev) / prev * 100;
    if (Math.abs(d) < 0.5) { return '<span class="dl muted">no change</span>'; }
    var good = lowerIsBetter ? d < 0 : d > 0;
    return '<span class="dl ' + (good ? 'up' : 'down') + '" title="vs the period before">' + (d > 0 ? '▲' : '▼') + ' ' + Math.abs(d).toFixed(0) + '%</span>';
  }

  function kpi(label, value, sub, d) {
    return '<div class="kpi"><div class="l">' + esc(label) + '</div><div class="v">' + value + '</div>' + (d ? '<div class="d">' + d + '</div>' : '') + (sub ? '<div class="s">' + sub + '</div>' : '') + '</div>';
  }

  /** Simple column chart, one series. */
  function columns(points, fmt, label) {
    if (!points.length) { return ''; }
    var max = Math.max.apply(null, points.map(function (p) { return p.v; }).concat([1]));
    var every = Math.ceil(points.length / 12);
    return '<div class="cols" role="img" aria-label="' + esc(label) + '">' + points.map(function (p, i) {
      return '<div class="col" title="' + esc(p.l + ': ' + fmt(p.v)) + '"><b style="height:' + Math.max(1, Math.round(p.v / max * 100)) + '%"></b><span>' + (i % every === 0 ? esc(p.s) : '') + '</span></div>';
    }).join('') + '</div>';
  }

  function trackingNote() {
    if (PI.tracking) { return ''; }
    return '<div class="note warn">Visit counting is being switched on. If visitors stay at 0 after a day, open the Help tab.</div>';
  }

  /** Visits exist only from the day the app was installed; orders and products come with their history. */
  function sinceNote(j) {
    if (!j.since || j.range[0] >= j.since) { return ''; }
    if (j.history && j.range[0] <= j.history[1]) {
      return '<div class="note">Visits before ' + esc(j.since) + ' are imported from Shopify Analytics. Real time and time per page start on ' + esc(j.since) + ', when the app started counting; journeys before that come from Shopify’s order and checkout records.</div>';
    }
    return '<div class="note">Orders, sales, products, stock and discount codes include your store’s history' + (SHOP ? ' (orders of the last 60 days); journeys before ' + esc(j.since) + ' come from Shopify’s order and checkout records' : '') + '. Visits are counted from ' + esc(j.since) + '.</div>';
  }

  function cutNote(d) {
    if (!d) { return ''; }
    return '<div class="note">Shopify shares orders of the last 60 days with apps, so orders before ' + esc(d) + ' are not included. Visits are kept for 400 days.</div>';
  }

  function srcName(src, ref) {
    var s = SOURCES[src] || src;
    return ref ? esc(ref) + ' <span class="type">' + esc(s) + '</span>' : esc(s);
  }

  function rangeText(j) { return esc(j.range[0] === j.range[1] ? j.range[0] : j.range[0] + ' – ' + j.range[1]); }

  function head(title, j, sub) {
    return '<h2>' + esc(title) + '</h2><p class="sub">' + (j ? rangeText(j) + (sub ? ' · ' : '') : '') + (sub || '') + '</p>';
  }

  function funnel(f, prev) {
    var steps = [['visit', 'Visits'], ['product', 'Looked at a product'], ['cart', 'Added to cart'], ['checkout', 'Started checkout'], ['order', 'Ordered']];
    if (!f.product && f.cart) { steps.splice(1, 1); }   // imported history has no product-view step
    var top = f.visit || 1;
    return '<div class="funnel">' + steps.map(function (s, i) {
      var n = f[s[0]] || 0, p = Math.round(n / top * 100);
      var drop = i ? (f[steps[i - 1][0]] ? Math.round((1 - n / f[steps[i - 1][0]]) * 100) : null) : null;
      return '<div class="fs"><div class="fl"><strong>' + esc(s[1]) + '</strong><span>' + num(n) + ' · ' + p + '% of visits' + (prev ? ' ' + delta(n, prev[s[0]]) : '') + '</span></div>' +
        '<div class="fb"><i style="width:' + Math.max(p, n ? 1 : 0) + '%"></i></div>' + (drop != null && drop > 0 ? '<div class="fd">' + drop + '% left before this step</div>' : '') + '</div>';
    }).join('') + '</div>';
  }

  // ------------------------------------------------------------ screens
  var views = {
    overview: function () {
      return api('summary').then(function (j) {
        var d = j.data, c = d.cur, p = d.prev;
        var h = head('Dashboard', j, 'compared with ' + esc(d.prev_range[0] + ' – ' + d.prev_range[1])) + trackingNote() + sinceNote(j) + cutNote(d.orders_cut);
        h += '<div class="kpis">' +
          kpi('Visitors', num(c.visitors), num(c.views) + ' page views', delta(c.visitors, p.visitors)) +
          kpi('Visits', num(c.visits), c.pages_per_visit == null ? '' : c.pages_per_visit + ' pages per visit', delta(c.visits, p.visits)) +
          kpi('Bounce rate', pct(c.bounce, 1), 'left after one page', delta(c.bounce, p.bounce, true)) +
          kpi('Time per visit', dur(c.time), '', delta(c.time, p.time)) +
          kpi('Orders', num(c.orders), 'avg. ' + money(c.aov), delta(c.orders, p.orders)) +
          kpi('Sales', money(c.sales), 'after discounts, before tax & shipping', delta(c.sales, p.sales)) +
          kpi('Conversion rate', pct(c.conversion), 'orders ÷ visitors', delta(c.conversion, p.conversion)) +
          kpi('On the store now', num(d.live), '<a href="#" data-go="realtime">see real time →</a>', '') + '</div>';
        if (d.daily.length > 1) {
          h += '<div class="grid2"><div class="card"><h3>Visitors per day</h3>' + columns(d.daily.map(function (x) { return { v: x.visitors, l: x.day, s: x.day.slice(5) }; }), num, 'Visitors per day') + '</div>' +
            '<div class="card"><h3>Sales per day</h3>' + columns(d.daily.map(function (x) { return { v: x.sales, l: x.day + ' · ' + x.orders + ' orders', s: x.day.slice(5) }; }), money, 'Sales per day') + '</div></div>';
        }
        h += '<div class="grid2"><div class="card"><h3>Sales funnel</h3>' + funnel(c.funnel, p.funnel) + '</div>';
        h += '<div class="card"><h3>Top sources</h3>' + table([['Source'], ['Visits', 1], ['Orders', 1], ['Sales', 1]], d.top_sources.map(function (s) {
          return '<tr><td>' + esc(SOURCES[s.src] || s.src) + '</td><td class="n">' + num(s.visits) + '</td><td class="n">' + num(s.orders) + '</td><td class="n" data-v="' + s.sales + '">' + money(s.sales) + '</td></tr>';
        }), 'No visits yet.', 'sources') + '</div></div>';
        h += '<div class="grid2"><div class="card"><h3>Top 5 pages</h3>' + table([['Page'], ['Visitors', 1]], d.top_pages.map(function (x) {
          return '<tr><td>' + itemLink(x.title, x.path, x.url) + '<span class="type">' + esc(TYPES[x.type] || x.type) + '</span></td><td class="n">' + num(x.visitors) + '</td></tr>';
        }), d.has_hits ? 'No page visits yet.' : 'Visits appear here a few minutes after the first visitors arrive.', 'top-pages') + '</div>';
        h += '<div class="card"><h3>Top 5 products</h3>' + table([['Product'], ['Sold', 1], ['Sales', 1]], d.top_products.map(function (x) {
          return '<tr><td>' + itemLink(x.title, x.path, x.url) + '</td><td class="n">' + num(x.units) + '</td><td class="n" data-v="' + x.sales + '">' + money(x.sales) + '</td></tr>';
        }), 'No sales or product visits in this period.', 'top-products') + '</div></div>';
        if (PI.upsell) {
          h += '<div class="card"><h3>Profit, ads and AI advice — Laghavi Ads Hub</h3><p class="muted" style="margin:0 0 6px">Profit per product after ad spend, your store next to your ads on Meta, Google and TikTok, customer value and segments, and an AI review of each product page.</p>' + more('A separate paid service by Laghavi Digital.') + '</div>';
        }
        return h + proCard();
      });
    },

    realtime: function () {
      return api('realtime', true).then(function (j) {
        var d = j.data;
        var h = '<h2>Real time</h2><p class="sub">Visitors on your store in the last 30 minutes · updates every 30 seconds</p>' + trackingNote();
        h += '<div class="kpis">' + kpi('Active now', num(d.active5), 'in the last 5 minutes') + kpi('Last 30 minutes', num(d.active30), num(d.views30) + ' page views') +
          kpi('With a cart', num(d.carts), num(d.checkout) + ' in checkout') + kpi('Ordered', num(d.ordered), 'in the last 30 minutes') + '</div>';
        h += '<div class="card"><h3>Page views per minute</h3>' + columns(d.minutes.map(function (v, i) { var m = 29 - i; return { v: v, l: (m ? m + ' min ago' : 'this minute'), s: m % 5 === 0 ? (m ? '-' + m + 'm' : 'now') : '' }; }), num, 'Page views per minute') + '</div>';
        h += '<div class="grid2"><div class="card"><h3>Pages being viewed (last 5 minutes)</h3>' + table([['Page'], ['Visitors', 1]], d.pages.map(function (x) {
          return '<tr><td>' + itemLink(x.title, x.path, x.url) + '</td><td class="n">' + num(x.now) + '</td></tr>';
        }), 'Nobody in the last 5 minutes.', 'pages-now') + '</div>';
        h += '<div class="card"><h3>Visitors</h3>' + table([['Now on'], ['Came from'], ['Device'], ['Pages', 1], ['Last seen', 1]], d.visitors.map(function (v) {
          var tag = v.outcome === 'order' ? '<span class="pill ok">ordered</span>' : (v.checkout ? '<span class="pill warnp">checkout</span>' : (v.outcome === 'cart' ? '<span class="pill new">cart</span>' : ''));
          return '<tr><td>' + itemLink(v.now.title, v.now.path, v.now.url) + ' ' + tag + '</td><td>' + srcName(v.src, v.ref) + '</td><td>' + flag(v.cc) + ' ' + esc(DEVICES[v.dev] || v.dev) + '</td>' +
            '<td class="n">' + num(v.pages) + '</td><td class="n" data-v="' + v.ago + '">' + esc(ago(v.ago)) + '</td></tr>';
        }), 'Nobody on the store right now.', 'visitors-now') + '</div></div>';
        return h;
      });
    },

    journeys: function () {
      return api('journeys' + (journeyFilter ? '?only=' + journeyFilter : '')).then(function (j) {
        var d = j.data, c = d.count;
        var h = head('Customer journeys', j, 'every visit that ended in an order or a cart: where the visitor came from, each page with the time on it, and the outcome') + sinceNote(j);
        h += '<div class="filters"><button data-jf="" class="' + (journeyFilter === '' ? 'on' : '') + '">All (' + num(c.all) + ')</button><button data-jf="order" class="' + (journeyFilter === 'order' ? 'on' : '') + '">Orders (' + num(c.order) + ')</button>' +
          '<button data-jf="cart" class="' + (journeyFilter === 'cart' ? 'on' : '') + '">Abandoned carts (' + num(c.cart) + ')</button></div>';
        if (!d.journeys.length) {
          h += '<div class="card"><p class="empty">No journeys in this period yet. A visit appears here 30 minutes after the visitor leaves — or right away while they are still shopping.</p></div>';
        } else {
          h += '<div class="card jlist">' + d.journeys.map(function (x) {
            var out = x.outcome === 'order' ? '<span class="pill ok">Ordered' + (x.order ? ' #' + esc(x.order) : '') + (x.value ? ' · ' + money(x.value) : '') + '</span>'
              : (x.outcome === 'open' ? '<span class="pill new">Cart · still shopping</span>' : '<span class="pill bad">Abandoned cart</span>');
            var steps = x.steps.map(function (s) {
              return '<span class="step' + (s.type === 'product' ? ' prod' : '') + '">' + (s.type === 'product' ? '<a href="#" class="open" data-path="' + esc(s.path) + '">' + esc(s.title) + '</a>' : esc(s.title)) + (s.secs != null ? ' <em>' + esc(dur(s.secs)) + '</em>' : '') + (s.note ? ' <em>' + esc(s.note) + '</em>' : '') + '</span>';
            }).join('<i>→</i>');
            var items = x.items.length ? '<div class="jitems">' + (x.outcome === 'order' ? 'Bought: ' : 'Left in the cart: ') + x.items.map(function (it) { return esc(it.title); }).join(', ') + '</div>' : '';
            return '<div class="jr"><div class="jh"><span>' + esc(when(x.start)) + '</span><span>' + srcName(x.src, x.ref) + (x.utm ? ' <span class="muted small">' + esc(x.utm) + '</span>' : '') + '</span>' +
              (x.history ? '<span class="muted small">from Shopify’s ' + (x.outcome === 'order' ? 'order record' : 'checkout record') + (x.days != null ? ' · ' + (x.days ? num(x.days) + (x.days === 1 ? ' day' : ' days') + ' from first visit to order' : 'ordered on the first day') : '') + '</span>'
                : '<span>' + flag(x.cc) + ' ' + esc(DEVICES[x.dev] || x.dev) + '</span><span>' + num(x.pages) + (x.pages === 1 ? ' page · ' : ' pages · ') + esc(dur(x.secs)) + '</span>') + out + '</div><div class="jp">' + (steps || '<span class="muted">no pages seen</span>') + '</div>' + items + '</div>';
          }).join('') + (d.journeys.length >= 200 ? '<p class="muted small">Showing the latest 200.</p>' : '') + '</div>';
        }
        h += '<div class="card"><h3>Per source</h3>' + table([['Source'], ['Orders', 1], ['Abandoned carts', 1], ['Cart → order', 1], ['Sales', 1], ['Pages before buying', 1], ['Time before buying', 1]], d.sources.map(function (s) {
          return '<tr><td>' + esc(SOURCES[s.src] || s.src) + '</td><td class="n">' + num(s.orders) + '</td><td class="n">' + num(s.carts) + '</td><td class="n" data-v="' + (s.cart_to_order == null ? -1 : s.cart_to_order) + '">' + pct(s.cart_to_order, 1) + '</td>' +
            '<td class="n" data-v="' + s.sales + '">' + money(s.sales) + '</td><td class="n">' + (s.pages_avg == null ? '–' : s.pages_avg) + '</td><td class="n" data-v="' + (s.secs_avg || 0) + '">' + esc(dur(s.secs_avg)) + '</td></tr>';
        }), 'No journeys yet.', 'journeys-per-source') + '</div>';
        var look = function (rows) {
          return table([['Product'], ['Times viewed', 1], ['Time spent', 1], ['Avg. per view', 1]], rows.map(function (p) {
            return '<tr><td>' + itemLink(p.title, p.path, p.url) + '</td><td class="n">' + num(p.views) + '</td><td class="n" data-v="' + p.secs + '">' + esc(dur(p.secs)) + '</td><td class="n" data-v="' + p.avg + '">' + esc(dur(p.avg)) + '</td></tr>';
          }), 'Nothing yet.', 'products-in-journeys');
        };
        h += '<div class="grid2"><div class="card"><h3>Looked at before buying</h3>' + look(d.before_buying) + '</div><div class="card"><h3>Looked at before leaving a cart</h3>' + look(d.before_leaving) +
          '<p class="muted small" style="margin:8px 0 0">Products people study for minutes and then leave often need clearer photos, sizes, delivery times or reviews.</p></div></div>';
        if (d.left_in_checkout && d.left_in_checkout.length) {
          h += '<div class="card"><h3>Left in unfinished checkouts</h3>' + table([['Product'], ['Checkouts', 1], ['Units', 1]], d.left_in_checkout.map(function (p) {
            return '<tr><td>' + itemLink(p.title, p.path, p.url) + '</td><td class="n">' + num(p.times) + '</td><td class="n">' + num(p.units) + '</td></tr>';
          }), '', 'left-in-checkouts') + '</div>';
        }
        h += '<p class="muted small">Journeys are anonymous: no name, email or IP address is stored. An order is linked only by a one-way code of its number.</p>';
        return h;
      });
    },

    sources: function () {
      return api('sources').then(function (j) {
        var d = j.data;
        var h = head('Traffic sources', j, 'where your visitors and buyers come from') + sinceNote(j);
        var vis = {}; d.channels.forEach(function (c) { vis[c.src] = c.visits; });
        h += '<div class="grid2"><div class="card"><h3>Visits by channel</h3>' + bars(vis, SOURCES) + '</div><div class="card"><h3>Channels</h3>' +
          table([['Channel'], ['Visits', 1], ['vs before', 1], ['Orders', 1], ['Sales', 1], ['Conversion', 1]], d.channels.map(function (c) {
            return '<tr><td>' + esc(SOURCES[c.src] || c.src) + '</td><td class="n">' + num(c.visits) + '</td><td class="n">' + delta(c.visits, c.prev) + '</td><td class="n">' + num(c.orders) + '</td>' +
              '<td class="n" data-v="' + c.sales + '">' + money(c.sales) + '</td><td class="n" data-v="' + (c.conversion == null ? -1 : c.conversion) + '">' + pct(c.conversion) + '</td></tr>';
          }), 'No visits yet.', 'channels') +
          '<p class="muted small" style="margin:8px 0 0">' + num(d.orders_known) + ' of ' + num(d.orders) + ' orders have a known source' + (d.attribution === 'shopify' ? ' (from Shopify’s order attribution, or the visit that ended with the order).' : ' (from the visit that ended with the order).') + '</p></div></div>';
        h += '<div class="card"><h3>AI assistants</h3>' + (d.ai.length ? table([['Assistant'], ['Visits', 1], ['Orders', 1], ['Sales', 1]], d.ai.map(function (a) {
          return '<tr><td>' + esc(a.name || 'AI assistant') + '</td><td class="n">' + num(a.visits) + '</td><td class="n">' + num(a.orders) + '</td><td class="n" data-v="' + a.sales + '">' + money(a.sales) + '</td></tr>';
        }), '', 'ai-assistants') : '<p class="empty">No visits from ChatGPT, Perplexity, Gemini, Copilot, Claude or other AI assistants in this period yet.</p>') + '</div>';
        h += '<div class="card"><h3>Websites, search engines and networks</h3>' + table([['Source'], ['Channel'], ['Visits', 1], ['Orders', 1], ['Sales', 1], ['Conversion', 1]], d.names.map(function (n) {
          return '<tr><td>' + esc(n.name || (n.src === 'direct' ? 'Typed in / bookmark' : '(not set)')) + '</td><td>' + esc(SOURCES[n.src] || n.src) + '</td><td class="n">' + num(n.visits) + '</td><td class="n">' + num(n.orders) + '</td>' +
            '<td class="n" data-v="' + n.sales + '">' + money(n.sales) + '</td><td class="n" data-v="' + (n.conversion == null ? -1 : n.conversion) + '">' + pct(n.conversion) + '</td></tr>';
        }), 'No visits yet.', 'sources') + '</div>';
        h += '<div class="card"><h3>Campaigns (UTM)</h3>' + table([['Source / medium · campaign'], ['Visits', 1], ['Orders', 1], ['Sales', 1]], d.utm.map(function (u) {
          return '<tr><td>' + esc(u.utm) + '</td><td class="n">' + num(u.visits) + '</td><td class="n">' + num(u.orders) + '</td><td class="n" data-v="' + u.sales + '">' + money(u.sales) + '</td></tr>';
        }), 'No visits with utm_ tags in this period. Add ?utm_source=…&utm_medium=…&utm_campaign=… to the links in your ads, emails and posts.', 'campaigns') + '</div>';
        return h + proCard();
      });
    },

    visitors: function () {
      return api('visitors').then(function (j) {
        var d = j.data;
        var h = head('Visitors', j, 'per visit — country comes from the browser’s time zone, no IP lookup') + sinceNote(j);
        h += '<div class="grid2"><div class="card"><h3>Countries</h3>' + bars(d.countries, function (k) { return flag(k) + ' ' + country(k); }) + '</div>' +
          '<div class="card"><h3>Devices</h3>' + bars(d.devices, DEVICES) + '<h3 style="margin-top:16px">Screen sizes</h3>' + bars(d.screens, {}) + '</div></div>';
        h += '<div class="grid2"><div class="card"><h3>Browsers</h3>' + bars(d.browsers, {}) + '</div><div class="card"><h3>Operating systems</h3>' + bars(d.os, {}) + '</div></div>';
        h += '<div class="card"><h3>Languages</h3>' + bars(d.languages, language) + '</div>';
        return h;
      });
    },

    pages: function () {
      return api('pages').then(function (j) {
        var d = j.data;
        var rows = d.pages.map(function (p, i) {
          return '<tr><td class="rank">' + (i + 1) + '</td><td>' + itemLink(p.title, p.path, p.url) +
            '<span class="type">' + esc(TYPES[p.type] || p.type) + '</span></td><td class="n">' + num(p.visitors) + '</td><td class="n">' + num(p.views) + '</td><td class="n">' + num(p.search) + '</td>' +
            '<td class="n">' + num(p.entries) + '</td><td class="n" data-v="' + (p.exit_rate == null ? -1 : p.exit_rate) + '">' + pct(p.exit_rate, 0) + '</td><td class="n" data-v="' + (p.score == null ? -1 : p.score) + '">' + score(p.score) + '</td></tr>';
        });
        var small = function (list, label) {
          return table([['Page'], [label, 1]], list.map(function (p) { return '<tr><td>' + itemLink(p.title, p.path, p.url) + '</td><td class="n">' + num(p.n) + '</td></tr>'; }), 'Nothing yet.', label.toLowerCase());
        };
        var h = head('Pages & posts', j, 'top 100 pages, products, collections and posts · click one for its details') + trackingNote();
        h += '<div class="card">' + table([['#'], ['Page'], ['Visitors', 1], ['Views', 1], ['From search', 1], ['Entries', 1], ['Exit rate', 1], ['SEO score', 1]], rows, 'No page visits yet.', 'pages') + '</div>';
        h += '<div class="grid2"><div class="card"><h3>Entry pages</h3><p class="muted small">The first page of a visit.</p>' + small(d.entry, 'Entries') + '</div>' +
          '<div class="card"><h3>Exit pages</h3><p class="muted small">The last page before the visitor left.</p>' + small(d.exit, 'Exits') + '</div></div>';
        h += '<div class="grid2"><div class="card"><h3>Searches on your store</h3>' + table([['Search term'], ['Searches', 1]], d.search.map(function (s) {
          return '<tr><td>' + esc(s.term) + '</td><td class="n">' + num(s.n) + '</td></tr>';
        }), 'No searches in this period.', 'site-search') + '</div><div class="card"><h3>Pages not found (404)</h3>' + table([['Address'], ['Views', 1]], d.not_found.map(function (s) {
          return '<tr><td>' + esc(s.path) + '</td><td class="n">' + num(s.n) + '</td></tr>';
        }), 'No broken links found in this period.', 'not-found') + (d.not_found.length ? '<p class="muted small" style="margin:8px 0 0">' + (SHOP ? 'Add a redirect in Online Store → Navigation → URL redirects.' : 'Add a 301 redirect in Settings → 301 Redirects.') + '</p>' : '') + '</div></div>';
        return h;
      });
    },

    products: function () {
      return api('products').then(function (j) {
        var d = j.data;
        var rows = d.products.map(function (p, i) {
          return '<tr><td class="rank">' + (i + 1) + '</td><td>' + itemLink(p.title, p.path, p.url) + '</td><td><span class="type">' + esc(KINDS[p.kind] || p.kind) + '</span></td>' +
            '<td class="n">' + num(p.visitors) + '</td><td class="n">' + num(p.carts) + '</td><td class="n">' + num(p.orders) + '</td><td class="n">' + num(p.units) + '</td><td class="n" data-v="' + p.sales + '">' + money(p.sales) + '</td><td class="n" data-v="' + (p.conversion == null ? -1 : p.conversion) + '">' + pct(p.conversion) + '</td></tr>';
        });
        var h = head('Best-selling products', j, 'top 100 by sales · click a product for its details') + cutNote(d.orders_cut);
        h += '<div class="card">' + table([['#'], ['Product'], ['Type'], ['Visitors', 1], ['Added to cart', 1], ['Orders', 1], ['Units', 1], ['Sales', 1], ['Conversion', 1]], rows, 'No sales or product visits in this period.', 'products') + '</div>';
        h += '<div class="card"><h3>Visited but not bought</h3>' + table([['Product'], ['Visitors', 1], ['Added to cart', 1]], d.not_bought.map(function (p) {
          return '<tr><td>' + itemLink(p.title, p.path, p.url) + '</td><td class="n">' + num(p.visitors) + '</td><td class="n">' + num(p.carts) + '</td></tr>';
        }), 'Every product with 5+ visitors sold at least once.', 'not-bought') + '<p class="muted small" style="margin:8px 0 0">Check the price, photos, description and delivery information of these products — open one to see its SEO problems.</p>' +
          more('Profit per product after ad spend and an AI review of each product page — in Laghavi Ads Hub.') + '</div>';
        return h;
      });
    },

    stock: function () {
      return api('stock').then(function (j) {
        var d = j.data, c = d.count;
        var ST = { out: ['Sold out', 'bad'], backorder: ['Sold out · backorders', 'warnp'], low: ['Low', 'warnp'], ok: ['In stock', 'ok'], untracked: ['Not tracked', ''] };
        var h = '<h2>Stock</h2><p class="sub">Live stock of every product and variant · low = ' + d.low + ' or fewer · days left at the sales pace of the last 30 days · visitors in the selected period</p>';
        h += '<div class="kpis">' + kpi('Sold out', num(c.out), '') + kpi('Low stock', num(c.low), d.low + ' or fewer left') + kpi('Sold out but visited', num(c.visited_out), 'visitors are seeing a sold-out product') + kpi('In stock', num(c.ok), num(c.untracked) + ' not tracked') + '</div>';
        var rows = d.rows.map(function (r) {
          var st = ST[r.status] || [r.status, ''];
          return '<tr data-t="' + esc(r.status === 'backorder' ? 'out' : r.status) + '"><td>' + itemLink(r.title, r.path, null) + (r.option ? ' <span class="muted">' + esc(r.option) + '</span>' : '') + '</td><td class="small muted">' + esc(r.sku) + '</td>' +
            '<td><span class="pill ' + st[1] + '">' + esc(st[0]) + '</span></td><td class="n" data-v="' + (r.qty == null ? -99999 : r.qty) + '">' + (r.qty == null ? '–' : num(r.qty)) + '</td><td class="n">' + num(r.sold30) + '</td>' +
            '<td class="n" data-v="' + (r.days_left == null ? 99999 : r.days_left) + '">' + (r.days_left == null ? '–' : num(r.days_left)) + '</td><td class="n">' + num(r.visitors) + '</td>' +
            '<td class="n"><a href="' + esc(r.edit) + '" target="_top">Edit</a></td></tr>';
        });
        h += '<div class="card"><div class="filters"><button class="on" data-f="">All (' + num(d.total) + ')</button><button data-f="out">Sold out (' + num(c.out) + ')</button><button data-f="low">Low (' + num(c.low) + ')</button><button data-f="ok">In stock (' + num(c.ok) + ')</button></div>' +
          table([['Product'], ['SKU'], ['Status'], ['In stock', 1], ['Sold (30 days)', 1], ['Days left', 1], ['Visitors', 1], ['', 1]], rows, 'No products yet.', 'stock') + '</div>';
        return h;
      });
    },

    coupons: function () {
      return api('coupons').then(function (j) {
        var d = j.data, s = d.summary;
        var h = head('Discount codes', j, 'who used your codes, the sales they brought and the discount they cost') + cutNote(d.orders_cut);
        h += '<div class="kpis">' +
          kpi('Codes used', num(s.codes_used), s.codes_in_store == null ? 'codes used in this period' : 'of ' + num(s.codes_in_store) + ' active codes in your store') +
          kpi('Orders with a code', num(s.orders_with_code), s.share == null ? 'no orders yet' : pct(s.share, 1) + ' of ' + num(s.orders) + ' orders') +
          kpi('Sales with a code', money(s.sales_with_code), 'discount given ' + money(s.discount)) +
          kpi('Average order', s.avg_with == null ? '–' : money(s.avg_with), 'with a code · ' + (s.avg_without == null ? '–' : money(s.avg_without)) + ' without') + '</div>';
        var rows = d.codes.map(function (c, i) {
          var who = (c.new + c.returning) ? '<span class="pill new">' + c.new + ' new</span><span class="pill ret">' + c.returning + ' returning</span>' : '<span class="muted">–</span>';
          var where = Object.keys(c.countries).map(function (cc) { return '<span title="' + esc(country(cc)) + '">' + flag(cc) + ' ' + esc(cc) + ' ' + c.countries[cc] + '</span>'; }).join(' · ') || '<span class="muted">–</span>';
          return '<tr><td class="rank">' + (i + 1) + '</td><td><strong>' + esc(c.code) + '</strong></td><td class="n">' + num(c.uses) + '</td><td class="n" data-v="' + c.sales + '">' + money(c.sales) + '</td>' +
            '<td class="n" data-v="' + c.discount + '">' + money(c.discount) + '</td><td class="n" data-v="' + c.discount_pct + '">' + pct(c.discount_pct, 1) + '</td><td class="n" data-v="' + c.avg_order + '">' + money(c.avg_order) + '</td>' +
            '<td>' + who + '</td>' + (d.has_country ? '<td class="small">' + where + '</td>' : '') + '</tr>';
        });
        h += '<div class="card"><h3>Top codes</h3>' + table([['#'], ['Code'], ['Used', 1], ['Sales', 1], ['Discount given', 1], ['Discount % of sales', 1], ['Avg. order', 1], ['Customers']].concat(d.has_country ? [['Top countries']] : []), rows, 'No discount codes used in this period.', 'discount-codes');
        var notes = [];
        if (!d.has_customer) { notes.push('new vs returning customers'); }
        if (!d.has_country && !SHOP) { notes.push('countries'); }
        if (notes.length && d.codes.length) {
          h += '<p class="muted small" style="margin:8px 0 0">' + esc(notes.join(' and ')) + ': ' + (SHOP ? 'shown once Shopify allows the app to read customer data.' : 'not shared by your store for these orders.') + '</p>';
        }
        h += '</div>';
        if (d.unused) {
          h += '<div class="card"><h3>Active codes nobody used in this period' + (d.unused_count > d.unused.length ? ' <span class="muted small">(' + num(d.unused_count) + ' — showing ' + d.unused.length + ')</span>' : '') + '</h3>' +
            table([['Code'], ['Offer'], ['Used (all time)', 1], ['Ends', 1]], d.unused.map(function (c) {
              return '<tr><td><strong>' + esc(c.code) + '</strong></td><td>' + esc(c.offer) + '</td><td class="n">' + num(c.used) + '</td><td class="n">' + esc(c.ends || 'No end date') + '</td></tr>';
            }), 'Every active code was used in this period.', 'unused-codes') +
            '<p class="muted small" style="margin:8px 0 0">Codes that stay unused are usually not seen: share them in your emails, on social media or in a site banner — or switch them off.</p></div>';
        }
        return h;
      });
    },

    seo: function () {
      return api('seo').then(function (j) {
        var all = j.data;
        var types = {};
        all.forEach(function (r) { types[r.type] = (types[r.type] || 0) + 1; });
        var f = '<div class="filters"><button class="on" data-f="">All (' + all.length + ')</button>' + Object.keys(types).map(function (t) { return '<button data-f="' + esc(t) + '">' + esc(TYPES[t] || t) + ' (' + types[t] + ')</button>'; }).join('') + '</div>';
        var rows = all.map(function (r) {
          return '<tr data-t="' + esc(r.type) + '"><td>' + itemLink(r.title, r.path, r.url) + '</td><td>' + esc(TYPES[r.type] || r.type) + '</td><td class="n">' + (r.problems ? r.problems + ' to fix' : '<span class="ok">none</span>') + '</td><td class="n" data-v="' + r.score + '">' + score(r.score) + '</td></tr>';
        });
        return '<h2>SEO scores</h2><p class="sub">Every product, page, blog post and ' + (SHOP ? 'collection' : 'category') + ' scored for what search engines and shoppers look for — weakest first. Click one to see what to fix.</p>' +
          '<div class="card">' + f + table([['Page'], ['Type'], ['Problems', 1], ['SEO score', 1]], rows, 'Nothing published yet.', 'seo-scores') +
          '<p class="muted" style="margin:10px 0 0">80+ is good, 55–79 needs work, under 55 needs attention.</p></div>';
      });
    },

    profit: function () {
      return api('profit').then(function (j) {
        var d = j.data;
        if (d.locked) { return locked('Profit', 'See what you really earn: sales after discounts minus what each product costs you (Shopify’s “Cost per item”), with profit and margin per product and per day, and the best sellers that earn the least.'); }
        var h = head('Profit', j, 'sales after discounts, before tax and shipping, minus product cost') + cutNote(d.orders_cut);
        if (d.coverage !== null && d.coverage < 100) {
          h += '<div class="note">' + (d.coverage === 0 ? 'None' : 'Only ' + d.coverage + '%') + ' of your sales have a product cost in Shopify. Add “Cost per item” to the products below (Products → product → Pricing) to see your full profit.</div>';
        }
        h += '<div class="kpis">' + kpi('Sales', money(d.sales), num(d.orders) + ' orders') + kpi('Product cost', money(d.cost), d.coverage == null ? '' : d.coverage + '% of sales have a cost') +
          kpi('Gross profit', money(d.profit), '') + kpi('Margin', d.margin == null ? '–' : pct(d.margin, 1), 'profit ÷ sales with a cost') +
          kpi('Profit per order', d.per_order == null ? '–' : money(d.per_order), '') + '</div>';
        if (d.daily.length > 1) {
          h += '<div class="card"><h3>Profit per day</h3>' + columns(d.daily.map(function (x) { return { v: Math.max(0, x.profit), l: x.day + ' · sales ' + money(x.sales), s: x.day.slice(5) }; }), money, 'Profit per day') + '</div>';
        }
        h += '<div class="card"><h3>Profit per product</h3>' + table([['Product'], ['Units', 1], ['Sales', 1], ['Cost', 1], ['Profit', 1], ['Margin', 1]], d.products.map(function (x) {
          return '<tr><td>' + itemLink(x.title, x.path, x.url) + (x.coverage < 100 && x.coverage > 0 ? ' <span class="type">cost for ' + x.coverage + '% of sales</span>' : '') + '</td><td class="n">' + num(x.units) + '</td><td class="n">' + money(x.sales) +
            '</td><td class="n">' + (x.cost == null ? '<span class="muted">no cost</span>' : money(x.cost)) + '</td><td class="n">' + (x.profit == null ? '–' : money(x.profit)) + '</td><td class="n">' + (x.margin == null ? '–' : pct(x.margin, 1)) + '</td></tr>';
        }), 'No sales in this period.', 'profit-per-product') + '</div>';
        if (d.missing.length) {
          h += '<div class="card"><h3>Products sold without a cost</h3>' + table([['Product'], ['Sales', 1], ['']], d.missing.map(function (x) {
            return '<tr><td>' + esc(x.title) + '</td><td class="n">' + money(x.sales) + '</td><td><a href="' + esc(x.edit) + '" target="_top">Add cost →</a></td></tr>';
          }), '', 'missing-cost') + '</div>';
        }
        return h + proCard();
      });
    },

    customers: function () {
      return api('customers').then(function (j) {
        var d = j.data;
        if (d.locked) { return locked('Customers', 'Know your buyers without seeing any personal data: new vs returning customers, repeat-purchase rate, how many orders and how much each customer has spent with you over their whole life, and your most valuable customers.'); }
        var h = head('Customers', j, 'buyers in this period, kept only as anonymous codes') + cutNote(d.orders_cut);
        var sp = d.split;
        h += '<div class="kpis">' + kpi('Buyers', num(d.buyers), d.guests ? num(d.guests) + ' guest orders' : '') +
          kpi('Returning buyers', num(sp.returning.buyers), d.repeat_rate == null ? '' : pct(d.repeat_rate, 1) + ' of buyers') +
          kpi('Sales from returning', money(sp.returning.sales), 'new buyers: ' + money(sp.new.sales)) +
          kpi('Lifetime orders', d.avg_lifetime_orders == null ? '–' : d.avg_lifetime_orders, 'average per buyer, all time') +
          kpi('Lifetime value', d.avg_lifetime_spent == null ? '–' : money(d.avg_lifetime_spent), 'average spent per buyer, all time') + '</div>';
        h += '<div class="grid2"><div class="card"><h3>Orders per customer (all time)</h3>' + bars(d.orders_dist, function (k) { return k + (k === '1' ? ' order' : ' orders'); }) + '</div>' +
          '<div class="card"><h3>New vs returning</h3>' + bars({ new: sp.new.buyers, returning: sp.returning.buyers }, { new: 'New buyers', returning: 'Returning buyers' }) + '</div></div>';
        h += '<div class="card"><h3>Most valuable customers</h3><p class="muted">Shown as anonymous codes. Open Customers in Shopify to see who they are.</p>' + table([['Customer'], ['Orders in period', 1], ['Sales in period', 1], ['Lifetime orders', 1], ['Lifetime spent', 1], ['Last order']], d.top.map(function (x) {
          return '<tr><td>#' + esc(x.code) + '</td><td class="n">' + num(x.orders) + '</td><td class="n">' + money(x.sales) + '</td><td class="n">' + (x.lifetime_orders == null ? '–' : num(x.lifetime_orders)) + '</td><td class="n">' + (x.lifetime_spent == null ? '–' : money(x.lifetime_spent)) + '</td><td>' + esc(x.last) + '</td></tr>';
        }), 'No customer orders in this period.', 'customers') + '</div>';
        return h + proCard();
      });
    },

    plan: function () {
      warnings = [];
      return token().then(function (t) {
        return fetch('/api/plan', { headers: { Authorization: 'Bearer ' + t } }).then(function (r) { return r.json(); });
      }).then(function (j) {
        if (!j.data) { throw new Error(j.error || 'Could not load.'); }
        var d = j.data, paid = d.plan === 'plus' || d.plan === 'pro';
        PI.plan = d.plan; PAID = paid;
        var tick = function (on) { return on ? '<span class="ok">✓</span>' : '<span class="muted">–</span>'; };
        var rows = [
          ['Dashboard, real time, journeys, sources (incl. ChatGPT and other AI assistants), visitors, pages, products, stock, discount codes, SEO', 1, 1, 1],
          ['Past orders and unfinished checkouts shown from day one', 1, 1, 1],
          ['History you can look back on', 'Last ' + d.free_days + ' days', '13 months', '13 months'],
          ['Profit: sales minus product cost, margin per product and per day', 0, 1, 1],
          ['Customers: new vs returning, repeat rate, lifetime orders and value, best customers', 0, 1, 1],
          ['Weekly email report with a written summary of your week', 0, 1, 1],
          ['Email alerts: sales or visits drop, traffic spike, best sellers sold out or running out', 0, 1, 1],
          ['Your Laghavi dashboard: Meta and Google ads next to your sales, ROAS and profit per ad, which ads to scale or pause', 0, 0, 1],
          ['All ad platforms in one view, budget pacing, ad alerts (rejected ads, budget running out)', 0, 0, 1],
          ['Set up with you by the Laghavi team, priority support', 0, 0, 1]
        ];
        var h = '<h2>Plan</h2><p class="sub">You are on <strong>' + esc(d.name) + '</strong>. Plans are billed by Shopify on your Shopify invoice; change or cancel any time.</p>';
        var col = function (k, label, price) { return '<th class="n' + (d.plan === k ? ' cur' : '') + '">' + label + '<br><small>' + price + '</small>' + (d.plan === k ? '<br><span class="pill ok">Your plan</span>' : '') + '</th>'; };
        h += '<div class="card"><div class="tw"><table class="plans"><thead><tr><th></th>' + col('free', 'Free', '$0') + col('plus', 'Plus', PRICE.plus + ' / month') + col('pro', 'Pro', PRICE.pro + ' / month') + '</tr></thead><tbody>' + rows.map(function (r) {
          var c = function (v) { return typeof v === 'string' ? esc(v) : tick(v); };
          return '<tr><td>' + esc(r[0]) + '</td><td class="n">' + c(r[1]) + '</td><td class="n">' + c(r[2]) + '</td><td class="n">' + c(r[3]) + '</td></tr>';
        }).join('') + '</tbody></table></div><div class="tools left">' + (d.plan === 'free' ? upgradeBtn('Choose Plus or Pro — 7 days free') : upgradeBtn('Change plan')) + '</div></div>';
        if (d.plan === 'pro') {
          h += '<div class="card procard"><div><h3>Your Laghavi dashboard</h3><p>' + (d.hub ? 'Your ads, sales and profit per ad in one place.' : 'Thanks for choosing Pro. The Laghavi team is setting up your dashboard and will email your login within one business day.') + '</p></div>' +
            (d.hub ? '<a class="btn primary" href="' + esc(d.hub) + '" target="_blank" rel="noopener">Open my dashboard ↗</a>' : '') + '</div>';
        }
        h += '<div class="card"><h3>Email reports and alerts</h3>' + (paid ? '' : '<p class="muted">Part of Plus. You can save your settings now; emails start when you upgrade.</p>') +
          '<form id="prefs" class="prefs"><label>Send to <input type="email" name="email" value="' + esc(d.email) + '" placeholder="you@yourstore.com" maxlength="190"></label>' +
          '<label class="chk"><input type="checkbox" name="weekly"' + (d.weekly ? ' checked' : '') + '> Weekly report every Monday morning</label>' +
          '<label class="chk"><input type="checkbox" name="alerts"' + (d.alerts ? ' checked' : '') + '> Alerts when something needs a look (at most one email a day)</label>' +
          '<div class="tools left"><button class="btn primary" type="submit">Save</button>' + (paid ? ' <button class="btn" type="button" id="testrep">Send a test report now</button>' : '') + ' <span id="prefmsg" class="muted"></span></div></form>' +
          (d.last_weekly ? '<p class="muted">Last weekly report: ' + esc(d.last_weekly) + '</p>' : '') + '</div>';
        return h;
      });
    },

    search: function () {
      return api('search', true).then(function (j) {
        var d = j.data, st = d.status;
        var h = head('Search', j, 'What people search on Google and Bing before they visit — next to what they then do and buy in your store.');
        if (!st.google && !st.bing) {
          return h + '<div class="card"><h3>See which Google and Bing searches bring visitors — and sales</h3><ul class="plain"><li>Searches, clicks, impressions and position for your store and every page</li><li>Each landing page with its Google clicks next to its visitors, orders and sales</li><li>Quick wins: searches where you already show on page one but few people click</li></ul>' + searchConnections(st) + '</div>';
        }
        if (st.google_error === 'revoked') { h += '<div class="note warn">Google access was removed in your Google account. Sign in with Google again below.</div>'; }
        if (st.google && !st.google_site) { h += '<div class="note warn">Choose your Search Console property below to see Google data.</div>'; }
        var engine = function (name, g, prevTotals, bing) {
          if (!g) { return ''; }
          var out = '<h2 class="sec">' + esc(name) + '</h2>';
          if (g.error) { return out + '<div class="card"><p class="muted">' + esc(name) + ' did not answer just now. Try again in a few minutes.</p></div>'; }
          var t = g.totals, p = prevTotals || {};
          out += '<div class="kpis">' + kpi('Clicks', num(t.clicks), 'visits from ' + name, prevTotals ? delta(t.clicks, p.clicks) : '') + kpi('Impressions', num(t.impressions), 'times you showed up', prevTotals ? delta(t.impressions, p.impressions) : '') +
            kpi('Click rate', pct(t.ctr, 1), 'clicks ÷ impressions', '') + (bing ? '' : kpi('Average position', t.position == null ? '–' : t.position, 'lower is better', prevTotals ? delta(t.position, p.position, true) : '')) + '</div>';
          out += '<div class="card"><h3>Clicks per day</h3>' + columns(g.daily.map(function (x) { return { v: x.clicks, l: x.day, s: x.day.slice(5) }; }), num, 'Clicks per day') + (bing ? '' : '<p class="muted">Google shows search data about two days late, so the last days can look low.</p>') + '</div>';
          out += '<div class="card"><h3>Landing pages: searches → visitors → sales</h3>' + table([['Page'], ['Clicks', 1], ['Impressions', 1], ['Position', 1], ['Visitors (all sources)', 1], ['Orders', 1], ['Sales', 1]], g.pages.map(function (x) {
            return '<tr><td>' + (x.path ? itemLink(x.title, x.path, x.url) : esc(x.url)) + '</td><td class="n">' + num(x.clicks) + '</td><td class="n">' + num(x.impressions) + '</td><td class="n">' + x.position + '</td><td class="n">' + (x.visitors == null ? '–' : num(x.visitors)) + '</td><td class="n">' + (x.orders == null ? '–' : num(x.orders)) + '</td><td class="n" data-v="' + (x.sales || 0) + '">' + (x.sales == null ? '–' : money(x.sales)) + '</td></tr>';
          }), 'No search clicks or impressions in this period yet.', name.toLowerCase() + '-pages') + '<p class="muted">' + (bing ? 'Bing reports searches by week, so the weeks that overlap this period are shown. ' : '') + 'Orders and sales are for products, from every source — not only search.</p></div>';
          var wins = g.queries.filter(function (q) { return q.impressions >= 50 && q.position <= 12 && q.ctr < (q.position <= 3 ? 8 : 2.5); }).sort(function (a, b) { return b.impressions - a.impressions; }).slice(0, 10);
          out += '<div class="grid2"><div class="card"><h3>Top searches</h3>' + table([['Search'], ['Clicks', 1], ['Impr.', 1], ['CTR', 1], ['Pos.', 1]], g.queries.slice(0, 25).map(function (q) {
            return '<tr><td>' + esc(q.keys[0]) + '</td><td class="n">' + num(q.clicks) + '</td><td class="n">' + num(q.impressions) + '</td><td class="n">' + pct(q.ctr, 1) + '</td><td class="n">' + q.position + '</td></tr>';
          }), 'No searches in this period yet.', name.toLowerCase() + '-searches') + '</div><div class="card"><h3>Quick wins</h3><p class="muted">You already show up on page one for these, but few people click. A clearer product or page title and meta description that match the search usually bring more clicks.</p>' +
            (wins.length ? table([['Search'], ['Impr.', 1], ['Pos.', 1], ['CTR', 1]], wins.map(function (q) { return '<tr><td>' + esc(q.keys[0]) + '</td><td class="n">' + num(q.impressions) + '</td><td class="n">' + q.position + '</td><td class="n">' + pct(q.ctr, 1) + '</td></tr>'; }), '', 'quick-wins') : '<p class="ok">Nothing stands out right now.</p>') + '</div></div>';
          return out;
        };
        h += engine('Google', d.google, d.google && d.google.prev, false);
        h += engine('Bing', d.bing, null, true);
        h += '<div class="card"><h3>Connections</h3>' + searchConnections(st) + '</div>';
        return h;
      });
    },

    help: function () {
      var how = SHOP
        ? 'Visits are counted by the app’s Shopify pixel (Settings → Customer events). It runs only when the visitor allows analytics under your store’s customer-privacy settings.'
        : 'Visits are counted by a small script the app added in Storefront → Script Manager, under the "Analytics" consent category. A second tiny script on the order confirmation page passes the order number.';
      return Promise.resolve('<h2>Help</h2><p class="sub">How this app works.</p>' +
        '<div class="card"><h3>Visit counting</h3><p>' + esc(how) + '</p><p>The app sets no cookies and stores no IP addresses, names or emails. Pages of one visit are grouped with a one-way code that changes every day; the country comes from the browser’s time zone. A new visit starts after 30 minutes without activity.</p>' +
        '<p>Status: ' + (PI.tracking ? '<strong class="ok">on</strong>' : '<strong class="warnt">switching on</strong> — reopen the app in a minute.') + '</p></div>' +
        '<div class="card"><h3>What each screen shows</h3><ul class="plain">' +
        '<li><strong>Dashboard</strong> — visitors, visits, bounce rate, time per visit, orders, sales and conversion, compared with the period before, plus the sales funnel.</li>' +
        '<li><strong>Real time</strong> — who is on the store in the last 30 minutes and what they are looking at.</li>' +
        '<li><strong>Journeys</strong> — for each visit that ended in an order or a cart: the source, every page with the time on it, and the outcome.</li>' +
        '<li><strong>Sources</strong> — search engines, social, AI assistants (ChatGPT, Perplexity, Gemini, Copilot, Claude…), ads, email and UTM campaigns, with orders and sales.</li>' +
        '<li><strong>Visitors</strong> — countries, devices, browsers, operating systems, screen sizes and languages.</li>' +
        '<li><strong>Pages</strong> — top 100 pages, entry and exit pages, searches on your store and pages not found.</li>' +
        '<li><strong>Products</strong> — top 100 by sales with add-to-carts and conversion, and products visited but not bought.</li>' +
        '<li><strong>Stock</strong> — sold-out and low-stock variants, days of stock left and sold-out products that still get visitors.</li>' +
        '<li><strong>Discount codes</strong> and <strong>SEO</strong> — what each code brought, and what to fix on each page.</li>' +
        '<li><strong>Search</strong> — optional: connect Google Search Console (sign in with Google, read-only) and Bing Webmaster Tools (API key) to see searches, clicks and positions next to each page’s visitors and sales.</li></ul>' +
        '<p class="muted">Use the period menu at the top for today, yesterday, 7, 14, 30 or 90 days, this or last month, or your own dates. Every table can be downloaded as CSV.</p></div>' +
        '<div class="card"><h3>Your data</h3><p>Orders, products, stock, pages and discount codes are read from your store; nothing in your store is changed. Customers are never stored by name, email or address. Raw page views are kept 4 days, journeys 90 days, daily totals 400 days (the Free plan shows the last 30 days of them, Plus all 13 months). If you connect Google Search Console or Bing, the app reads your search data from them with read-only access; the sign-in is stored encrypted and Disconnect removes it. Uninstalling the app deletes everything it stored.</p>' +
        '<p><a href="' + esc(PI.privacy) + '" target="_blank" rel="noopener">Privacy policy</a> · Questions: <a href="mailto:' + esc(PI.support) + '">' + esc(PI.support) + '</a></p></div>');
    },

    item: function (path) {
      return api('item?path=' + encodeURIComponent(path)).then(function (j) {
        var d = j.data;
        var back = '<a href="#" class="back" data-back="1">← Back</a>';
        if (!d || !d.path) { return back + '<p class="empty">This page has no visits or details yet.</p>'; }
        var h = back + '<div class="itemhead"><div><h2>' + esc(d.title) + ' <span class="type">' + esc(TYPES[d.type] || d.type) + '</span></h2><p class="sub">' + esc(d.path) + ' · ' + rangeText(j) +
          (d.url ? ' · <a href="' + esc(d.url) + '" target="_blank" rel="noopener">Open the live page ↗</a>' : '') + '</p></div><div>' + (d.score != null ? '<div class="bigscore">' + score(d.score) + '<small>SEO score</small></div>' : '') + '</div></div>';
        h += '<div class="kpis">' + kpi('Visitors', num(d.visitors), num(d.views) + ' views') +
          kpi('From search engines', num(d.sources.search), d.visitors ? pct(d.sources.search / d.visitors * 100, 0) + ' of visitors' : '') +
          kpi('On mobile', d.visitors ? pct(d.devices.mobile / d.visitors * 100, 0) : '–', num(d.devices.mobile) + ' visitors') +
          kpi('Entries · exits', num(d.entries) + ' · ' + num(d.exits), 'visits that started · ended here');
        if (d.sales) {
          h += kpi('Added to cart', num(d.sales.carts), '') + kpi('Sales', money(d.sales.sales), num(d.sales.orders) + ' orders · ' + num(d.sales.units) + ' units · ' + pct(d.sales.conversion) + ' buy');
        }
        h += '</div>';
        var days = Object.keys(d.daily);
        h += '<div class="grid2"><div class="card"><h3>Visitors per day</h3>' + columns(days.map(function (k) { return { v: d.daily[k], l: k, s: k.slice(5) }; }), num, 'Visitors per day') + '</div>';
        h += '<div class="card"><h3>Where visitors came from</h3>' + bars(d.sources, SOURCES) + '<h3 style="margin-top:14px">Devices</h3>' + bars(d.devices, DEVICES) + '</div></div>';
        if (d.sales && Object.keys(d.sales.codes).length) {
          h += '<div class="card"><h3>Discount codes used with this product</h3><p>' + Object.keys(d.sales.codes).slice(0, 5).map(function (c) { return '<span class="pill">' + esc(c) + ' · ' + d.sales.codes[c] + '×</span>'; }).join(' ') + '</p></div>';
        }
        if (d.facts) {
          var f = d.facts;
          var chk = function (ok, label, val) { return '<tr><td>' + (ok ? '<span class="ok">✓</span>' : '<span class="bad">✗</span>') + '</td><td>' + esc(label) + '</td><td class="n muted">' + esc(val) + '</td></tr>'; };
          h += '<div class="grid2"><div class="card"><h3>Problems found (' + d.issues.length + ')</h3>';
          h += d.issues.length ? '<ul class="issues">' + d.issues.map(function (i) {
            return '<li class="' + esc(i[0]) + '"><span class="lvl">' + esc(i[0] === 'high' ? 'Important' : (i[0] === 'medium' ? 'Should fix' : 'Nice to fix')) + '</span><strong>' + esc(i[1]) + '</strong><small>' + esc(WHY[i[1]] || '') + '</small></li>';
          }).join('') + '</ul>' : '<p class="ok">No problems found — well done.</p>';
          h += '</div><div class="card"><h3>What the check looked at</h3><table class="checks"><tbody>' +
            chk(f.title_len >= 25 && f.title_len <= 65, 'SEO title', f.title_len + ' characters') +
            chk(f.desc_len >= 70 && f.desc_len <= 165, 'Meta description', f.desc_len ? f.desc_len + ' characters' : 'missing') +
            chk(f.words >= (f.type === 'product' ? 150 : (f.type === 'post' ? 600 : 250)), 'Text on the page', num(f.words) + ' words') +
            chk(f.images_no_alt === 0, 'Image alt text', f.images ? (f.images - f.images_no_alt) + ' of ' + f.images + ' images' : 'no images') +
            (f.type === 'product' ? chk(f.images >= 3, 'Product photos', num(f.images)) + chk(f.videos > 0, 'Video', f.videos ? 'yes' : 'none') : chk(f.h2 > 0 || f.words <= 300, 'Subheadings', num(f.h2))) +
            '</tbody></table></div></div>';
        }
        return h;
      });
    }
  };

  // ------------------------------------------------------------ wiring
  function csv(t) {
    var lines = [];
    t.querySelectorAll('tr').forEach(function (tr) {
      if (tr.hidden) { return; }
      lines.push(Array.prototype.map.call(tr.cells, function (c) { var s = c.textContent.replace(/\s+/g, ' ').replace(/↗/g, '').trim(); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(','));
    });
    var blob = new Blob(['﻿' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'performance-insight-' + (t.dataset.name || 'report') + '-' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }

  function wire() {
    main.querySelectorAll('table.sort').forEach(function (t) {
      var ths = t.querySelectorAll('th');
      ths.forEach(function (th, col) {
        th.addEventListener('click', function () {
          var desc = th.dataset.d !== '1'; ths.forEach(function (x) { x.dataset.d = ''; }); th.dataset.d = desc ? '1' : '';
          var rows = Array.prototype.slice.call(t.tBodies[0].rows);
          var val = function (td) { if (!td) return ''; if (td.dataset.v !== undefined) return parseFloat(td.dataset.v); var s = td.textContent.trim(); var n = parseFloat(s.replace(/[^0-9.\-]/g, '')); return /^[^a-zA-Z]*[0-9]/.test(s) && !isNaN(n) ? n : s.toLowerCase(); };
          rows.sort(function (a, b) { var x = val(a.cells[col]), y = val(b.cells[col]); var r = (typeof x === 'number' && typeof y === 'number') ? x - y : String(x).localeCompare(String(y)); return desc ? -r : r; });
          rows.forEach(function (r) { t.tBodies[0].appendChild(r); });
        });
      });
    });
    main.querySelectorAll('button.csv').forEach(function (b) { b.addEventListener('click', function () { var t = document.getElementById(b.dataset.t); if (t) { csv(t); } }); });
    main.querySelectorAll('.filters button[data-f]').forEach(function (b) {
      b.addEventListener('click', function () {
        var box = b.closest('.card') || main;
        box.querySelectorAll('.filters button').forEach(function (x) { x.classList.remove('on'); }); b.classList.add('on');
        var f = b.dataset.f; box.querySelectorAll('tr[data-t]').forEach(function (tr) { tr.hidden = f !== '' && tr.dataset.t !== f; });
      });
    });
    main.querySelectorAll('.filters button[data-jf]').forEach(function (b) {
      b.addEventListener('click', function () { journeyFilter = b.dataset.jf; show('journeys'); });
    });
    main.querySelectorAll('a.open').forEach(function (a) {
      a.addEventListener('click', function (e) { e.preventDefault(); stopTimer(); render(views.item(a.dataset.path)); window.scrollTo(0, 0); });
    });
    main.querySelectorAll('a[data-back]').forEach(function (a) { a.addEventListener('click', function (e) { e.preventDefault(); show(current); }); });
    main.querySelectorAll('a[data-go]').forEach(function (a) { a.addEventListener('click', function (e) { e.preventDefault(); show(a.dataset.go); }); });
    bindSearch();
    var pf = document.getElementById('prefs');
    if (pf) {
      var msg = document.getElementById('prefmsg');
      var post = function (what, body) {
        return token().then(function (t) {
          return fetch('/api/' + what, { method: 'POST', headers: { Authorization: 'Bearer ' + t, 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
        }).then(function (r) { return r.json().then(function (j) { if (!r.ok) { throw new Error(j.error || 'Could not save.'); } return j; }); });
      };
      pf.addEventListener('submit', function (e) {
        e.preventDefault(); msg.textContent = 'Saving…';
        post('prefs', { email: pf.email.value.trim(), weekly: pf.weekly.checked, alerts: pf.alerts.checked })
          .then(function () { msg.textContent = 'Saved.'; }, function (er) { msg.textContent = er.message; });
      });
      var tb = document.getElementById('testrep');
      if (tb) {
        tb.addEventListener('click', function () {
          msg.textContent = 'Saving and sending…';
          post('prefs', { email: pf.email.value.trim(), weekly: pf.weekly.checked, alerts: pf.alerts.checked })
            .then(function () { return post('report-test'); })
            .then(function () { msg.textContent = 'Sent — check your inbox (and spam folder) in a few minutes.'; }, function (er) { msg.textContent = er.message; });
        });
      }
    }
  }

  /** Connect / choose / disconnect Google Search Console and Bing Webmaster Tools. */
  function searchConnections(st) {
    var g = '<div><h4>Google Search Console</h4>';
    if (!st.google || st.google_error === 'revoked') {
      g += st.google_ready ? '<button class="btn primary" type="button" id="gconnect">Sign in with Google</button><p class="muted">Opens Google in a new tab. Read-only access to your Search Console data.</p>' : '<p class="muted">Google sign-in is being switched on — check back soon.</p>';
    } else {
      g += '<p>Signed in as ' + esc(st.google_email || 'your Google account') + '</p><form id="gsite" class="prefs"><label>Property <select name="g_site" id="gsites"><option>' + esc(st.google_site || 'Loading…') + '</option></select></label> <button class="btn" type="submit">Save</button> <span class="muted" id="gmsg"></span></form>' +
        '<p><a href="#" data-disc="google">Disconnect Google</a></p>';
    }
    g += '</div>';
    var b = '<div><h4>Bing Webmaster Tools</h4>';
    if (!st.bing) {
      b += '<form id="bkey" class="prefs"><label>API key <input type="password" name="b_key" autocomplete="off" placeholder="Bing API key"></label> <button class="btn primary" type="submit">Connect Bing</button> <span class="muted" id="bmsg"></span></form>' +
        '<p class="muted">In Bing Webmaster Tools open Settings → API access → API key, copy it and paste it here. Your store must be added and verified there (you can import it from Google Search Console in one click). Bing also powers Copilot, DuckDuckGo and Yahoo results.</p>';
    } else {
      b += '<p>Connected: ' + esc(st.bing_site) + '</p><p><a href="#" data-disc="bing">Disconnect Bing</a></p>';
    }
    b += '</div>';
    return '<div class="grid2 conn">' + g + b + '</div>';
  }

  function post(what, body) {
    return token().then(function (t) {
      return fetch('/api/' + what, { method: 'POST', headers: { Authorization: 'Bearer ' + t, 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
    }).then(function (r) { return r.json().then(function (j) { if (!r.ok) { throw new Error(j.error || 'Could not save.'); } return j; }); });
  }

  function bindSearch() {
    var gc = document.getElementById('gconnect');
    if (gc) {
      gc.addEventListener('click', function () {
        var w = window.open('about:blank', '_blank');
        token().then(function (t) { return fetch('/api/search-connect', { headers: { Authorization: 'Bearer ' + t } }); })
          .then(function (r) { return r.json(); })
          .then(function (j) { if (j.url && w) { w.location = j.url; } else { if (w) { w.close(); } alert(j.error || 'Could not start Google sign-in.'); } });
      });
    }
    var sel = document.getElementById('gsites');
    if (sel) {
      token().then(function (t) { return fetch('/api/search-sites?' + qs(), { headers: { Authorization: 'Bearer ' + t } }); }).then(function (r) { return r.json(); }).then(function (j) {
        var cur = (j.status || {}).google_site || '';
        sel.innerHTML = (cur ? '' : '<option value="">— choose —</option>') + (j.sites || []).map(function (s) { return '<option value="' + esc(s) + '"' + (s === cur ? ' selected' : '') + '>' + esc(s) + '</option>'; }).join('');
        if (!(j.sites || []).length) { document.getElementById('gmsg').textContent = 'No Search Console property found for this Google account. Add and verify your store at search.google.com/search-console.'; }
      });
      document.getElementById('gsite').addEventListener('submit', function (e) {
        e.preventDefault(); var m = document.getElementById('gmsg'); m.textContent = 'Saving…';
        post('search-save', { g_site: sel.value }).then(function () { show('search'); }, function (er) { m.textContent = er.message; });
      });
    }
    var bk = document.getElementById('bkey');
    if (bk) {
      bk.addEventListener('submit', function (e) {
        e.preventDefault(); var m = document.getElementById('bmsg'); m.textContent = 'Checking with Bing…';
        post('search-save', { b_key: bk.b_key.value.trim() }).then(function () { show('search'); }, function (er) { m.textContent = er.message; });
      });
    }
    main.querySelectorAll('a[data-disc]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        e.preventDefault();
        if (!confirm('Disconnect ' + (a.dataset.disc === 'google' ? 'Google Search Console' : 'Bing Webmaster Tools') + '?')) { return; }
        post('search-disconnect', { which: a.dataset.disc }).then(function () { show('search'); });
      });
    });
  }

  function render(promise, quiet) {
    var my = ++seq;
    if (!quiet) { main.innerHTML = '<div class="loading">Loading…</div>'; }
    promise.then(function (html) {
      if (my !== seq) { return; }
      var notes = warnings.map(function (w) {
        if (w.indexOf('__cut__') === 0) { var x = w.slice(7).split('|'); return cutPlanNote({ cut: x[0], range: [x[1]] }); }
        return '<div class="note">' + esc(w) + '</div>';
      }).join('');
      main.innerHTML = notes + html; wire();
    })
      .catch(function (e) { if (my === seq) { main.innerHTML = '<div class="note warn">' + esc(e.message || 'Could not load.') + '</div>'; } });
  }

  window.addEventListener('message', function (e) { if (e.data === 'pi-search-connected' && current === 'search') { show('search'); } });
  window.addEventListener('focus', function () { if (current === 'search' && document.getElementById('gconnect')) { show('search'); } });
  function stopTimer() { if (timer) { clearInterval(timer); timer = null; } }

  function show(tab) {
    stopTimer();
    warnings = [];
    current = views[tab] && tab !== 'item' ? tab : 'overview';
    document.querySelectorAll('.tabs button').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === current); });
    document.getElementById('period').hidden = current === 'realtime' || current === 'help' || current === 'seo' || current === 'plan';
    render(views[current]());
    if (current === 'realtime') {
      timer = setInterval(function () { if (!document.hidden && current === 'realtime') { render(views.realtime(), true); } }, 30000);
    }
  }

  // period menu
  var sel = document.getElementById('range');
  if (SHOP && !PAID) {
    Array.prototype.forEach.call(sel.options, function (o) { if (o.value === '90d' || o.value === 'lastmonth') { o.textContent += ' (Plus)'; } });
  }
  var from = document.getElementById('from');
  var to = document.getElementById('to');
  var custom = document.getElementById('custom');
  var today = new Date().toISOString().slice(0, 10);
  from.max = to.max = today;
  sel.addEventListener('change', function () {
    if (sel.value === 'custom') {
      custom.hidden = false;
      if (!from.value) { from.value = new Date(Date.now() - 13 * 864e5).toISOString().slice(0, 10); to.value = today; }
      return;
    }
    custom.hidden = true;
    range = { r: sel.value, from: '', to: '' };
    show(current);
  });
  document.getElementById('apply').addEventListener('click', function () {
    if (!from.value || !to.value || from.value > to.value) { return; }
    range = { r: 'custom', from: from.value, to: to.value };
    show(current);
  });

  document.querySelectorAll('.tabs button').forEach(function (b) { b.addEventListener('click', function () { show(b.dataset.tab); }); });
  show('overview');
})();

<?php
/** @var array $shop @var ?string $appToken @var ?string $plan */
use App\Config;

$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
$boot = [
    'platform' => Config::get('platform'),
    'appToken' => $appToken,
    'currency' => $shop['currency'] ?? '',
    'shopName' => $shop['name'] ?: $shop['shop'],
    'tracking' => (bool) $shop['pixel'],
    'upsell' => (bool) Config::get('upsell') ? (string) Config::get('upsell_url') : null,
    'support' => (string) Config::get('support_email'),
    'privacy' => (string) Config::get('privacy_url'),
    'plan' => Config::shopify() ? ($plan ?? 'free') : null,
    'pricing' => App\Plan::pricingUrl($shop),
    'freeDays' => App\Plan::FREE_DAYS,
];
$v = '1.6.0';
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php if (Config::shopify()): ?>
<meta name="shopify-api-key" content="<?= $e(Config::get('client_id')) ?>">
<script src="https://cdn.shopify.com/shopifycloud/app-bridge.js"></script>
<?php endif; ?>
<title><?= $e(Config::get('app_name')) ?></title>
<link rel="stylesheet" href="/assets/app.css?v=<?= $v ?>">
</head>
<body class="pf-<?= $e(Config::get('platform')) ?>">
<div class="wrap">
  <header class="top">
    <div class="brand"><span class="logo">PI</span><div><strong><?= $e(Config::get('app_name')) ?></strong><small><?= $e($boot['shopName']) ?></small></div></div>
    <div class="period" id="period">
      <label for="range" class="sr">Period</label>
      <select id="range">
        <?php foreach (App\Insights::PRESETS as $k => $label): ?>
        <option value="<?= $e($k) ?>"<?= $k === '7d' ? ' selected' : '' ?>><?= $e($label === 'Custom' ? 'Custom dates…' : $label) ?></option>
        <?php endforeach; ?>
      </select>
      <span id="custom" hidden><input type="date" id="from" aria-label="From"> – <input type="date" id="to" aria-label="To"> <button id="apply" class="btn">Apply</button></span>
    </div>
  </header>
  <nav class="tabs" role="tablist">
    <button data-tab="overview" class="on">Dashboard</button>
    <button data-tab="realtime">Real time</button>
    <button data-tab="journeys">Journeys</button>
    <button data-tab="sources">Sources</button>
    <button data-tab="visitors">Visitors</button>
    <button data-tab="pages">Pages</button>
    <button data-tab="products">Products</button>
    <?php $lock = Config::shopify() && ! App\Plan::paid($plan ?? 'free') ? ' <span class="pill">Plus</span>' : ''; ?>
    <?php if (Config::shopify()): ?><button data-tab="profit">Profit<?= $lock ?></button><button data-tab="customers">Customers<?= $lock ?></button><?php endif; ?>
    <button data-tab="stock">Stock</button>
    <button data-tab="coupons">Discount codes</button>
    <button data-tab="seo">SEO</button>
    <button data-tab="search">Search</button>
    <?php if (Config::shopify()): ?><button data-tab="plan">Plan <span class="pill"><?= $e(App\Plan::NAMES[$plan ?? 'free'] ?? 'Free') ?></span></button><?php endif; ?>
    <button data-tab="help">Help</button>
  </nav>
  <main id="main"><div class="loading">Loading your store…</div></main>
  <footer class="foot">Performance Insight by Laghavi Digital · no cookies, no IP addresses, no personal data</footer>
</div>
<script>window.PI = <?= json_encode($boot, JSON_HEX_TAG | JSON_HEX_AMP) ?>;</script>
<script src="/assets/app.js?v=<?= $v ?>"></script>
</body>
</html>

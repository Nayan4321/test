# Performance Insight — free Shopify & BigCommerce apps

One program, installed twice on your Hostinger account:

| Copy | Address | `platform` in config.php |
|---|---|---|
| Shopify app | https://sh.laghavi.site | `shopify` |
| BigCommerce app | https://bc.laghavi.site | `bigcommerce` |

Each shop that installs gets its own account automatically (from its Shopify / BigCommerce login). Every row in the database belongs to one shop, and every screen checks a token signed by Shopify / BigCommerce, so one shop can never see another shop's data. Uninstalling deletes that shop's data.

---

## 1. Put both copies on your hosting (about 15 minutes)

1. hPanel → **Domains → Subdomains**: create `sh.laghavi.site` and `bc.laghavi.site`. Wait until SSL is active (hPanel → Security → SSL).
2. Upload `laghavi-store-apps-1.2.0.zip` to your **home folder** (not public_html) and run over SSH:

```
cd ~
unzip -q laghavi-store-apps-1.2.0.zip -d store-app-sh
unzip -q laghavi-store-apps-1.2.0.zip -d store-app-bc
# Point each subdomain at the app's public folder only (config and database stay private):
ls -d ~/domains/*/public_html/sh ~/domains/sh.laghavi.site/public_html 2>/dev/null   # shows which folder the subdomain uses
```

Use the folder the last line printed (call it WEB) and run, for each copy:

```
mv WEB WEB.bak-$(date +%F) && ln -s ~/store-app-sh/public WEB      # for sh
mv WEB WEB.bak-$(date +%F) && ln -s ~/store-app-bc/public WEB      # for bc (its own WEB folder)
```

3. In each copy: `cp config.example.php config.php` and edit `config.php`:
   - `platform` → `shopify` (sh) or `bigcommerce` (bc)
   - `app_url` → `https://sh.laghavi.site` or `https://bc.laghavi.site`
   - `client_id`, `client_secret` → from step 2 or 3 below
   - `app_key` → run `php -r "echo bin2hex(random_bytes(32));"` and paste (different for each copy; **never change it later**)
   - `upsell` → `false` for Shopify (App Store rule 1.2), `true` for BigCommerce
4. `chmod 700 ~/store-app-sh/storage ~/store-app-bc/storage`
5. hPanel → Advanced → **Cron Jobs**, **every hour**: `php ~/store-app-sh/cron.php` and `php ~/store-app-bc/cron.php`
6. Check: `https://sh.laghavi.site/health` and `https://bc.laghavi.site/health` show `ok`.

When many shops install, switch `db` to MySQL (create a database in hPanel → Databases; the tables are created automatically).

---

## 2. Shopify app (free, App Store)

**You need:** a free Shopify Partner account (partners.shopify.com) and, on your own computer, Node.js 20+.

1. Partner dashboard → **Apps → Create app → Create app manually** → name “Performance Insight”. Copy the **Client ID** and **Client secret** into `~/store-app-sh/config.php`.
2. On your computer: download the `shopify-cli` folder from the zip, open a terminal in it:
   ```
   npm install -g @shopify/cli
   npm install
   ```
   Edit `shopify.app.toml` → put your Client ID in `client_id`. Then:
   ```
   shopify app deploy
   ```
   This uploads the app settings (address, permissions, uninstall + privacy webhooks) and the **visit-counter pixel**.
3. Dev Dashboard → your app → **API access → Protected customer data access**: request access to **customer data** (Level 1) and, under Level 2, only the **Address** field (for the country). Names, emails and phone numbers are not needed. Reason: “Shows the merchant their sales per product and per discount code for the last 7 days, whether each code was used by new or returning customers, and which countries the orders came from. Customers are kept only as a one-way code and a country; no names, emails, phones or street addresses are stored.” Without this the app still works — the discount-code page then just leaves out new vs returning and countries.
   The app also asks for **read_discounts** (to list the store's active discount codes and spot unused ones), **read_customers** (new vs returning buyers) and **read_inventory** (the Stock screen).
4. **Test:** Partner dashboard → Stores → **Add store → Development store**, then your app → **Test on development store**. Add a few products, place a test order with a discount code (Bogus Gateway), visit some pages. The app opens inside the Shopify admin.
5. **Listing** (Distribution → Shopify App Store): app icon 1200×1200, 3+ screenshots (1600×900), short description, pricing **Free**, privacy policy URL `https://laghavi.site/privacy-policy/`, support email, demo store link. Submit for review.

Things Shopify reviewers check — already done in the app: embedded with App Bridge, works immediately after install, only the permissions it needs, uninstall + three privacy webhooks answered (customers/redact deletes the journeys of that customer's orders), no billing outside Shopify, pixel respects customer-privacy (analytics consent). See **SHOPIFY-SUBMISSION.md** for the listing text, the reviewer instructions and the full checklist.

---

## 3. BigCommerce app (free, App Marketplace)

**You need:** a BigCommerce developer account (devtools.bigcommerce.com) and a sandbox/trial store for testing.

1. devtools.bigcommerce.com → **My Apps → Create an app** → “Performance Insight”.
2. **Technical** tab:
   - Auth callback URL: `https://bc.laghavi.site/bc/auth`
   - Load callback URL: `https://bc.laghavi.site/bc/load`
   - Uninstall callback URL: `https://bc.laghavi.site/bc/uninstall`
   - Remove user callback URL: `https://bc.laghavi.site/bc/remove_user`
   - Multiple users: **on**
   - OAuth scopes: **Orders: read-only · Products: read-only · Information & settings: read-only · Marketing: read-only** (lists the store's active coupon codes) **· Content: modify** (needed to add the visit counter to Script Manager). Everything else: None.
3. **View Client ID** → copy Client ID and Client secret into `~/store-app-bc/config.php`.
4. **Test:** in your sandbox store → Apps → My Apps → My Draft Apps → install. Check Storefront → Script Manager shows “Performance Insight” (Analytics). Visit some pages, place a test order with a coupon.
5. **Listing:** app summary, icon, screenshots, pricing Free, privacy policy, support — submit from the Developer Portal.

---

## 4. Pro (paying clients) — in your hub, not in these apps

Store tab → **Connect store** in hub.laghavi.site shows the Shopify and BigCommerce Pro steps (private Shopify app per client / BigCommerce API account). Data refreshes with the hub's cron job.

## 5. Search: Google Search Console and Bing (1.6.0, also used by the WordPress plugin 1.7.0)

The Search tab (and the WordPress plugin's Search screen) need one Google app. Do this once, in your own Google account:

1. https://console.cloud.google.com → create a project "Laghavi Performance Insight" (or reuse the hub's project).
2. APIs & Services → Library → enable **Google Search Console API**.
3. APIs & Services → OAuth consent screen → External. App name "Performance Insight", support email, logo, home page https://laghavi.site/performance-insight/, privacy https://laghavi.site/privacy-policy-2/, terms https://laghavi.site/terms-conditions/, authorised domain laghavi.site. Scopes: `openid`, `email`, `https://www.googleapis.com/auth/webmasters.readonly`. Then **Publish app** and submit it for verification (Google asks for a short screen recording of the sign-in and the Search screen).
4. APIs & Services → Credentials → Create OAuth client ID → Web application. Authorised redirect URIs:
   - `https://sh.laghavi.site/connect/callback.php` (WordPress plugin)
   - `https://sh.laghavi.site/google/callback` (Shopify app)
5. hPanel → File Manager → `store-app-sh/connect-config.php` (already created, with its own random `state_key`): paste the **Client ID** and **Client secret** into the two empty values. Never put this file in a zip or in chat.

Until Google verifies the app, only test users you add on the consent screen can sign in. Bing needs nothing from you: each store owner pastes their own Bing Webmaster Tools API key.

## Updating an installed copy (1.2.0 and later)

The update zip contains only program files — never `config.php` or `storage/`. Over SSH:

```
cd ~ && rm -rf upd-store && mkdir upd-store && unzip -q laghavi-store-apps-update-1.2.0.zip -d upd-store
cp -r upd-store/. ~/store-app-sh/ && cp -r upd-store/. ~/store-app-bc/ && rm -rf upd-store
```

The database tables are added automatically on the next request. Then, for Shopify only, on your computer in the `shopify-cli` folder: `shopify app deploy` (new pixel + the new read_inventory permission). Shops get the new pixel settings the next time they open the app; BigCommerce stores get the new counter script the same way.

## Files

- `public/` — the only folder the web server shows
- `src/`, `views/` — program; `config.php` — your settings (keep private); `storage/` — database and error log
- `shopify-cli/` — Shopify app settings + pixel, deployed from your computer with Shopify CLI
- Errors: `storage/error.log`

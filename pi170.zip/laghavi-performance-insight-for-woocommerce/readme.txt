=== Performance Insight – Cookieless Analytics & SEO for WooCommerce ===
Contributors: nayan4321
Tags: woocommerce analytics, customer journey, abandoned cart, inventory, conversion
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Cookieless WooCommerce analytics with customer journeys: where each buyer came from, every product they viewed and for how long. No cookies.

== Description ==

**See what your WooCommerce store's visitors do — and what turns them into orders — without Google Analytics, cookies or a consent banner.**

Performance Insight lives right inside your **WooCommerce** menu, next to Orders and Products. Install it, activate it, and your store stats start counting with the next visit. No account, no tracking code, no setup.

= Answers in one screen =

* How many people visited today, and how many of them bought?
* **Where did this customer come from, which products did they look at, and for how long — before they bought, left their cart or signed up?**
* Which products get views but no sales?
* Where do your buyers come from — Google, Instagram, ads, email or **ChatGPT**?
* Which coupons bring sales, and which ones nobody uses?
* What is out of stock or running low — and is a sold-out product still getting visitors?
* Which pages and products have SEO problems, and what exactly to fix?

= Google Search Console and Bing searches — new in 1.7 =

Connect **Google Search Console** (sign in with Google) and **Bing Webmaster Tools** (paste your API key) on the new **Search** screen — both optional and read-only:

* Clicks, impressions, click rate and average position for your site, compared with the period before.
* **Landing pages from search with their visitors, orders and sales** from Performance Insight and WooCommerce — see which searches really sell.
* Top searches on Google and Bing, and **quick wins**: searches where you already show on page one but few people click.
* On every page's and product's detail screen: the Google searches that bring people to it, and its Bing clicks.

Bing also powers results in Copilot, DuckDuckGo and Yahoo.

= Customer journeys — new in 1.4 =

For every visit that ends in an **order**, an **abandoned cart** or a **new customer account**, Performance Insight shows the whole path:

* **Where the customer came from** — Google or Bing (organic), paid ads (Instagram, Facebook, TikTok, Google Ads, with the UTM campaign), social media, email, **ChatGPT and other AI assistants**, or direct.
* **Every page and product they looked at, in order, with the time spent on each** — e.g. Home 12s → Linen Kaftan 1m 35s → Silk Scarf 48s → order.
* **The outcome** — ordered (with the order number and value), abandoned cart (with the products left behind) or account created.
* **Per source**: orders, abandoned carts, cart-to-order rate, pages and time before buying.
* **Products looked at before buying vs before leaving** — find the products people study for minutes and then abandon.
* **On every order screen**: a "Customer journey" box showing where that customer came from and what they viewed before ordering.

Journeys are anonymous: no name, email or IP address is stored, and an order is linked only by its order number.

= Subscriptions, licenses, languages and logins — new in 1.5 =

When these plugins are active, Performance Insight adds their numbers to its own screens, read-only:

* **Rinnovo Subscriptions & Licenses** (and Pro): active, new and cancelled subscriptions, MRR, ARR, churn, net revenue retention, successful, failed and recovered renewals, trials and trial-to-paid conversion, revenue per currency, refunds and credit notes, licenses and activations, and "Ask for price" enquiries.
* **Rinnovo extensions**, each in its own tab when installed: subscription boxes (shipped, skips, swaps, prepaid and gift plans, expected quantities), membership content (members, courses, download credits), media archives (plays, watch time, quotas, devices), service contracts (contract MRR, quota used vs included, requests), session membership (bookings, attendance, no-shows, class utilisation, credits, waitlists) and bundles (components, held renewals, plan switches).
* **Vacanam Language Switcher**: views, orders, revenue and conversion per language, language changes and country redirects.
* **Sarala Login Page**: sign-ins and sign-ups per provider, failed logins and lockouts.

To-do cards point out what needs attention: failed renewals to follow up, trials ending this week, contracts close to their quota, classes under 40% full, box items that may run out before the next shipping day, and languages with traffic but low conversion. Visible to shop managers and administrators only.

= WooCommerce analytics, free =


* **Dashboard** — visitors, page views, visits, bounce rate, time per visit, orders, sales and **conversion rate**, compared with the period before.
* **Real-time visitors** — who is on your store in the last 30 minutes and what they are looking at.
* **Store sales funnel** — product views → added to cart → checkout → orders, so you see where shoppers drop off.
* **Best-selling products** — the top 100 products with visitors, orders, units, sales and conversion (physical, digital and subscription products).
* **Traffic sources** — search engines, social networks, **AI assistants (ChatGPT, Perplexity, Gemini, Copilot, Claude…)**, other websites and UTM campaigns, with orders and sales per channel from WooCommerce order attribution.
* **Stock tracking** — live stock for every product and variation, **low-stock and out-of-stock alerts**, days of stock left at the current sales pace, sold-out products that still get visitors, and a direct **Edit** link for each one. Optional: **hide sold-out products from the shop automatically** and show them again when they are back in stock, plus a daily stock alert email.
* **Inside WooCommerce's own screens** — Visitors and Conversion columns in the Products list, a 30-day box (visitors, add to cart, orders, sales, sources) on every product's edit page, and the customer journey on every order.
* **Weekly store report email** — every Monday: visitors, orders, sales and conversion vs the week before, the best source, top products, abandoned carts and low stock.
* **Today in the admin toolbar** and a **WordPress Dashboard widget** — visitors and orders today, who is on the site now, and the latest customer journeys.
* **AI crawlers & search bots** — which AI companies (OpenAI GPTBot and ChatGPT, Anthropic ClaudeBot, PerplexityBot, Meta AI, Amazon and more) and search engines read your store, and which pages they read most.
* **Coupons report** — sales and discount per code, new vs returning customers, average order with vs without a coupon, and coupons nobody used.
* **Visitors** — countries, devices, browsers, operating systems, screen sizes and languages.
* **Pages & posts** — most visited pages, entry and exit pages, site search terms and **404 pages not found**.
* **SEO score for every page, post and product** — weakest first, with a checklist (title, meta description, text length, image alt text, headings, links, photos, reviews, SKU, stock). Works with Yoast SEO, Rank Math, All in One SEO, SEOPress and Elementor.
* **A detail screen for every page and product** — visitors per day, sources, mobile vs desktop, add-to-carts, sales and its SEO problems.
* **Any period** — today, yesterday, 7 or 30 days, this or last month, this year or custom dates.
* **CSV export** of every report.

= Privacy friendly, GDPR friendly =

* **No cookies** and **no IP addresses** stored. A visitor is counted once per day with a one-way code that changes every day.
* Country comes from the browser's time zone (also the older names some browsers still send, such as Asia/Calcutta), or from the country header your host or CDN already adds — no IP lookup, no outside service.
* Raw page views are kept for 4 days only; after that only daily totals remain.
* Your own staff (administrators, shop managers — you choose) are not counted, bots are filtered and "Do Not Track" is respected.
* **Everything stays in your own WordPress database.** Nothing about your visitors or orders ever leaves your site. Only if you choose to connect Google or Bing does the plugin talk to them (see External services), and the optional feedback form when you deactivate sends only what you type.

= Light and fast =

Your pages are not changed. A tiny script (about 1 KB) sends one small request after the page has loaded. No jQuery, no external scripts, no slowdown.

= Want profit, ads and AI advice too? Laghavi Ads Hub (paid) =

Laghavi Ads Hub is a separate paid service by Laghavi Digital. With a plan you receive the **Performance Insight Pro** add-on, which connects your store to your Hub dashboard:

* Profit per product after ad spend, and stock vs ads.
* Your store next to your ads on Meta, Google, TikTok and more — which ads really sell.
* Abandoned carts, customer value and segments.
* AI review of each product page and an AI action plan.

This free plugin is complete on its own and sends no store data. Only the Pro add-on, installed separately, connects to Laghavi Ads Hub. Learn more at https://laghavi.site/performance-insight/

== Installation ==

1. In WordPress go to **Plugins → Add New**, search for "Performance Insight WooCommerce analytics" and click **Install Now**, then **Activate**. (WooCommerce must be active.)
2. Open **WooCommerce → Performance Insight**.
3. That's it — counting starts with the next visit.

== Frequently Asked Questions ==

= Where do I find the reports? =

In **WooCommerce → Performance Insight**. All screens (Visitors, Sources, Pages & posts, Journeys, Products, Coupons, Stock, SEO scores, Settings) are in the tab bar at the top of the page.

= Is this a Google Analytics alternative for WooCommerce? =

For most store owners, yes: visitors, sources, the sales funnel, products, coupons and conversion rate in one simple screen inside WordPress — without cookies, consent banners or a Google account. If you also use Google Analytics, both can run side by side.

= Do I need WooCommerce? =

Yes. Orders, sales, products, the funnel and coupons come from WooCommerce, so WordPress asks for WooCommerce to be active first.

= Does it work with Rinnovo, Vacanam and Sarala? =

Yes. When one of them is active, its tab appears automatically (Rinnovo, Languages or Logins). Each Rinnovo extension gets its own sub-tab only when it is installed. The data is read-only and cached for 15 minutes; nothing in those plugins is changed. All of it is free — nothing is limited by the Pro add-on.

= Does Performance Insight recommend other plugins? =

Yes, our own free plugins, on Performance Insight's own screens only (never on other admin pages, no pop-ups). The Dashboard and Settings show a small "More free plugins from Laghavi Digital" card with Rinnovo Subscriptions & Licenses and Sarala Login Page. Some screens also suggest one when your data points to it — for example when customers re-buy the same product (subscriptions) or carts are abandoned (one-click sign-in at checkout). Plugins you already have are never suggested, and every card has a "Not now" link that hides it.

= What is a customer journey? =

The path one visitor took on your store in one visit: where they came from (search, ads, social, email, AI assistant or direct), each page and product they opened with the time spent on it, and how it ended — an order, an abandoned cart or a new account. Find them in **WooCommerce → Performance Insight → Journeys**, and on each order's edit screen.

= Are customer journeys GDPR friendly? =

They are stored without cookies, names, email addresses or IP addresses. A journey is linked to an order only by the order number, which is already in your store. Journeys are kept for 90 days by default (Settings) and removed with the plugin.

= Can I see which AI bots read my site? =

Yes. The Sources screen lists AI crawlers (GPTBot, ChatGPT, ClaudeBot, PerplexityBot, Meta AI, Amazonbot and others) and search engine crawlers, and the pages AI crawlers read most. Bots are never counted as visitors. Pages served from a full-page cache may not be counted.

= Can I see traffic from ChatGPT and other AI assistants? =

Yes. When someone clicks a link to your store inside ChatGPT, Perplexity, Gemini, Copilot, Claude or similar, the visit is counted under **AI assistants** with the assistant's name — and you see the orders it brought.

= Does it slow my site down? =

No. Pages are not changed. A tiny script (about 1 KB) sends one small request after the page has loaded, and one more with the time spent when the visitor leaves.

= Do I need a cookie banner for this plugin? =

The plugin sets no cookies and stores no IP addresses. Check your local law and your own privacy policy, but this plugin is built to need no consent for counting.

= How do I connect Google Search Console and Bing? =

Open WooCommerce → Performance Insight → Search. For Google, click "Sign in with Google", allow read-only access, and the matching Search Console property is picked for you. For Bing, open Bing Webmaster Tools → Settings → API access, copy your API key and paste it. Your site must be verified in each tool first (Bing can import it from Search Console in one click).

= Is my data sent anywhere? =

No. Your visitor and order data stays in your WordPress database. If you connect Google Search Console or Bing Webmaster Tools, the plugin reads your search data from them (it does not send them your visitor or order data). The optional deactivation feedback form sends only what you choose to type (see External services). Only the separate Performance Insight Pro add-on (part of a paid Laghavi Ads Hub plan) sends data, and only after you connect it.

= Will numbers match Google Analytics? =

Not exactly. Every analytics tool counts a little differently (ad blockers, bots, consent banners, staff visits). Use the numbers to compare your own pages, products and periods with each other.

= How long is data kept? =

Daily totals are kept as long as you choose in **Settings** (default 400 days). Raw page views are kept for 4 days only.

= Does it work with HPOS, Elementor and SEO plugins? =

Yes — WooCommerce High-Performance Order Storage, Elementor pages and Yoast SEO, Rank Math, All in One SEO and SEOPress are supported.

= What happens when I delete the plugin? =

By default all its tables and settings are removed. You can switch that off in **Settings**.

= Why are some numbers empty right after I install it? =

Visits, page views and time on page can only be counted from the moment the plugin is switched on. Everything WooCommerce already knows is brought in straight away: on activation the plugin reads your past orders and unfinished checkouts (with WooCommerce's order attribution — source, landing page, pages seen, device) and shows them under Journeys and Sources, marked "from WooCommerce's order record". Sales, products, coupons, stock and SEO already use your full store history.

== Screenshots ==

1. Dashboard — visitors, visits, bounce rate, sales and conversion rate vs the period before, real-time visitors and sources.
2. Products — the store sales funnel and every product's visitors, orders, units, sales and conversion.
3. Coupons — sales, discount and customers per coupon code, plus coupons nobody used.
4. SEO scores for every page, post and product, weakest first.
5. Visitors — countries, devices, browsers, operating systems, screens and languages.
6. Traffic sources — search engines, social networks, AI assistants like ChatGPT, websites and campaigns.
7. Customer journeys — orders, abandoned carts and new accounts by source, and the products looked at before buying vs before leaving.
8. Each journey: where the customer came from, every page and product viewed with the time on each, and the outcome.
9. The customer journey on a WooCommerce order.
10. Stock — out-of-stock and low-stock alerts, days of stock left, visitors to sold-out products and automatic hiding of sold-out products.
11. Rinnovo — subscriptions, MRR, churn, renewals, trials and to-do cards (when Rinnovo Subscriptions & Licenses is active).

== External services ==

This plugin contacts outside services only when you choose to:

* **Deactivation feedback (optional).** When you click "Deactivate" on the Plugins screen, a short form asks why. If you press "Submit & Deactivate", the plugin sends the reason you picked, the text you typed, your email and site address only if you entered or ticked them, and the plugin, WordPress, WooCommerce and PHP versions to Laghavi Digital at https://sh.laghavi.site/feedback, so we can fix what went wrong and reply if you asked. "Skip & Deactivate" sends nothing. [Privacy policy](https://laghavi.site/privacy-policy-2/)

* **Laghavi Connect (only if you click "Sign in with Google").** Google requires a registered app with a secret key for reading Search Console data, so sign-in goes through Laghavi Connect at https://sh.laghavi.site/connect/ (the same approach as Site Kit and MonsterInsights). When you click the button, your browser is sent there with your site address, the address to return to, and a one-time public key; it sends you on to Google's consent screen, then hands the sign-in back to your site sealed with that one-time key, so only your admin session can open it. Afterwards, about once an hour while you look at the Search screen, your site sends its Google refresh token to https://sh.laghavi.site/connect/refresh.php to get a short-lived access token, because Google needs the app's secret for that. Laghavi Connect stores nothing — no tokens and no search data — and your search data is read by your site directly from Google. [Terms](https://laghavi.site/terms-conditions/) · [Privacy policy](https://laghavi.site/privacy-policy-2/)
* **Google Search Console API and Google sign-in (only after you connect Google).** Your site reads your Search Console data (searches, pages, clicks, impressions, positions) from https://www.googleapis.com/webmasters/v3/ with read-only access, and withdraws access at https://oauth2.googleapis.com/revoke when you click Disconnect. Nothing about your visitors or orders is sent. [Google Terms](https://policies.google.com/terms) · [Google Privacy Policy](https://policies.google.com/privacy)
* **Bing Webmaster Tools API (only after you paste a Bing API key).** Your site reads your Bing search data from https://ssl.bing.com/webmaster/api.svc/json/ using your key. Nothing about your visitors or orders is sent. [Microsoft Services Agreement](https://www.microsoft.com/servicesagreement) · [Microsoft Privacy Statement](https://privacy.microsoft.com/privacystatement)

The review request link opens WordPress.org in your browser; the plugin itself sends nothing.

== Changelog ==

= 1.7.0 =
* New Search screen: connect Google Search Console (sign in with Google) and Bing Webmaster Tools (API key). Clicks, impressions, click rate and position compared with the period before, top searches, quick wins, and landing pages with their visitors, orders and sales.
* New: Google searches and Bing clicks on every page's and product's detail screen.
* Google and Bing access is read-only and stored encrypted with your site's own keys. Disconnect deletes it and also withdraws Google access; deleting the plugin deletes it too.
* Includes all accuracy fixes from 1.6.1.

= 1.6.1 =
* More accurate counting: speed and cache plugins (LiteSpeed Cache, WP Rocket, Perfmatters, SiteGround Speed Optimizer, Autoptimize, NitroPack and others) are asked not to delay, defer or combine the counter. A delayed counter only ran after a scroll or tap, so quick visits were missed.
* More accurate countries: older time zone names that browsers still send (for example Asia/Calcutta from Chrome on Windows in India) are now recognised. When the browser gives no usable time zone, the country header from Cloudflare, CloudFront or your host is used, then the region of the browser language.
* More accurate sources: visits from the Instagram, Facebook, TikTok, Snapchat, LinkedIn, Pinterest, X and Threads apps are counted as social even when the app hides the referrer, and Android apps (Gmail, Google app, WhatsApp, ChatGPT…) are recognised. utm_source=chatgpt.com and similar tags count as AI assistants; igshid, fbclid and srsltid are understood.
* Pages the browser prepares in advance (prerendering) are only counted when the visitor really opens them, and pages shown again with the Back button are counted.
* New: the Dashboard warns when nothing has been counted for two days and names the speed or cache plugin that may be the cause.
* The counter script and its address have new names that ad blockers' lists don't catch; the old ones keep working for pages cached before the update.

= 1.6.0 =
* New: on activation, past orders and unfinished checkouts are brought in from WooCommerce's own records (order attribution: source, landing page, pages seen, device and session start), so Journeys and Sources show your store's history straight away instead of zeros. They are marked "from WooCommerce's order record". Runs in the background in batches of 200.
* New: screens explain which numbers start counting at install and which already show your full history.
* New: a short review request 3 days after install. "Maybe later" asks again after 7 days; "I already did" or "Don't ask again" hides it for good.
* New: optional feedback form when the plugin is deactivated. Nothing is sent unless you press "Submit & Deactivate".
* Tested with WordPress 7.1.5 and WooCommerce 11.3.

= 1.5.0 =
* New Rinnovo tab (when Rinnovo Subscriptions & Licenses is active) with a sub-tab per installed Rinnovo extension: subscriptions, revenue (MRR, ARR, churn, net revenue retention), renewals, trials, currencies, refunds, licenses, "Ask for price", subscription boxes, membership content, media archives, service contracts, session membership and bundles.
* New Languages tab (Vacanam Language Switcher) and Logins tab (Sarala Login Page).
* New to-do cards: failed renewals, trials ending this week, contracts near their quota, classes under 40% full, box items that may run out, languages with low conversion. A summary appears on the Dashboard.
* New: "More free plugins from Laghavi Digital" (Rinnovo Subscriptions & Licenses, Sarala Login Page) and data-based suggestions, on Performance Insight screens only, each with "Not now".

= 1.4.0 =
* New **Customer journeys** screen: for every order, abandoned cart and new account — where the customer came from (organic search, paid ads with UTM campaign, social, email, AI assistants, direct), every page and product viewed in order with the time on each, and the outcome. By source: orders, abandoned carts, cart-to-order rate, pages and time before buying. Products looked at before buying vs before leaving. Filters and CSV export.
* New "Customer journey" box on every WooCommerce order.
* New Visitors and Conversion columns in WooCommerce → Products, and a 30-day box on each product's edit page.
* New weekly store report email (Mondays; can be switched off in Settings, with a "Send one now" button).
* New: today's visitors and orders in the admin toolbar, and a Performance Insight widget on the WordPress Dashboard.
* New: AI crawler and search engine bot report on the Sources screen (which bots read the site and which pages AI crawlers read most).
* Fix: visits to the WooCommerce Shop page are now counted.
* Settings: how long to keep journeys, when a cart counts as abandoned, the weekly email and the toolbar.

= 1.3.0 =
* The reports now live inside the **WooCommerce** menu (WooCommerce → Performance Insight), next to Orders and Products. All screens are in the tab bar at the top; old links keep working.
* The Pro page is now WooCommerce → Insight Pro.
* New **Stock** screen: live stock for every product and variation, low-stock and out-of-stock alerts, days of stock left at the current sales pace, visitors to sold-out products, and an Edit link for each product. CSV export.
* Optional: hide products from the shop and search automatically while they are sold out, and show them again when they are back in stock (off by default; products you hid yourself are never touched).
* Optional daily stock alert email.
* Stock alerts on the Dashboard and a count on the Stock tab.
* A review request for administrators after 3 days of use. Closing it or "Maybe later" reminds again after 24 hours; "I already did" stops it for good.
* Clearer plugin description and FAQ.

= 1.2.0 =
* Any period (today, yesterday, 7 / 30 days, this / last month, this year, custom dates) on every report, compared with the period before.
* Dashboard: visits, bounce rate, time per visit and pages per visit; visitors per day; real-time visitors; top countries.
* New Visitors screen: countries (from the browser time zone, no IP lookup), devices, browsers, operating systems, screen sizes, languages and visits per day.
* New Traffic sources screen: search engines, social networks, AI assistants (ChatGPT, Perplexity, Gemini, Copilot, Claude…), websites, campaigns and source / medium, with orders and sales per channel.
* Pages & posts: top 100, entry pages, exit pages, site search terms and pages not found (404).
* Products: store funnel (product views → cart → checkout → orders) and the top 100 products.
* CSV export of every report.
* Settings: exclude IP addresses; choose which roles can see the reports.

= 1.1.2 =
* For the Pro add-on's conversion reports: orders also carry the device type, the landing page path and which ad click IDs the visit had (names only), from WooCommerce's own order attribution. Add-to-cart events report the device type to add-ons.

= 1.1.1 =
* Fix: variable products whose variations are all virtual or downloadable now show as Digital, not Physical.
* Subscription products made with YITH, SUMO, WP Swings or WebToffee subscriptions are now recognised as Subscriptions.
* New `lgpi_product_kind` filter to correct a product's kind.

= 1.1.0 =
* New: a detail screen for every page, post and product — visitors per day, sources, devices, sales and its SEO problem list.
* New: richer Coupons screen — new vs returning customers, top countries, discount % of sales, average order with vs without a coupon, and unused coupons.
* The visit counter also sends the visitor's time zone (for visits by country in add-ons) and notes checkout-page visits. Still no cookies and no personal data.
* New `lgpi_hit` action for add-ons.

= 1.0.0 =
* First release.

== Upgrade Notice ==

= 1.7.0 =
New Search screen with Google Search Console and Bing searches next to your visitors and sales, plus more accurate visitors, countries and sources. Purge your page cache once after updating.

= 1.6.1 =
More accurate visitors, countries and traffic sources (cache plugins, in-app browsers, older time zone names). Purge your page cache once after updating.

= 1.6.0 =
Shows your past orders and unfinished checkouts right after install, instead of empty screens.

= 1.5.0 =
Adds Rinnovo subscriptions and licenses, Vacanam languages and Sarala logins to your insights when those plugins are active.

= 1.4.0 =
Customer journeys: see where each buyer came from and which products they viewed (and for how long) before ordering or abandoning the cart. Plus a weekly email, Products-list columns and an AI crawler report.

= 1.3.0 =
Performance Insight moves into the WooCommerce menu (WooCommerce → Performance Insight) and adds a Stock screen with low-stock alerts.

= 1.1.0 =
Detail screen for every page and product, and a much richer Coupons screen.

= 1.0.0 =
First release.

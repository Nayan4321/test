<?php
/**
 * The "Search" screen: Google Search Console and Bing Webmaster Tools next to this site's own visitors and sales,
 * and a search block on every page's detail screen.
 *
 * @package PerformanceInsight
 */

defined( 'ABSPATH' ) || exit;

/**
 * Search screen.
 */
class LGPI_Search_View {

	/**
	 * Number cell.
	 *
	 * @param float $v   Value.
	 * @param int   $dec Decimals.
	 * @return string
	 */
	private static function n( $v, $dec = 0 ) {
		return null === $v ? '–' : number_format_i18n( (float) $v, $dec );
	}

	/**
	 * The screen.
	 */
	public static function page() {
		list( $since, $until, $label, $psince, $puntil ) = LGPI_Admin::range();
		$admin = current_user_can( 'manage_options' );
		echo '<div class="lgpi-head"><div><h2>' . esc_html__( 'Search', 'laghavi-performance-insight-for-woocommerce' ) . '</h2><p>' . esc_html( $label ) . ' · ' . esc_html__( 'What people search on Google and Bing before they visit — next to what they then do and buy on your site.', 'laghavi-performance-insight-for-woocommerce' ) . '</p></div></div>';
		$g = LGPI_Search::google_on();
		$b = LGPI_Search::bing_on();
		if ( ! $g && ! $b ) {
			self::intro( $admin );
			return;
		}
		$o = LGPI_Search::get();
		if ( 'revoked' === $o['g_error'] || 'no_access' === $o['g_error'] ) {
			echo '<div class="lgpi-note err">' . esc_html( 'revoked' === $o['g_error'] ? __( 'Google access was removed in your Google account. Connect Google again below.', 'laghavi-performance-insight-for-woocommerce' ) : __( 'This Google account can no longer read the chosen Search Console property. Choose another property or connect another Google account below.', 'laghavi-performance-insight-for-woocommerce' ) ) . '</div>';
		}
		if ( $g ) {
			self::google_section( $since, $until, $psince, $puntil );
		}
		if ( $b ) {
			self::bing_section( $since, $until );
		}
		if ( $admin ) {
			self::connections();
		}
	}

	/**
	 * Nothing connected yet.
	 *
	 * @param bool $admin Can connect.
	 */
	private static function intro( $admin ) {
		echo '<div class="lgpi-card lgpi-search-intro"><h3><span class="dashicons dashicons-search"></span> ' . esc_html__( 'See which Google and Bing searches bring visitors — and sales', 'laghavi-performance-insight-for-woocommerce' ) . '</h3>';
		echo '<ul class="lgpi-rec-list"><li>' . esc_html__( 'Searches, clicks, impressions and position for your site and for every page', 'laghavi-performance-insight-for-woocommerce' ) . '</li><li>' . esc_html__( 'Each landing page with its Google clicks next to its visitors, orders and sales from Performance Insight', 'laghavi-performance-insight-for-woocommerce' ) . '</li><li>' . esc_html__( 'Searches where you show up a lot but few people click — quick wins for better titles', 'laghavi-performance-insight-for-woocommerce' ) . '</li></ul>';
		if ( $admin ) {
			self::connections( true );
		} else {
			echo '<p class="lgpi-muted">' . esc_html__( 'An administrator can connect Google Search Console and Bing Webmaster Tools here.', 'laghavi-performance-insight-for-woocommerce' ) . '</p>';
		}
		echo '</div>';
	}

	/**
	 * Google Search Console section.
	 *
	 * @param string $since  Y-m-d.
	 * @param string $until  Y-m-d.
	 * @param string $psince Previous period start.
	 * @param string $puntil Previous period end.
	 */
	private static function google_section( $since, $until, $psince, $puntil ) {
		$days    = LGPI_Search::gsc( $since, $until, array( 'date' ), 500 );
		$prev    = LGPI_Search::gsc( $psince, $puntil, array( 'date' ), 500 );
		$queries = LGPI_Search::gsc( $since, $until, array( 'query' ), 250 );
		$pages   = LGPI_Search::gsc( $since, $until, array( 'page' ), 100 );
		echo '<h2 class="lgpi-sechead"><span class="lgpi-engine g">G</span> ' . esc_html__( 'Google Search', 'laghavi-performance-insight-for-woocommerce' ) . '</h2>';
		if ( null === $days ) {
			echo '<div class="lgpi-card"><p class="lgpi-muted">' . esc_html__( 'Google did not answer just now. Try again in a few minutes.', 'laghavi-performance-insight-for-woocommerce' ) . '</p></div>';
			return;
		}
		$t = LGPI_Search::totals( $days );
		$p = LGPI_Search::totals( (array) $prev );
		echo '<div class="lgpi-kpis">';
		LGPI_Admin::kpi( __( 'Clicks', 'laghavi-performance-insight-for-woocommerce' ), self::n( $t['clicks'] ), __( 'visits from Google search', 'laghavi-performance-insight-for-woocommerce' ), $prev ? LGPI_Admin::delta( $t['clicks'], $p['clicks'] ) : array() );
		LGPI_Admin::kpi( __( 'Impressions', 'laghavi-performance-insight-for-woocommerce' ), self::n( $t['impressions'] ), __( 'times you showed up in results', 'laghavi-performance-insight-for-woocommerce' ), $prev ? LGPI_Admin::delta( $t['impressions'], $p['impressions'] ) : array() );
		LGPI_Admin::kpi( __( 'Click rate', 'laghavi-performance-insight-for-woocommerce' ), null === $t['ctr'] ? '–' : self::n( $t['ctr'], 1 ) . '%', __( 'clicks ÷ impressions', 'laghavi-performance-insight-for-woocommerce' ), null !== $t['ctr'] && null !== $p['ctr'] ? LGPI_Admin::delta( $t['ctr'], $p['ctr'] ) : array() );
		LGPI_Admin::kpi( __( 'Average position', 'laghavi-performance-insight-for-woocommerce' ), self::n( $t['position'], 1 ), __( 'lower is better', 'laghavi-performance-insight-for-woocommerce' ), null !== $t['position'] && null !== $p['position'] ? LGPI_Admin::delta( $t['position'], $p['position'], false ) : array() );
		echo '</div>';
		$daily = array();
		foreach ( $days as $r ) {
			$daily[ (string) $r['keys'][0] ] = $r['clicks'];
		}
		echo '<div class="lgpi-card"><h3>' . esc_html__( 'Clicks from Google per day', 'laghavi-performance-insight-for-woocommerce' ) . '</h3>';
		LGPI_Admin::day_chart( $daily, $since, $until );
		echo '<p class="lgpi-muted">' . esc_html__( 'Google shows search data with a delay of about two days, so the last days can look low.', 'laghavi-performance-insight-for-woocommerce' ) . '</p></div>';
		self::pages_table( (array) $pages, $since, $until, __( 'Landing pages from Google: searches → visitors → sales', 'laghavi-performance-insight-for-woocommerce' ) );
		echo '<div class="lgpi-grid2">';
		self::queries_table( array_slice( (array) $queries, 0, 25 ), __( 'Top searches', 'laghavi-performance-insight-for-woocommerce' ) );
		self::quick_wins( (array) $queries );
		echo '</div>';
	}

	/**
	 * Bing section.
	 *
	 * @param string $since Y-m-d.
	 * @param string $until Y-m-d.
	 */
	private static function bing_section( $since, $until ) {
		$r = LGPI_Search::bing_report( $since, $until );
		echo '<h2 class="lgpi-sechead"><span class="lgpi-engine b">b</span> ' . esc_html__( 'Bing (also powers Copilot, DuckDuckGo and Yahoo results)', 'laghavi-performance-insight-for-woocommerce' ) . '</h2>';
		if ( null === $r ) {
			echo '<div class="lgpi-card"><p class="lgpi-muted">' . esc_html__( 'Bing did not answer just now. Try again in a few minutes.', 'laghavi-performance-insight-for-woocommerce' ) . '</p></div>';
			return;
		}
		$clicks = 0;
		$impr   = 0;
		$daily  = array();
		foreach ( $r['days'] as $d => $v ) {
			$clicks     += $v[0];
			$impr       += $v[1];
			$daily[ $d ] = $v[0];
		}
		echo '<div class="lgpi-kpis">';
		LGPI_Admin::kpi( __( 'Clicks', 'laghavi-performance-insight-for-woocommerce' ), self::n( $clicks ), __( 'visits from Bing search', 'laghavi-performance-insight-for-woocommerce' ) );
		LGPI_Admin::kpi( __( 'Impressions', 'laghavi-performance-insight-for-woocommerce' ), self::n( $impr ), __( 'times you showed up in results', 'laghavi-performance-insight-for-woocommerce' ) );
		LGPI_Admin::kpi( __( 'Click rate', 'laghavi-performance-insight-for-woocommerce' ), $impr ? self::n( $clicks / $impr * 100, 1 ) . '%' : '–', __( 'clicks ÷ impressions', 'laghavi-performance-insight-for-woocommerce' ) );
		echo '</div>';
		echo '<div class="lgpi-card"><h3>' . esc_html__( 'Clicks from Bing per day', 'laghavi-performance-insight-for-woocommerce' ) . '</h3>';
		LGPI_Admin::day_chart( $daily, $since, $until );
		echo '</div>';
		self::pages_table( $r['pages'], $since, $until, __( 'Landing pages from Bing: searches → visitors → sales', 'laghavi-performance-insight-for-woocommerce' ), true );
		echo '<div class="lgpi-grid2">';
		self::queries_table( array_slice( $r['queries'], 0, 25 ), __( 'Top searches on Bing', 'laghavi-performance-insight-for-woocommerce' ), true );
		self::quick_wins( $r['queries'] );
		echo '</div>';
	}

	/**
	 * Landing pages joined with Performance Insight visitors and WooCommerce sales.
	 *
	 * @param array  $rows  Rows with keys[0] = page URL.
	 * @param string $since Y-m-d.
	 * @param string $until Y-m-d.
	 * @param string $title Card title.
	 * @param bool   $weeks Bing (weekly figures).
	 */
	private static function pages_table( $rows, $since, $until, $title, $weeks = false ) {
		$woo   = LGPI_Plugin::has_woo();
		$sales = $woo ? LGPI_Store::product_sales( $since, $until ) : array();
		echo '<div class="lgpi-card"><h3>' . esc_html( $title ) . '</h3><div class="lgpi-tablewrap"><table class="lgpi-table lgpi-sortable"><thead><tr><th>' . esc_html__( 'Page', 'laghavi-performance-insight-for-woocommerce' ) . '</th><th class="n">' . esc_html__( 'Clicks', 'laghavi-performance-insight-for-woocommerce' ) . '</th><th class="n">' . esc_html__( 'Impressions', 'laghavi-performance-insight-for-woocommerce' ) . '</th><th class="n">' . esc_html__( 'Position', 'laghavi-performance-insight-for-woocommerce' ) . '</th><th class="n">' . esc_html__( 'Visitors (all sources)', 'laghavi-performance-insight-for-woocommerce' ) . '</th>';
		if ( $woo ) {
			echo '<th class="n">' . esc_html__( 'Orders', 'laghavi-performance-insight-for-woocommerce' ) . '</th><th class="n">' . esc_html__( 'Sales', 'laghavi-performance-insight-for-woocommerce' ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		$shown = 0;
		foreach ( array_slice( $rows, 0, 30 ) as $r ) {
			$url = (string) $r['keys'][0];
			$obj = LGPI_Search::object_for_url( $url );
			$vis = '–';
			$ord = '–';
			$rev = null;
			$lab = (string) wp_parse_url( $url, PHP_URL_PATH );
			$lab = '' === $lab || '/' === $lab ? __( 'Home page', 'laghavi-performance-insight-for-woocommerce' ) : $lab;
			$cell = '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $lab ) . '</a>';
			if ( $obj ) {
				list( $name ) = LGPI_Admin::object_label( $obj[0], $obj[1] );
				$cell         = '<a href="' . esc_url( LGPI_Admin::url( 'lgpi-pages', array( 'item' => $obj[0] . ':' . $obj[1] ) ) ) . '">' . esc_html( $name ) . '</a>';
				$v            = 0;
				foreach ( LGPI_DB::object_daily( $obj[0], $obj[1], $since, $until ) as $d ) {
					$v += (int) $d['visitors'];
				}
				$vis = self::n( $v );
				if ( 'product' === $obj[0] && isset( $sales[ $obj[1] ] ) ) {
					$ord = self::n( $sales[ $obj[1] ]['orders'] );
					$rev = (float) $sales[ $obj[1] ]['revenue'];
				} elseif ( 'product' === $obj[0] ) {
					$ord = '0';
				}
			}
			++$shown;
			echo '<tr><td>' . wp_kses( $cell, LGPI_Admin::LINK_HTML ) . '</td><td class="n">' . esc_html( self::n( $r['clicks'] ) ) . '</td><td class="n">' . esc_html( self::n( $r['impressions'] ) ) . '</td><td class="n">' . esc_html( self::n( $r['position'], 1 ) ) . '</td><td class="n">' . esc_html( $vis ) . '</td>';
			if ( $woo ) {
				echo '<td class="n">' . esc_html( $ord ) . '</td><td class="n" data-v="' . esc_attr( (string) (float) $rev ) . '">' . esc_html( null === $rev ? '–' : LGPI_Admin::money( $rev ) ) . '</td>';
			}
			echo '</tr>';
		}
		if ( ! $shown ) {
			echo '<tr><td colspan="7" class="lgpi-muted">' . esc_html__( 'No search clicks or impressions in this period yet.', 'laghavi-performance-insight-for-woocommerce' ) . '</td></tr>';
		}
		echo '</tbody></table></div><p class="lgpi-muted">' . esc_html( $weeks ? __( 'Bing reports searches by week, so the weeks that overlap this period are shown. Orders and sales are for products, from WooCommerce.', 'laghavi-performance-insight-for-woocommerce' ) : __( 'Orders and sales are for products, from WooCommerce, from every source — not only search.', 'laghavi-performance-insight-for-woocommerce' ) ) . '</p></div>';
	}

	/**
	 * Searches table.
	 *
	 * @param array  $rows  Rows with keys[0] = search words.
	 * @param string $title Title.
	 * @param bool   $weeks Bing.
	 */
	private static function queries_table( $rows, $title, $weeks = false ) {
		echo '<div class="lgpi-card"><h3>' . esc_html( $title ) . '</h3><div class="lgpi-tablewrap"><table class="lgpi-table lgpi-sortable"><thead><tr><th>' . esc_html__( 'Search', 'laghavi-performance-insight-for-woocommerce' ) . '</th><th class="n">' . esc_html__( 'Clicks', 'laghavi-performance-insight-for-woocommerce' ) . '</th><th class="n">' . esc_html__( 'Impr.', 'laghavi-performance-insight-for-woocommerce' ) . '</th><th class="n">' . esc_html__( 'CTR', 'laghavi-performance-insight-for-woocommerce' ) . '</th><th class="n">' . esc_html__( 'Pos.', 'laghavi-performance-insight-for-woocommerce' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr><td>' . esc_html( (string) $r['keys'][0] ) . '</td><td class="n">' . esc_html( self::n( $r['clicks'] ) ) . '</td><td class="n">' . esc_html( self::n( $r['impressions'] ) ) . '</td><td class="n">' . esc_html( self::n( $r['ctr'], 1 ) ) . '%</td><td class="n">' . esc_html( self::n( $r['position'], 1 ) ) . '</td></tr>';
		}
		if ( ! $rows ) {
			echo '<tr><td colspan="5" class="lgpi-muted">' . esc_html__( 'No searches in this period yet.', 'laghavi-performance-insight-for-woocommerce' ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
		if ( ! $weeks ) {
			echo '<p class="lgpi-muted">' . esc_html__( 'Google hides very rare searches for privacy, so these add up to less than the total.', 'laghavi-performance-insight-for-woocommerce' ) . '</p>';
		}
		echo '</div>';
	}

	/**
	 * Searches with many impressions but a low click rate on page one: better titles and descriptions win clicks.
	 *
	 * @param array $rows Query rows.
	 */
	private static function quick_wins( $rows ) {
		$wins = array_filter(
			$rows,
			function ( $r ) {
				return $r['impressions'] >= 50 && $r['position'] <= 12 && $r['ctr'] < ( $r['position'] <= 3 ? 8 : 2.5 );
			}
		);
		usort(
			$wins,
			function ( $a, $b ) {
				return $b['impressions'] <=> $a['impressions'];
			}
		);
		echo '<div class="lgpi-card"><h3>' . esc_html__( 'Quick wins', 'laghavi-performance-insight-for-woocommerce' ) . '</h3><p class="lgpi-muted">' . esc_html__( 'You already show up on page one for these, but few people click. A clearer page title and meta description that match the search usually bring more clicks.', 'laghavi-performance-insight-for-woocommerce' ) . '</p>';
		if ( ! $wins ) {
			echo '<p class="lgpi-good">' . esc_html__( 'Nothing stands out right now.', 'laghavi-performance-insight-for-woocommerce' ) . '</p></div>';
			return;
		}
		echo '<table class="lgpi-table"><tbody>';
		foreach ( array_slice( $wins, 0, 10 ) as $r ) {
			echo '<tr><td>' . esc_html( (string) $r['keys'][0] ) . '</td><td class="n lgpi-muted">' . esc_html( sprintf( /* translators: 1: impressions, 2: position, 3: click rate */ __( '%1$s impr. · pos. %2$s · %3$s%% CTR', 'laghavi-performance-insight-for-woocommerce' ), self::n( $r['impressions'] ), self::n( $r['position'], 1 ), self::n( $r['ctr'], 1 ) ) ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	/**
	 * Search block on a page's detail screen.
	 *
	 * @param string $type Type.
	 * @param int    $id   ID.
	 */
	public static function item_block( $type, $id ) {
		$g = LGPI_Search::google_on();
		$b = LGPI_Search::bing_on();
		if ( ! $g && ! $b ) {
			if ( current_user_can( 'manage_options' ) ) {
				echo '<div class="lgpi-card"><h3>' . esc_html__( 'Google and Bing searches for this page', 'laghavi-performance-insight-for-woocommerce' ) . '</h3><p class="lgpi-muted">' . esc_html__( 'Connect Google Search Console or Bing Webmaster Tools to see which searches bring people to this page.', 'laghavi-performance-insight-for-woocommerce' ) . ' <a href="' . esc_url( LGPI_Admin::url( 'lgpi-search' ) ) . '">' . esc_html__( 'Connect', 'laghavi-performance-insight-for-woocommerce' ) . ' →</a></p></div>';
			}
			return;
		}
		$url = LGPI_Search::url_for( $type, $id );
		if ( '' === $url ) {
			return;
		}
		list( $since, $until ) = LGPI_Admin::range();
		echo '<div class="lgpi-grid2">';
		if ( $g ) {
			$rows = LGPI_Search::gsc( $since, $until, array( 'query' ), 25, $url );
			$t    = LGPI_Search::totals( (array) $rows );
			/* translators: 1: clicks, 2: impressions */
			self::queries_table( (array) $rows, sprintf( __( 'Google searches for this page · %1$s clicks · %2$s impressions', 'laghavi-performance-insight-for-woocommerce' ), self::n( $t['clicks'] ), self::n( $t['impressions'] ) ) );
		}
		if ( $b ) {
			$r   = LGPI_Search::bing_report( $since, $until );
			$hit = null;
			foreach ( (array) ( $r['pages'] ?? array() ) as $p ) {
				if ( untrailingslashit( (string) $p['keys'][0] ) === untrailingslashit( $url ) ) {
					$hit = $p;
				}
			}
			echo '<div class="lgpi-card"><h3>' . esc_html__( 'Bing for this page', 'laghavi-performance-insight-for-woocommerce' ) . '</h3>';
			echo $hit ? '<p>' . esc_html( sprintf( /* translators: 1: clicks, 2: impressions, 3: position */ __( '%1$s clicks · %2$s impressions · average position %3$s', 'laghavi-performance-insight-for-woocommerce' ), self::n( $hit['clicks'] ), self::n( $hit['impressions'] ), self::n( $hit['position'], 1 ) ) ) . '</p>' : '<p class="lgpi-muted">' . esc_html__( 'No Bing clicks or impressions for this page in these weeks.', 'laghavi-performance-insight-for-woocommerce' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			echo '</div>';
		}
		echo '</div>';
	}

	/**
	 * Connect / choose / disconnect (administrators).
	 *
	 * @param bool $inline Inside the intro card.
	 */
	public static function connections( $inline = false ) {
		$o = LGPI_Search::get();
		if ( ! $inline ) {
			echo '<div class="lgpi-card"><h3>' . esc_html__( 'Connections', 'laghavi-performance-insight-for-woocommerce' ) . '</h3>';
		}
		echo '<div class="lgpi-grid2 lgpi-conn">';
		// Google.
		echo '<div><h4><span class="lgpi-engine g">G</span> Google Search Console</h4>';
		if ( '' === $o['g_refresh'] || 'revoked' === $o['g_error'] ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'lgpi_google_connect' );
			echo '<input type="hidden" name="action" value="lgpi_google_connect"><button class="button button-primary">' . esc_html__( 'Sign in with Google', 'laghavi-performance-insight-for-woocommerce' ) . '</button></form>';
			echo '<p class="description">' . esc_html__( 'Read-only access to your Search Console data. Sign-in goes through Laghavi Connect, which passes the sign-in back to this site and keeps nothing; your search data is then read by this site directly from Google.', 'laghavi-performance-insight-for-woocommerce' ) . '</p>';
		} else {
			echo '<p>' . esc_html( sprintf( /* translators: %s: email */ __( 'Signed in as %s', 'laghavi-performance-insight-for-woocommerce' ), '' !== $o['g_email'] ? $o['g_email'] : __( 'your Google account', 'laghavi-performance-insight-for-woocommerce' ) ) ) . '</p>';
			$sites = LGPI_Search::gsc_sites();
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'lgpi_search_save' );
			echo '<input type="hidden" name="action" value="lgpi_search_save"><label>' . esc_html__( 'Property', 'laghavi-performance-insight-for-woocommerce' ) . ' <select name="g_site">';
			if ( '' === $o['g_site'] ) {
				echo '<option value="">' . esc_html__( '— choose —', 'laghavi-performance-insight-for-woocommerce' ) . '</option>';
			}
			foreach ( $sites as $s ) {
				echo '<option value="' . esc_attr( $s ) . '" ' . selected( $s, $o['g_site'], false ) . '>' . esc_html( $s ) . '</option>';
			}
			echo '</select></label> <button class="button">' . esc_html__( 'Save', 'laghavi-performance-insight-for-woocommerce' ) . '</button></form>';
			if ( ! $sites ) {
				echo '<p class="description">' . esc_html__( 'No Search Console property found for this Google account. Add and verify your site at search.google.com/search-console, then reload this page.', 'laghavi-performance-insight-for-woocommerce' ) . '</p>';
			}
			self::disconnect_button( 'google' );
		}
		echo '</div>';
		// Bing.
		echo '<div><h4><span class="lgpi-engine b">b</span> Bing Webmaster Tools</h4>';
		if ( '' === $o['b_key'] ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'lgpi_search_save' );
			echo '<input type="hidden" name="action" value="lgpi_search_save"><input type="password" name="b_key" class="regular-text" autocomplete="off" placeholder="' . esc_attr__( 'Bing API key', 'laghavi-performance-insight-for-woocommerce' ) . '"> <button class="button button-primary">' . esc_html__( 'Connect Bing', 'laghavi-performance-insight-for-woocommerce' ) . '</button></form>';
			echo '<p class="description">' . esc_html__( 'In Bing Webmaster Tools open Settings → API access → API key, copy the key and paste it here. Your site must be added and verified there (you can import it from Google Search Console in one click). The key is stored encrypted on this site and only sent to Bing.', 'laghavi-performance-insight-for-woocommerce' ) . '</p>';
		} else {
			echo '<p>' . esc_html( sprintf( /* translators: %s: site */ __( 'Connected: %s', 'laghavi-performance-insight-for-woocommerce' ), $o['b_site'] ) ) . '</p>';
			self::disconnect_button( 'bing' );
		}
		echo '</div></div>';
		if ( ! $inline ) {
			echo '</div>';
		}
	}

	/**
	 * Disconnect button.
	 *
	 * @param string $which google|bing.
	 */
	private static function disconnect_button( $which ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:8px">';
		wp_nonce_field( 'lgpi_search_disconnect' );
		echo '<input type="hidden" name="action" value="lgpi_search_disconnect"><input type="hidden" name="which" value="' . esc_attr( $which ) . '"><button class="button-link lgpi-rec-dismiss">' . esc_html__( 'Disconnect', 'laghavi-performance-insight-for-woocommerce' ) . '</button></form>';
	}
}

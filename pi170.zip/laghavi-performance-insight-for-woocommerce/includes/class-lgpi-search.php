<?php
/**
 * Search connections: Google Search Console (sign in with Google) and Bing Webmaster Tools (API key).
 *
 * Optional and off until the owner connects. Google sign-in goes through Laghavi Connect, a small relay that holds
 * the Google app's secret (like Site Kit and MonsterInsights do); it hands the sign-in back sealed with a one-time key
 * and stores nothing. After that, this site reads its reports straight from Google and Bing — report data never
 * passes through Laghavi. Tokens are stored encrypted in this site's database.
 *
 * @package PerformanceInsight
 */

defined( 'ABSPATH' ) || exit;

/**
 * Connections and data.
 */
class LGPI_Search {

	const OPTION = 'lgpi_search';
	const GSC    = 'https://www.googleapis.com/webmasters/v3/';
	const BING   = 'https://ssl.bing.com/webmaster/api.svc/json/';
	const CACHE  = 6 * HOUR_IN_SECONDS;

	/**
	 * Laghavi Connect address (can be changed with the lgpi_connect_url filter).
	 *
	 * @return string
	 */
	public static function relay() {
		return trailingslashit( (string) apply_filters( 'lgpi_connect_url', 'https://sh.laghavi.site/connect/' ) );
	}

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_post_lgpi_google_connect', array( __CLASS__, 'google_connect' ) );
		add_action( 'admin_post_lgpi_google_back', array( __CLASS__, 'google_back' ) );
		add_action( 'admin_post_lgpi_search_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_lgpi_search_disconnect', array( __CLASS__, 'disconnect' ) );
	}

	// ------------------------------------------------------------------ settings & secrets

	/**
	 * Saved connections.
	 *
	 * @return array
	 */
	public static function get() {
		$o = get_option( self::OPTION, array() );
		return wp_parse_args(
			is_array( $o ) ? $o : array(),
			array(
				'g_refresh' => '',
				'g_email'   => '',
				'g_scope'   => '',
				'g_site'    => '',
				'g_error'   => '',
				'b_key'     => '',
				'b_site'    => '',
				'b_error'   => '',
			)
		);
	}

	/**
	 * Save connections (never autoloaded).
	 *
	 * @param array $o Values.
	 */
	private static function put( $o ) {
		update_option( self::OPTION, $o, false );
	}

	/**
	 * Key for encrypting tokens at rest, from this site's own secret keys in wp-config.php.
	 *
	 * @return string 32 bytes.
	 */
	private static function key() {
		return hash( 'sha256', wp_salt( 'secure_auth' ) . '|lgpi-search', true );
	}

	/**
	 * Encrypt a secret for the database.
	 *
	 * @param string $plain Text.
	 * @return string
	 */
	private static function seal( $plain ) {
		if ( '' === $plain ) {
			return '';
		}
		$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		return 's1:' . base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, self::key() ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Decrypt a secret from the database ('' when it can't be read, e.g. after the site's keys changed).
	 *
	 * @param string $stored Stored value.
	 * @return string
	 */
	private static function open( $stored ) {
		if ( 0 !== strpos( (string) $stored, 's1:' ) ) {
			return '';
		}
		$raw = base64_decode( substr( $stored, 3 ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		if ( ! $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
			return '';
		}
		$out = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), self::key() );
		return false === $out ? '' : $out;
	}

	/**
	 * Base64url helpers.
	 *
	 * @param string $s Bytes.
	 * @return string
	 */
	private static function b64u( $s ) {
		return rtrim( strtr( base64_encode( $s ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Base64url decode.
	 *
	 * @param string $s Text.
	 * @return string
	 */
	private static function unb64u( $s ) {
		return (string) base64_decode( strtr( $s, '-_', '+/' ) . str_repeat( '=', ( 4 - strlen( $s ) % 4 ) % 4 ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
	}

	/**
	 * Is Google connected (and a property chosen)?
	 *
	 * @return bool
	 */
	public static function google_on() {
		$o = self::get();
		return '' !== $o['g_refresh'] && '' !== $o['g_site'];
	}

	/**
	 * Is Bing connected?
	 *
	 * @return bool
	 */
	public static function bing_on() {
		$o = self::get();
		return '' !== $o['b_key'] && '' !== $o['b_site'];
	}

	// ------------------------------------------------------------------ Google sign-in

	/**
	 * "Connect Google": make a one-time key pair and go to Laghavi Connect.
	 */
	public static function google_connect() {
		check_admin_referer( 'lgpi_google_connect' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'laghavi-performance-insight-for-woocommerce' ) );
		}
		$pair  = sodium_crypto_box_keypair();
		$nonce = wp_generate_password( 24, false, false );
		set_transient(
			'lgpi_gsign_' . get_current_user_id(),
			array(
				'kp' => self::b64u( $pair ),
				'n'  => $nonce,
			),
			30 * MINUTE_IN_SECONDS
		);
		$url = add_query_arg(
			array(
				'site'   => rawurlencode( home_url( '/' ) ),
				'back'   => rawurlencode( admin_url( 'admin-post.php?action=lgpi_google_back' ) ),
				'pk'     => self::b64u( sodium_crypto_box_publickey( $pair ) ),
				'n'      => $nonce,
				'scopes' => 'gsc',
				'v'      => LGPI_VERSION,
			),
			self::relay() . 'start.php'
		);
		wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- our own sign-in relay.
		exit;
	}

	/**
	 * Back from Google: open the sealed tokens with the one-time key, save them, pick the matching property.
	 */
	public static function google_back() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'laghavi-performance-insight-for-woocommerce' ) );
		}
		$key = 'lgpi_gsign_' . get_current_user_id();
		$t   = get_transient( $key );
		delete_transient( $key );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- protected by the one-time key and nonce sealed in the payload.
		if ( isset( $_GET['lgpi_gerr'] ) ) {
			LGPI_Admin::back( 'lgpi-search', __( 'Google sign-in was cancelled or did not finish. Please try again.', 'laghavi-performance-insight-for-woocommerce' ), true );
		}
		$sealed = isset( $_GET['lgpi_sealed'] ) ? self::unb64u( sanitize_text_field( wp_unslash( $_GET['lgpi_sealed'] ) ) ) : '';
		// phpcs:enable
		$data = null;
		if ( is_array( $t ) && '' !== $sealed ) {
			$plain = sodium_crypto_box_seal_open( $sealed, self::unb64u( (string) $t['kp'] ) );
			$data  = false === $plain ? null : json_decode( $plain, true );
		}
		if ( ! is_array( $data ) || ! hash_equals( (string) $t['n'], (string) ( $data['n'] ?? '' ) ) || empty( $data['refresh_token'] ) ) {
			LGPI_Admin::back( 'lgpi-search', __( 'The Google sign-in could not be completed (it may have taken longer than 30 minutes). Please try again.', 'laghavi-performance-insight-for-woocommerce' ), true );
		}
		$o              = self::get();
		$o['g_refresh'] = self::seal( (string) $data['refresh_token'] );
		$o['g_email']   = sanitize_email( (string) ( $data['email'] ?? '' ) );
		$o['g_scope']   = sanitize_text_field( (string) ( $data['scope'] ?? '' ) );
		$o['g_error']   = '';
		$o['g_site']    = '';
		self::put( $o );
		set_transient( 'lgpi_g_at', self::seal( (string) $data['access_token'] ), max( 60, (int) ( $data['expires_in'] ?? 3600 ) - 120 ) );
		$sites = self::gsc_sites();
		$pick  = self::best_site( $sites );
		if ( $pick ) {
			$o           = self::get();
			$o['g_site'] = $pick;
			self::put( $o );
			self::flush();
			LGPI_Admin::back( 'lgpi-search', sprintf( /* translators: %s: Search Console property */ __( 'Google Search Console is connected (%s).', 'laghavi-performance-insight-for-woocommerce' ), $pick ) );
		}
		LGPI_Admin::back( 'lgpi-search', $sites ? __( 'Google is connected. Choose which Search Console property belongs to this site.', 'laghavi-performance-insight-for-woocommerce' ) : __( 'Google is connected, but this Google account has no Search Console property for this site yet. Add and verify your site in Search Console, then reload this page.', 'laghavi-performance-insight-for-woocommerce' ), ! $sites );
	}

	/**
	 * A fresh Google access token ('' when Google is not connected or access was removed).
	 *
	 * @return string
	 */
	private static function google_token() {
		$cached = get_transient( 'lgpi_g_at' );
		if ( $cached ) {
			$at = self::open( (string) $cached );
			if ( '' !== $at ) {
				return $at;
			}
		}
		$o  = self::get();
		$rt = self::open( $o['g_refresh'] );
		if ( '' === $rt ) {
			return '';
		}
		$res  = wp_remote_post(
			self::relay() . 'refresh.php',
			array(
				'timeout' => 15,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( array( 'refresh_token' => $rt ) ),
			)
		);
		$code = (int) wp_remote_retrieve_response_code( $res );
		$j    = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( 200 !== $code || empty( $j['access_token'] ) ) {
			if ( 400 === $code && 'invalid_grant' === ( $j['error'] ?? '' ) ) {
				$o['g_error'] = 'revoked';
				self::put( $o );
			}
			return '';
		}
		set_transient( 'lgpi_g_at', self::seal( (string) $j['access_token'] ), max( 60, (int) ( $j['expires_in'] ?? 3600 ) - 120 ) );
		return (string) $j['access_token'];
	}

	/**
	 * Call a Google API.
	 *
	 * @param string     $url  Address.
	 * @param array|null $body JSON body (POST) or null (GET).
	 * @return array|null
	 */
	private static function google( $url, $body = null ) {
		$at = self::google_token();
		if ( '' === $at ) {
			return null;
		}
		$args = array(
			'timeout' => 20,
			'headers' => array(
				'Authorization' => 'Bearer ' . $at,
				'Content-Type'  => 'application/json',
			),
		);
		$res  = null === $body ? wp_remote_get( $url, $args ) : wp_remote_post( $url, $args + array( 'body' => wp_json_encode( $body ) ) );
		$code = (int) wp_remote_retrieve_response_code( $res );
		$j    = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( 401 === $code ) {
			delete_transient( 'lgpi_g_at' );
		}
		if ( 403 === $code ) {
			$o            = self::get();
			$o['g_error'] = 'no_access';
			self::put( $o );
		}
		return 200 === $code && is_array( $j ) ? $j : null;
	}

	/**
	 * Search Console properties this Google account can read.
	 *
	 * @return string[]
	 */
	public static function gsc_sites() {
		$j   = self::google( self::GSC . 'sites' );
		$out = array();
		foreach ( (array) ( $j['siteEntry'] ?? array() ) as $s ) {
			if ( 'siteUnverifiedUser' !== ( $s['permissionLevel'] ?? '' ) && ! empty( $s['siteUrl'] ) ) {
				$out[] = (string) $s['siteUrl'];
			}
		}
		return $out;
	}

	/**
	 * The property that matches this site: the exact URL prefix first, then the domain property.
	 *
	 * @param string[] $sites Properties.
	 * @return string
	 */
	public static function best_site( $sites ) {
		$home = trailingslashit( home_url( '/' ) );
		$host = (string) preg_replace( '/^www\./', '', (string) wp_parse_url( $home, PHP_URL_HOST ) );
		foreach ( array( $home, set_url_scheme( $home, 'https' ), str_replace( '://', '://www.', set_url_scheme( $home, 'https' ) ), str_replace( '://www.', '://', set_url_scheme( $home, 'https' ) ), 'sc-domain:' . $host ) as $want ) {
			if ( in_array( $want, $sites, true ) ) {
				return $want;
			}
		}
		return '';
	}

	// ------------------------------------------------------------------ Bing

	/**
	 * Call the Bing Webmaster API (GET).
	 *
	 * @param string $method Method, e.g. GetUserSites.
	 * @param array  $args   Query arguments.
	 * @param string $key    API key (default: the saved one).
	 * @return array|null The "d" value.
	 */
	private static function bing( $method, $args = array(), $key = '' ) {
		$key = '' !== $key ? $key : self::open( self::get()['b_key'] );
		if ( '' === $key ) {
			return null;
		}
		$res  = wp_remote_get( add_query_arg( array_map( 'rawurlencode', $args + array( 'apikey' => $key ) ), self::BING . $method ), array( 'timeout' => 20 ) );
		$code = (int) wp_remote_retrieve_response_code( $res );
		$j    = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		return 200 === $code && is_array( $j ) && isset( $j['d'] ) ? (array) $j['d'] : null;
	}

	/**
	 * Bing dates look like /Date(1700000000000-0800)/.
	 *
	 * @param string $d Bing date.
	 * @return string Y-m-d in the site's time zone, or ''.
	 */
	private static function bing_day( $d ) {
		return preg_match( '/Date\((-?\d+)/', (string) $d, $m ) ? wp_date( 'Y-m-d', (int) floor( (int) $m[1] / 1000 ) ) : '';
	}

	// ------------------------------------------------------------------ settings screen actions

	/**
	 * Save the Google property and the Bing key / site.
	 */
	public static function save() {
		check_admin_referer( 'lgpi_search_save' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'laghavi-performance-insight-for-woocommerce' ) );
		}
		$o = self::get();
		if ( isset( $_POST['g_site'] ) ) {
			$want = sanitize_text_field( wp_unslash( $_POST['g_site'] ) );
			if ( in_array( $want, self::gsc_sites(), true ) ) {
				$o['g_site']  = $want;
				$o['g_error'] = '';
			}
		}
		$msg = __( 'Saved.', 'laghavi-performance-insight-for-woocommerce' );
		$err = false;
		$key = isset( $_POST['b_key'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_POST['b_key'] ) ) : '';
		if ( '' !== $key ) {
			$sites = self::bing( 'GetUserSites', array(), $key );
			if ( null === $sites ) {
				$msg = __( 'Bing did not accept that API key. Copy it again from Bing Webmaster Tools → Settings → API access.', 'laghavi-performance-insight-for-woocommerce' );
				$err = true;
			} else {
				$urls = array();
				foreach ( $sites as $s ) {
					if ( ! empty( $s['Url'] ) && ! empty( $s['IsVerified'] ) ) {
						$urls[] = (string) $s['Url'];
					}
				}
				$host = (string) preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
				$pick = '';
				foreach ( $urls as $u ) {
					if ( preg_replace( '/^www\./', '', (string) wp_parse_url( $u, PHP_URL_HOST ) ) === $host ) {
						$pick = $u;
						break;
					}
				}
				if ( '' === $pick ) {
					$msg = __( 'The key works, but this site is not verified in that Bing Webmaster Tools account. Add and verify it there (you can import it from Google Search Console), then save again.', 'laghavi-performance-insight-for-woocommerce' );
					$err = true;
				} else {
					$o['b_key']   = self::seal( $key );
					$o['b_site']  = $pick;
					$o['b_error'] = '';
					$msg          = sprintf( /* translators: %s: site */ __( 'Bing Webmaster Tools is connected (%s).', 'laghavi-performance-insight-for-woocommerce' ), $pick );
				}
			}
		}
		self::put( $o );
		self::flush();
		LGPI_Admin::back( 'lgpi-search', $msg, $err );
	}

	/**
	 * Disconnect Google or Bing (Google access is also withdrawn at Google).
	 */
	public static function disconnect() {
		check_admin_referer( 'lgpi_search_disconnect' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'laghavi-performance-insight-for-woocommerce' ) );
		}
		$which = isset( $_POST['which'] ) ? sanitize_key( wp_unslash( $_POST['which'] ) ) : '';
		$o     = self::get();
		if ( 'google' === $which ) {
			$rt = self::open( $o['g_refresh'] );
			if ( '' !== $rt ) {
				wp_remote_post(
					'https://oauth2.googleapis.com/revoke',
					array(
						'timeout'  => 10,
						'blocking' => false,
						'body'     => array( 'token' => $rt ),
					)
				);
			}
			foreach ( array( 'g_refresh', 'g_email', 'g_scope', 'g_site', 'g_error' ) as $k ) {
				$o[ $k ] = '';
			}
			delete_transient( 'lgpi_g_at' );
		} elseif ( 'bing' === $which ) {
			foreach ( array( 'b_key', 'b_site', 'b_error' ) as $k ) {
				$o[ $k ] = '';
			}
		}
		self::put( $o );
		self::flush();
		LGPI_Admin::back( 'lgpi-search', __( 'Disconnected.', 'laghavi-performance-insight-for-woocommerce' ) );
	}

	/**
	 * Forget cached reports.
	 */
	public static function flush() {
		update_option( 'lgpi_search_gen', time(), false );
	}

	/**
	 * Cached call.
	 *
	 * @param string   $name Cache name.
	 * @param callable $fn   Producer (null results are not cached for long).
	 * @return mixed
	 */
	private static function cached( $name, $fn ) {
		$key = 'lgpi_s_' . md5( $name . '|' . get_option( 'lgpi_search_gen', 0 ) );
		$hit = get_transient( $key );
		if ( false !== $hit ) {
			return $hit;
		}
		$val = call_user_func( $fn );
		set_transient( $key, null === $val ? 'err' : $val, null === $val ? 10 * MINUTE_IN_SECONDS : self::CACHE );
		return $val;
	}

	// ------------------------------------------------------------------ reports

	/**
	 * Search Console rows for a period.
	 *
	 * @param string $since   Y-m-d.
	 * @param string $until   Y-m-d.
	 * @param array  $dims    Dimensions (query, page, date).
	 * @param int    $limit   Rows.
	 * @param string $page    Only this page URL ('' = all).
	 * @return array|null [ [keys..., clicks, impressions, ctr, position], ... ]
	 */
	public static function gsc( $since, $until, $dims, $limit = 100, $page = '' ) {
		if ( ! self::google_on() ) {
			return null;
		}
		$site = self::get()['g_site'];
		$out  = self::cached(
			'gsc|' . $site . '|' . $since . '|' . $until . '|' . implode( ',', $dims ) . '|' . $limit . '|' . $page,
			function () use ( $site, $since, $until, $dims, $limit, $page ) {
				$body = array(
					'startDate'  => $since,
					'endDate'    => $until,
					'dimensions' => $dims,
					'rowLimit'   => $limit,
					'dataState'  => 'all',
				);
				if ( '' !== $page ) {
					$body['dimensionFilterGroups'] = array(
						array(
							'filters' => array(
								array(
									'dimension'  => 'page',
									'operator'   => 'equals',
									'expression' => $page,
								),
							),
						),
					);
				}
				$j = self::google( self::GSC . 'sites/' . rawurlencode( $site ) . '/searchAnalytics/query', $body );
				if ( null === $j ) {
					return null;
				}
				$rows = array();
				foreach ( (array) ( $j['rows'] ?? array() ) as $r ) {
					$rows[] = array(
						'keys'        => (array) ( $r['keys'] ?? array() ),
						'clicks'      => (int) ( $r['clicks'] ?? 0 ),
						'impressions' => (int) ( $r['impressions'] ?? 0 ),
						'ctr'         => (float) ( $r['ctr'] ?? 0 ) * 100,
						'position'    => (float) ( $r['position'] ?? 0 ),
					);
				}
				return $rows;
			}
		);
		return 'err' === $out ? null : $out;
	}

	/**
	 * Bing rows for a period: totals per day, per query and per page. Bing gives weekly rows for queries and pages,
	 * so those are the weeks that fall in the period.
	 *
	 * @param string $since Y-m-d.
	 * @param string $until Y-m-d.
	 * @return array|null ['days' => [Y-m-d => [clicks, impressions]], 'queries' => [...], 'pages' => [...]]
	 */
	public static function bing_report( $since, $until ) {
		if ( ! self::bing_on() ) {
			return null;
		}
		$site = self::get()['b_site'];
		$out  = self::cached(
			'bing|' . $site . '|' . $since . '|' . $until,
			function () use ( $site, $since, $until ) {
				$traffic = self::bing( 'GetRankAndTrafficStats', array( 'siteUrl' => $site ) );
				if ( null === $traffic ) {
					return null;
				}
				$days = array();
				foreach ( $traffic as $r ) {
					$d = self::bing_day( $r['Date'] ?? '' );
					if ( $d >= $since && $d <= $until ) {
						$days[ $d ] = array( (int) ( $r['Clicks'] ?? 0 ), (int) ( $r['Impressions'] ?? 0 ) );
					}
				}
				ksort( $days );
				$group = function ( $rows ) use ( $since, $until ) {
					$agg = array();
					foreach ( (array) $rows as $r ) {
						$d = self::bing_day( $r['Date'] ?? '' );
						$k = (string) ( $r['Query'] ?? '' );
						if ( '' === $k || $d < gmdate( 'Y-m-d', strtotime( $since . ' -6 days' ) ) || $d > $until ) {
							continue;
						}
						if ( ! isset( $agg[ $k ] ) ) {
							$agg[ $k ] = array(
								'keys'        => array( $k ),
								'clicks'      => 0,
								'impressions' => 0,
								'pos_sum'     => 0.0,
							);
						}
						$agg[ $k ]['clicks']      += (int) ( $r['Clicks'] ?? 0 );
						$agg[ $k ]['impressions'] += (int) ( $r['Impressions'] ?? 0 );
						$agg[ $k ]['pos_sum']     += (float) ( $r['AvgImpressionPosition'] ?? 0 ) * max( 1, (int) ( $r['Impressions'] ?? 0 ) );
					}
					foreach ( $agg as &$a ) {
						$a['ctr']      = $a['impressions'] ? $a['clicks'] / $a['impressions'] * 100 : 0;
						$a['position'] = $a['impressions'] ? $a['pos_sum'] / $a['impressions'] : 0;
						unset( $a['pos_sum'] );
					}
					unset( $a );
					usort(
						$agg,
						function ( $x, $y ) {
							return array( $y['clicks'], $y['impressions'] ) <=> array( $x['clicks'], $x['impressions'] );
						}
					);
					return array_slice( $agg, 0, 100 );
				};
				return array(
					'days'    => $days,
					'queries' => $group( self::bing( 'GetQueryStats', array( 'siteUrl' => $site ) ) ),
					'pages'   => $group( self::bing( 'GetPageStats', array( 'siteUrl' => $site ) ) ),
				);
			}
		);
		return 'err' === $out ? null : $out;
	}

	/**
	 * Totals of rows.
	 *
	 * @param array $rows Rows with clicks, impressions, position.
	 * @return array clicks, impressions, ctr, position.
	 */
	public static function totals( $rows ) {
		$t = array(
			'clicks'      => 0,
			'impressions' => 0,
			'pos'         => 0.0,
		);
		foreach ( (array) $rows as $r ) {
			$t['clicks']      += $r['clicks'];
			$t['impressions'] += $r['impressions'];
			$t['pos']         += $r['position'] * $r['impressions'];
		}
		return array(
			'clicks'      => $t['clicks'],
			'impressions' => $t['impressions'],
			'ctr'         => $t['impressions'] ? $t['clicks'] / $t['impressions'] * 100 : null,
			'position'    => $t['impressions'] ? $t['pos'] / $t['impressions'] : null,
		);
	}

	/**
	 * The post / product / term behind one of this site's URLs: [type, id] or null.
	 *
	 * @param string $url Page address.
	 * @return array|null
	 */
	public static function object_for_url( $url ) {
		$home = (string) preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		if ( (string) preg_replace( '/^www\./', '', (string) wp_parse_url( $url, PHP_URL_HOST ) ) !== $home ) {
			return null;
		}
		$query = (string) wp_parse_url( $url, PHP_URL_QUERY );
		$clean = (string) strtok( $url, '?#' );
		if ( '' === $query && untrailingslashit( $clean ) === untrailingslashit( home_url() ) ) {
			$front = (int) get_option( 'page_on_front' );
			return $front ? array( 'page', $front ) : array( 'home', 0 );
		}
		$id = url_to_postid( $url );
		if ( ! $id && '' !== $query ) {
			// Plain permalinks: ?product=slug, ?post_type=slug.
			parse_str( $query, $q );
			foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $pt ) {
				if ( $pt->query_var && ! empty( $q[ $pt->query_var ] ) && is_string( $q[ $pt->query_var ] ) ) {
					$post = get_page_by_path( sanitize_title( $q[ $pt->query_var ] ), OBJECT, $pt->name );
					$id   = $post ? (int) $post->ID : 0;
					break;
				}
			}
		}
		if ( $id ) {
			return array( substr( (string) get_post_type( $id ), 0, 20 ), $id );
		}
		return null;
	}

	/**
	 * The address Google and Bing know for one of our objects.
	 *
	 * @param string $type Type.
	 * @param int    $id   ID.
	 * @return string
	 */
	public static function url_for( $type, $id ) {
		if ( 'home' === $type ) {
			return home_url( '/' );
		}
		if ( taxonomy_exists( $type ) ) {
			$l = get_term_link( $id, $type );
			return is_wp_error( $l ) ? '' : (string) $l;
		}
		return (string) get_permalink( $id );
	}
}

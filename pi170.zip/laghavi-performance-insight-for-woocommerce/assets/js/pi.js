/* Performance Insight — counts one page view on this site (no cookies, nothing sent elsewhere). */
( function () {
	var c = window.lgpiTrack;
	if ( ! c || ! c.url ) { return; }
	if ( c.dnt && ( navigator.doNotTrack === '1' || window.doNotTrack === '1' ) ) { return; }
	if ( navigator.webdriver ) { return; }
	function send( url, body ) {
		try {
			if ( navigator.sendBeacon && navigator.sendBeacon( url, new Blob( [ body ], { type: 'application/json' } ) ) ) { return; }
		} catch ( e ) {}
		try {
			fetch( url, { method: 'POST', body: body, headers: { 'Content-Type': 'application/json' }, keepalive: true, credentials: 'omit' } );
		} catch ( e ) {}
	}
	var tz = '';
	try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch ( e ) {}
	var pv, shown = 0, total = 0, sentLeave = false;
	function view( first ) {
		// A random id for this one page view, so the time spent on it can be added when the visitor leaves.
		pv = Math.random().toString( 36 ).slice( 2, 12 );
		total = 0; sentLeave = false;
		shown = document.visibilityState === 'visible' ? Date.now() : 0;
		send( c.url, JSON.stringify( {
			t: c.t, i: c.i, r: first ? ( document.referrer || '' ) : '', u: first ? ( location.search || '' ) : '', pv: pv,
			w: window.screen ? screen.width : 0, h: window.screen ? screen.height : 0,
			l: navigator.language || '', z: tz, co: c.co ? 1 : 0, s: c.s || '', nf: c.nf || ''
		} ) );
	}
	function leave() {
		if ( shown ) { total += Date.now() - shown; shown = 0; }
		var s = Math.round( total / 1000 );
		if ( c.leave && s > 0 && ! sentLeave ) { sentLeave = true; send( c.leave, JSON.stringify( { pv: pv, d: s } ) ); }
	}
	function start() {
		view( true );
		document.addEventListener( 'visibilitychange', function () {
			if ( document.visibilityState === 'hidden' ) { leave(); } else if ( ! shown ) { shown = Date.now(); sentLeave = false; }
		} );
		window.addEventListener( 'pagehide', leave );
		// Back / forward from the browser cache does not run scripts again: count that view too.
		window.addEventListener( 'pageshow', function ( e ) { if ( e.persisted ) { view( false ); } } );
	}
	// A page the browser prepared in advance (prerender) is only counted if the visitor really opens it.
	if ( document.prerendering ) {
		document.addEventListener( 'prerenderingchange', start, { once: true } );
	} else {
		start();
	}
}() );
